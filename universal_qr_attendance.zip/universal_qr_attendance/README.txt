# QR CODE ATTENDANCE MANAGEMENT SYSTEM

Current Version: 1.1.2

## IMPORTANT LICENSE NOTICE

This project is provided for EDUCATIONAL AND NON-COMMERCIAL USE ONLY.

It is primarily intended for students, learners, teachers, educators, academic projects, demonstrations, personal learning, experimentation, and other educational purposes.

Commercial use, commercial deployment, resale, sublicensing, redistribution as a paid product or service, or incorporation into a commercial product or service is NOT permitted without prior written permission from the copyright holder.

Please read LICENSE.txt before using, modifying, or redistributing this project.

## PROJECT DESCRIPTION

QR Code Attendance Management System is a PHP/MySQL-based attendance management application designed primarily as an educational project.

It demonstrates how a complete attendance management platform can be developed using PHP, MySQL, PDO, role-based authentication, QR codes, browser camera scanning, reporting, and a responsive administrative interface.

Attendees are stored as People and classified through configurable Categories, making the same project suitable for educational demonstrations involving schools, companies, organizations, seminars, clubs, events, and mixed-use environments.

This project is intended to help students and learners study and understand concepts such as:

* PHP application development
* MySQL database design
* CRUD operations
* Authentication and authorization
* Role-based access control
* PDO and prepared statements
* QR code generation and validation
* Browser-based camera access
* Attendance management
* Report generation
* PDF and spreadsheet exports
* Session and CSRF security
* Audit logging
* Responsive web application development
* MVC-style application organization
* Configuration management
* Composer dependency management

## FEATURES

* Secure authentication, role-based access, password reset tokens, profile updates, and change password
* Super Administrator, Administrator, and Staff / Operator roles
* Dashboard statistics, Time In / Time Out summary, 7-day graph, recent attendance, and announcements
* People registration with unique Person ID, photo, category, department/group, optional position, status, and secure QR token
* Category and department/group management with parent groups
* QR generation, validation, regeneration, download, preview, and professional CR80 individual/bulk identity-card printing
* Mobile/webcam QR scanner with instant save, success/error audio, invalid/replaced QR detection, duplicate alerts, and confirmation profile
* Separate responsive public self-service Attendance Kiosk page with no administrator login or admin-panel access
* Automatic Time In / Time Out, plus optional Break Out / Break In modes
* Manual attendance, attendance corrections, remarks, scanner location, and correction audit history
* Present, Late, Absent, On Leave, Holiday, and Half-Day statuses
* Configurable attendance schedules, active days, late threshold, scan window, and assignments to categories, groups, or people
* Daily, weekly, monthly, yearly, individual, department, category, late, and absent reports
* PDF, Excel XLSX, CSV, and printable report outputs
* Search/filter by name, Person ID, QR token, category, department, date, and status
* In-app attendance and low-attendance alerts
* Announcements, holidays, notifications, activity logs, and login/logout history
* Organization settings, logo, timezone, Person ID rules, QR settings, public kiosk controls, SQL backup, download, and restore
* Responsive AdminLTE 3 interface
* 10-record pagination on operational tables

## TECHNOLOGY REQUIREMENTS

* PHP 8.2 or newer
* MySQL 8+ or MariaDB 10.5+
* Apache or Nginx
* Composer 2
* PHP extensions:

  * pdo_mysql
  * gd
  * mbstring
  * zip
  * dom
  * fileinfo
  * json
* HTTPS or localhost for browser camera access

## QUICK INSTALLATION WITH XAMPP ON WINDOWS

1. Extract the project folder to:

   C:\xampp\htdocs\universal_qr_attendance

2. Open Command Prompt or PowerShell in the project folder:

   cd C:\xampp\htdocs\universal_qr_attendance

   composer install --no-dev --optimize-autoloader

3. Enable the required PHP extensions in:

   C:\xampp\php\php.ini

   Remove the leading semicolon from lines such as:

   extension=gd
   extension=mbstring
   extension=mysqli
   extension=pdo_mysql
   extension=zip

   The DOM and Fileinfo extensions are normally enabled by default.

   Restart Apache after making changes to php.ini.

4. Start Apache and MySQL using XAMPP.

5. Open the installer:

   http://localhost/universal_qr_attendance/public/install.php

6. Enter the MySQL connection, application URL, and first Super Administrator details.

   The installer will:

   * Create the database when permitted
   * Import the full schema
   * Seed roles, universal categories, and default settings
   * Create the first Super Administrator
   * Generate the .env configuration file

7. Sign in to the application.

   On a production server, delete or rename:

   public/install.php

   after installation has been completed.

## COMMAND-LINE REQUIREMENTS CHECK

Run the following command before installation or when troubleshooting:

php scripts/check_requirements.php

## MANUAL INSTALLATION

When the hosting account cannot create databases automatically:

1. Create a MySQL database manually.

2. Import:

   database/schema.sql

   using phpMyAdmin or the MySQL client.

3. Copy:

   .env.example

   to:

   .env

   Then enter the correct configuration values.

4. Create the first user manually with a PHP password hash, or temporarily use the web installer against the existing empty database.

5. Run:

   composer install --no-dev --optimize-autoloader

6. Point the web root to the public directory where possible.

## PUBLIC SELF-SERVICE ATTENDANCE KIOSK

Version 1.1.0 introduced a separate scanner page intended for a shared entrance tablet, phone, or computer.

Version 1.1.1 rebuilt the page with a fluid responsive layout, adaptive camera frame, improved spacing, and clearer attendance confirmations.

People can scan their own assigned QR cards without receiving an administrator account.

The default kiosk URL is:

http://localhost/universal_qr_attendance/public/kiosk.php

The exact URL is displayed under:

System Settings -> Public Attendance Kiosk

The Super Administrator can configure:

* Enabled or disabled status
* Kiosk page title
* Scanner location
* Automatic camera startup
* Confirmation-screen duration
* Optional access key for an approved kiosk link

Kiosk attendance uses automatic mode:

1. First accepted scan records Time In.
2. Second accepted scan records Time Out.
3. Once both are recorded, further scans are rejected as completed attendance.

The public kiosk page does not provide:

* Administrator navigation
* Manual attendance controls
* Reports
* People management
* Break actions
* System settings

The kiosk includes protections such as:

* CSRF protection
* Session request throttling
* Secure QR-token validation
* Schedule checks
* Repeated-read delay to help prevent the same card from immediately recording both actions

## IMPORTANT SECURITY AND DEPLOYMENT NOTES

This project is intended primarily for educational use and demonstration.

If you deploy it on an internet-facing or production environment, you are responsible for reviewing and hardening the application, server, PHP configuration, database configuration, file permissions, authentication settings, HTTPS configuration, backups, and other security controls.

Never use real personal or sensitive information for demonstrations unless you have appropriate authorization and security measures in place.

The developer does not guarantee that the project is suitable for a particular production, legal, regulatory, organizational, or security requirement.

## THIRD-PARTY SOFTWARE

The project uses or may use third-party software and libraries.

Examples include:

* AdminLTE
* Bootstrap
* Font Awesome
* Chart.js
* SweetAlert2
* html5-qrcode
* Composer packages and their dependencies

Some frontend libraries are loaded through CDN links.

Third-party software remains subject to its own respective licenses and terms. The license for this project does not replace, modify, or grant additional rights under those third-party licenses.

For a fully offline intranet installation, download the required frontend assets locally and update the application layout URLs accordingly.

## COMPOSER DEPENDENCIES

The source archive intentionally excludes the Composer vendor directory to keep the project archive manageable.

Run:

composer install

to download the compatible libraries defined in composer.json.

## DATA AND PRIVACY

No real personal records are included with the project.

The installer creates only the administrator account entered by the person performing the installation.

If you use this project for demonstrations, testing, or classroom activities, use fictional or appropriately authorized data whenever possible.

## EDUCATIONAL USE

Students and educators are encouraged to:

* Study the source code
* Run the project locally
* Modify the application for learning
* Create educational demonstrations
* Experiment with the database and application architecture
* Add features as part of coursework or personal study
* Create private classroom or laboratory demonstrations
* Learn from the implementation and adapt it for non-commercial educational projects

Any modified version remains subject to the restrictions in LICENSE.txt unless separate written permission has been obtained.

## COMMERCIAL USE

Commercial use is not permitted under the included license.

Examples of prohibited use include, but are not limited to:

* Selling the software
* Selling modified versions of the software
* Offering the software as a paid service
* Deploying it as part of a commercial attendance service
* Including it in a paid software product
* Charging customers for access to the application
* Using it as part of a commercial SaaS product
* Redistributing the project as a paid download
* Using the project as a commercial client deliverable

If you would like to use this project commercially, please contact the copyright holder to request separate written permission or a commercial license.

## COPYRIGHT AND LICENSE

Copyright (c) [2026] [codeastro.com]

This project is licensed under the Educational Non-Commercial License included in LICENSE.txt.

Permission to use, study, copy, modify, and redistribute this project is granted only for purposes permitted by that license.

Commercial use requires prior written permission.

## DISCLAIMER

THIS SOFTWARE IS PROVIDED FOR EDUCATIONAL AND DEMONSTRATION PURPOSES ONLY.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, SECURITY, ACCURACY, OR NON-INFRINGEMENT.

THE COPYRIGHT HOLDER SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES ARISING FROM THE USE OF OR INABILITY TO USE THIS SOFTWARE.

YOU ARE RESPONSIBLE FOR DETERMINING WHETHER THE SOFTWARE IS APPROPRIATE FOR YOUR INTENDED USE.

## VERSION

QR Code Attendance Management System
Version 1.1.2

License: Educational Non-Commercial License

See LICENSE.txt for the complete license terms.
