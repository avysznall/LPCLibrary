<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Services\AttendanceService;
use RuntimeException;

final class AttendanceController extends BaseController
{
    public function index(): void
    {
        $this->auth();
        $q=trim($_GET['q']??'');$category=(int)($_GET['category_id']??0);$department=(int)($_GET['department_id']??0);$status=trim($_GET['status']??'');$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');
        $where=['a.attendance_date BETWEEN ? AND ?'];$params=[$from,$to];
        if($q!==''){$where[]='(p.full_name LIKE ? OR p.person_id LIKE ? OR p.qr_token LIKE ?)';$like="%{$q}%";array_push($params,$like,$like,$like);}if($category){$where[]='p.category_id=?';$params[]=$category;}if($department){$where[]='p.department_id=?';$params[]=$department;}if(in_array($status,['Present','Late','Absent','On Leave','Holiday','Half-Day'],true)){$where[]='a.status=?';$params[]=$status;}
        $w=implode(' AND ',$where);$count=Database::fetch("SELECT COUNT(*) c FROM attendance a JOIN people p ON p.id=a.person_id WHERE {$w}",$params);$p=paginate((int)$count['c'],10);
        $logs=Database::fetchAll("SELECT a.*,p.person_id,p.qr_token,p.full_name,c.name category_name,d.name department_name,s.name schedule_name FROM attendance a JOIN people p ON p.id=a.person_id JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id LEFT JOIN attendance_schedules s ON s.id=a.schedule_id WHERE {$w} ORDER BY a.attendance_date DESC,a.updated_at DESC LIMIT {$p['per_page']} OFFSET {$p['offset']}",$params);
        $categories=Database::fetchAll('SELECT * FROM categories ORDER BY name');$departments=Database::fetchAll('SELECT * FROM departments ORDER BY name');
        view('attendance/index',compact('logs','categories','departments','p','from','to')+['title'=>'Attendance Logs']);
    }

    public function scanner(): void
    {
        $this->auth();view('attendance/scanner',['title'=>'QR Attendance Scanner']);
    }

    public function scanApi(): void
    {
        $this->auth();
        $payload=json_decode(file_get_contents('php://input'),true)?:[];
        if(!\App\Core\Csrf::verify($payload['_token']??null))$this->json(['success'=>false,'message'=>'Security token mismatch. Refresh the page.'],419);
        try{$result=(new AttendanceService())->scan(trim($payload['token']??''),$payload['action']??'auto',trim($payload['location']??''),substr($_SERVER['HTTP_USER_AGENT']??'',0,500));$this->json(['success'=>true]+$result);}
        catch(\Throwable $e){$this->json(['success'=>false,'message'=>$e->getMessage()],422);}
    }

    public function manualForm(): void
    {
        $this->auth();$people=Database::fetchAll('SELECT id,person_id,full_name FROM people WHERE status="Active" ORDER BY full_name');$schedules=Database::fetchAll('SELECT * FROM attendance_schedules WHERE status="Active" ORDER BY name');view('attendance/form',compact('people','schedules')+['title'=>'Manual Attendance','record'=>null]);
    }

    public function manualStore(): void
    {
        $this->auth();$this->csrf();
        try{$d=$this->validateManual();$exists=Database::fetch('SELECT id FROM attendance WHERE person_id=? AND attendance_date=? AND schedule_id <=> ?',[$d['person_id'],$d['attendance_date'],$d['schedule_id']]);if($exists)throw new RuntimeException('An attendance record already exists for this person, date, and schedule.');
            $id=Database::insert('INSERT INTO attendance (person_id,schedule_id,attendance_date,time_in,time_out,break_out,break_in,status,remarks,scanner_location,created_by,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',[$d['person_id'],$d['schedule_id'],$d['attendance_date'],$d['time_in'],$d['time_out'],$d['break_out'],$d['break_in'],$d['status'],$d['remarks'],$d['scanner_location'],Auth::id(),Auth::id()]);activity('Manual Attendance Created','attendance',$id,$d['attendance_date']);flash('success','Attendance record created.');redirect('attendance');
        }catch(\Throwable $e){set_old($_POST);flash('error',$e->getMessage());redirect('attendance/manual');}
    }

    public function edit(): void
    {
        $this->auth();$record=Database::fetch('SELECT * FROM attendance WHERE id=?',[(int)($_GET['id']??0)]);if(!$record){flash('error','Attendance record not found.');redirect('attendance');}$people=Database::fetchAll('SELECT id,person_id,full_name FROM people ORDER BY full_name');$schedules=Database::fetchAll('SELECT * FROM attendance_schedules ORDER BY name');view('attendance/form',compact('record','people','schedules')+['title'=>'Attendance Correction']);
    }

    public function update(): void
    {
        $this->auth();$this->csrf();$id=(int)($_POST['id']??0);$old=Database::fetch('SELECT * FROM attendance WHERE id=?',[$id]);if(!$old){flash('error','Attendance record not found.');redirect('attendance');}
        try{$d=$this->validateManual();Database::execute('UPDATE attendance SET person_id=?,schedule_id=?,attendance_date=?,time_in=?,time_out=?,break_out=?,break_in=?,status=?,remarks=?,scanner_location=?,updated_by=? WHERE id=?',[$d['person_id'],$d['schedule_id'],$d['attendance_date'],$d['time_in'],$d['time_out'],$d['break_out'],$d['break_in'],$d['status'],$d['remarks'],$d['scanner_location'],Auth::id(),$id]);activity('Attendance Corrected','attendance',$id,json_encode(['before'=>$old,'after'=>$d]));flash('success','Attendance correction saved.');redirect('attendance');}
        catch(\Throwable $e){flash('error',$e->getMessage());redirect('attendance/edit',['id'=>$id]);}
    }

    public function delete(): void
    {
        $this->admin();$this->csrf();$id=(int)($_POST['id']??0);Database::execute('DELETE FROM attendance WHERE id=?',[$id]);activity('Attendance Deleted','attendance',$id);flash('success','Attendance record deleted.');back();
    }

    public function markAbsences(): void
    {
        $this->admin();$this->csrf();$date=$_POST['date']??date('Y-m-d');try{$count=(new AttendanceService())->markAbsences($date);flash('success',"{$count} absent record(s) created for ".format_date($date).'.');}catch(\Throwable $e){flash('error',$e->getMessage());}back();
    }

    private function validateManual(): array
    {
        $person=(int)($_POST['person_id']??0);$date=$_POST['attendance_date']??'';$status=$_POST['status']??'';
        if(!$person||!Database::fetch('SELECT id FROM people WHERE id=?',[$person]))throw new RuntimeException('Choose a valid person.');if(!$date||strtotime($date)===false)throw new RuntimeException('Choose a valid date.');if(!in_array($status,['Present','Late','Absent','On Leave','Holiday','Half-Day'],true))throw new RuntimeException('Choose a valid attendance status.');
        foreach(['time_in','time_out','break_out','break_in'] as $field){$v=$_POST[$field]??'';if($v!==''&&!preg_match('/^\d{2}:\d{2}(:\d{2})?$/',$v))throw new RuntimeException('Invalid time value.');}
        return ['person_id'=>$person,'schedule_id'=>($_POST['schedule_id']??'')!==''?(int)$_POST['schedule_id']:null,'attendance_date'=>$date,'time_in'=>($_POST['time_in']??'')?:null,'time_out'=>($_POST['time_out']??'')?:null,'break_out'=>($_POST['break_out']??'')?:null,'break_in'=>($_POST['break_in']??'')?:null,'status'=>$status,'remarks'=>trim($_POST['remarks']??''),'scanner_location'=>trim($_POST['scanner_location']??'')];
    }
}
