<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;

final class AuthController extends BaseController
{
    public function loginForm(): void
    {
        if (Auth::check()) redirect('dashboard');
        view('auth/login', ['title'=>'Login'], false);
    }

    public function login(): void
    {
        $this->csrf();
        $login = trim($_POST['login'] ?? '');
        if (!Auth::attempt($login, $_POST['password'] ?? '')) {
            set_old(['login'=>$login]); flash('error','Invalid credentials or inactive account.'); redirect('login');
        }
        clear_old(); redirect('dashboard');
    }

    public function logout(): void { $this->auth(); $this->csrf(); Auth::logout(); redirect('login'); }

    public function forgotForm(): void { view('auth/forgot', ['title'=>'Forgot Password'], false); }

    public function forgot(): void
    {
        $this->csrf();
        $email = trim($_POST['email'] ?? '');
        $user = Database::fetch('SELECT id,email FROM users WHERE email=? AND status="Active" LIMIT 1', [$email]);
        if ($user) {
            $token = bin2hex(random_bytes(32));
            Database::execute('INSERT INTO password_resets (email,token_hash,expires_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 60 MINUTE))', [$email,hash('sha256',$token)]);
            $link = url('reset-password', ['token'=>$token,'email'=>$email]);
            $log = BASE_PATH . '/storage/logs/password-reset.log';
            file_put_contents($log, date('c') . " {$email} {$link}\n", FILE_APPEND);
            $subject = 'Password reset - ' . setting('organization_name', 'Universal Organization');
            $body = "A password reset was requested for your account.\n\nReset link: {$link}\n\nThis link expires in 60 minutes.";
            @mail($email, $subject, $body, 'Content-Type: text/plain; charset=UTF-8');
            if (config('env') !== 'production' || config('debug', false)) {
                $_SESSION['_reset_preview'] = $link;
            }
            activity('Password Reset Requested','users',(int)$user['id'],$email);
        }
        flash('success','If the account exists, a password reset link has been created. In local installations it is shown below and written to storage/logs/password-reset.log.');
        redirect('forgot-password');
    }

    public function resetForm(): void
    {
        view('auth/reset', ['title'=>'Reset Password','token'=>$_GET['token'] ?? '','email'=>$_GET['email'] ?? ''], false);
    }

    public function reset(): void
    {
        $this->csrf();
        $email = trim($_POST['email'] ?? '');
        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        if (strlen($password) < 8 || $password !== ($_POST['password_confirmation'] ?? '')) {
            flash('error','Passwords must match and contain at least 8 characters.');
            header('Location: ' . url('reset-password',['token'=>$token,'email'=>$email])); exit;
        }
        $row = Database::fetch('SELECT * FROM password_resets WHERE email=? AND token_hash=? AND used_at IS NULL AND expires_at>NOW() ORDER BY id DESC LIMIT 1', [$email,hash('sha256',$token)]);
        if (!$row) { flash('error','The reset link is invalid or expired.'); redirect('forgot-password'); }
        Database::execute('UPDATE users SET password=? WHERE email=?', [password_hash($password,PASSWORD_DEFAULT),$email]);
        Database::execute('UPDATE password_resets SET used_at=NOW() WHERE id=?', [$row['id']]);
        flash('success','Password reset successfully. You can now sign in.'); redirect('login');
    }

    public function profile(): void
    {
        $this->auth(); view('auth/profile', ['title'=>'My Profile','user'=>Auth::user()]);
    }

    public function updateProfile(): void
    {
        $this->auth(); $this->csrf();
        $name = trim($_POST['full_name'] ?? ''); $email = trim($_POST['email'] ?? '');
        if ($name === '' || !filter_var($email,FILTER_VALIDATE_EMAIL)) { flash('error','Enter a valid name and email.'); back(); }
        $existing = Database::fetch('SELECT id FROM users WHERE email=? AND id<>?',[$email,Auth::id()]);
        if ($existing) { flash('error','Email is already in use.'); back(); }
        $photo = Auth::user()['photo'];
        try { $uploaded = upload_file('photo','uploads/photos',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']); if ($uploaded) $photo=$uploaded; }
        catch (\Throwable $e) { flash('error',$e->getMessage()); back(); }
        Database::execute('UPDATE users SET full_name=?,email=?,phone=?,photo=? WHERE id=?',[$name,$email,trim($_POST['phone']??''),$photo,Auth::id()]);
        activity('Profile Updated','users',Auth::id(),$email); flash('success','Profile updated.'); redirect('profile');
    }

    public function changePassword(): void
    {
        $this->auth(); $this->csrf();
        $current = $_POST['current_password'] ?? ''; $new = $_POST['new_password'] ?? '';
        if (!password_verify($current,Auth::user()['password'])) { flash('error','Current password is incorrect.'); back(); }
        if (strlen($new)<8 || $new!==($_POST['new_password_confirmation']??'')) { flash('error','New passwords must match and contain at least 8 characters.'); back(); }
        Database::execute('UPDATE users SET password=? WHERE id=?',[password_hash($new,PASSWORD_DEFAULT),Auth::id()]);
        activity('Password Changed','users',Auth::id()); flash('success','Password changed successfully.'); redirect('profile');
    }
}
