<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Csrf;

abstract class BaseController
{
    protected function auth(): void { Auth::requireLogin(); }
    protected function admin(): void { Auth::requireRoles(['super-administrator','administrator']); }
    protected function superAdmin(): void { Auth::requireRoles(['super-administrator']); }
    protected function csrf(): void { Csrf::enforce(); }
    protected function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }
}
