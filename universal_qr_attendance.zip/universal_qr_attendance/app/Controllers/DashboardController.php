<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;

final class DashboardController extends BaseController
{
    public function index(): void
    {
        $this->auth(); $this->generateLowAttendanceAlerts(); $today=date('Y-m-d');
        $stats = [
            'people'=>(int)(Database::fetch('SELECT COUNT(*) c FROM people WHERE status="Active"')['c']??0),
            'present'=>(int)(Database::fetch('SELECT COUNT(*) c FROM attendance WHERE attendance_date=? AND status IN ("Present","Half-Day")',[$today])['c']??0),
            'late'=>(int)(Database::fetch('SELECT COUNT(*) c FROM attendance WHERE attendance_date=? AND status="Late"',[$today])['c']??0),
            'absent'=>(int)(Database::fetch('SELECT COUNT(*) c FROM attendance WHERE attendance_date=? AND status="Absent"',[$today])['c']??0),
            'time_in'=>(int)(Database::fetch('SELECT COUNT(*) c FROM attendance WHERE attendance_date=? AND time_in IS NOT NULL',[$today])['c']??0),
            'time_out'=>(int)(Database::fetch('SELECT COUNT(*) c FROM attendance WHERE attendance_date=? AND time_out IS NOT NULL',[$today])['c']??0),
        ];
        $recent=Database::fetchAll('SELECT a.*,p.person_id,p.full_name,p.photo,c.name category_name,d.name department_name FROM attendance a JOIN people p ON p.id=a.person_id JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id ORDER BY a.updated_at DESC LIMIT 10');
        $announcements=Database::fetchAll('SELECT * FROM announcements WHERE status="Active" AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW()) ORDER BY created_at DESC LIMIT 5');
        $chart=Database::fetchAll('SELECT attendance_date, SUM(status IN ("Present","Half-Day")) present_count, SUM(status="Late") late_count, SUM(status="Absent") absent_count FROM attendance WHERE attendance_date>=DATE_SUB(CURDATE(),INTERVAL 6 DAY) GROUP BY attendance_date ORDER BY attendance_date');
        view('dashboard/index',compact('stats','recent','announcements','chart')+['title'=>'Dashboard']);
    }
    private function generateLowAttendanceAlerts(): void
    {
        $threshold = max(1, min(100, (int)setting('low_attendance_threshold', 75)));
        $rows = Database::fetchAll('SELECT p.id,p.person_id,p.full_name,COUNT(a.id) total_records,SUM(a.status IN ("Present","Late","Half-Day")) attended_records FROM people p JOIN attendance a ON a.person_id=p.id AND a.attendance_date>=DATE_SUB(CURDATE(),INTERVAL 30 DAY) AND a.status<>"Holiday" WHERE p.status="Active" GROUP BY p.id,p.person_id,p.full_name HAVING COUNT(a.id)>=5');
        foreach ($rows as $row) {
            $rate = (int)round(((int)$row['attended_records'] / max(1,(int)$row['total_records'])) * 100);
            if ($rate >= $threshold) continue;
            $title = 'Low Attendance Alert: ' . $row['person_id'];
            $exists = Database::fetch('SELECT id FROM notifications WHERE user_id=? AND title=? AND DATE(created_at)=CURDATE() LIMIT 1', [\App\Core\Auth::id(), $title]);
            if (!$exists) notify_user(\App\Core\Auth::id(), 'warning', $title, $row['full_name'] . ' has a 30-day attendance rate of ' . $rate . '%.', 'reports');
        }
    }

}
