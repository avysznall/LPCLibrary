<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Csrf;
use App\Services\AttendanceService;

final class KioskController extends BaseController
{
    public function index(): void
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Frame-Options: SAMEORIGIN');

        $enabled = setting('public_kiosk_enabled', '1') === '1';
        $authorized = $enabled && $this->authorizeFromRequest();

        view('kiosk/index', [
            'title' => trim((string) setting('kiosk_title', 'Attendance Kiosk')) ?: 'Attendance Kiosk',
            'enabled' => $enabled,
            'authorized' => $authorized,
            'organization' => setting('organization_name', 'Universal Organization'),
            'logo' => setting('organization_logo', ''),
            'location' => trim((string) setting('kiosk_location', 'Main Entrance')) ?: 'Main Entrance',
            'autoStart' => setting('kiosk_auto_start', '1') === '1',
            'confirmationSeconds' => max(3, min(20, (int) setting('kiosk_confirmation_seconds', '5'))),
        ], false);
    }

    public function scanApi(): void
    {
        header('Cache-Control: no-store');

        if (setting('public_kiosk_enabled', '1') !== '1') {
            $this->json(['success' => false, 'message' => 'The public attendance kiosk is currently disabled.'], 403);
        }
        if (!$this->isAuthorized()) {
            $this->json(['success' => false, 'message' => 'This kiosk link is not authorized.'], 403);
        }

        $payload = json_decode(file_get_contents('php://input'), true) ?: [];
        if (!Csrf::verify($payload['_token'] ?? null)) {
            $this->json(['success' => false, 'message' => 'Security token mismatch. Refresh the kiosk page.'], 419);
        }

        $token = trim((string) ($payload['token'] ?? ''));
        if ($token === '') {
            $this->json(['success' => false, 'message' => 'No QR code was detected.'], 422);
        }
        if (strlen($token) > 300) {
            $this->json(['success' => false, 'message' => 'The scanned QR content is not valid.'], 422);
        }

        $this->enforceRateLimit($token);

        try {
            $result = (new AttendanceService())->scan(
                $token,
                'auto',
                trim((string) setting('kiosk_location', 'Main Entrance')) ?: 'Main Entrance',
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
                'Public Attendance Kiosk'
            );
            $this->json(['success' => true] + $result);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    private function authorizeFromRequest(): bool
    {
        $requiredKey = trim((string) setting('kiosk_access_key', ''));
        if ($requiredKey === '') {
            $_SESSION['_kiosk_authorized'] = 'public';
            return true;
        }

        $requiredHash = hash('sha256', $requiredKey);
        $providedKey = trim((string) ($_GET['key'] ?? ''));
        if ($providedKey !== '' && hash_equals($requiredKey, $providedKey)) {
            $_SESSION['_kiosk_authorized'] = $requiredHash;
            return true;
        }

        return hash_equals($requiredHash, (string) ($_SESSION['_kiosk_authorized'] ?? ''));
    }

    private function isAuthorized(): bool
    {
        $requiredKey = trim((string) setting('kiosk_access_key', ''));
        if ($requiredKey === '') {
            return true;
        }
        return hash_equals(hash('sha256', $requiredKey), (string) ($_SESSION['_kiosk_authorized'] ?? ''));
    }

    private function enforceRateLimit(string $token): void
    {
        $now = microtime(true);
        $attempts = array_values(array_filter(
            $_SESSION['_kiosk_scan_attempts'] ?? [],
            static fn ($time): bool => is_numeric($time) && (float) $time > $now - 60
        ));

        if (count($attempts) >= 120) {
            $this->json(['success' => false, 'message' => 'Too many scan attempts. Please pause briefly and try again.'], 429);
        }

        $hash = hash('sha256', $token);
        $last = $_SESSION['_kiosk_last_scan'] ?? null;
        if (is_array($last) && ($last['hash'] ?? '') === $hash && ($now - (float) ($last['time'] ?? 0)) < 10) {
            $this->json(['success' => false, 'message' => 'This QR code was just scanned. Please wait before trying again.'], 429);
        }

        $attempts[] = $now;
        $_SESSION['_kiosk_scan_attempts'] = $attempts;
        $_SESSION['_kiosk_last_scan'] = ['hash' => $hash, 'time' => $now];
    }
}
