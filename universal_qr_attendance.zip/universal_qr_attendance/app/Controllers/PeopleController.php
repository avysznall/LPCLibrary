<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Services\QrService;
use RuntimeException;

final class PeopleController extends BaseController
{
    public function index(): void
    {
        $this->auth();
        $q=trim($_GET['q']??''); $category=(int)($_GET['category_id']??0); $department=(int)($_GET['department_id']??0); $status=trim($_GET['status']??'');
        $where=['1=1']; $params=[];
        if($q!==''){ $where[]='(p.full_name LIKE ? OR p.person_id LIKE ? OR p.email LIKE ?)'; $like="%{$q}%"; array_push($params,$like,$like,$like); }
        if($category){$where[]='p.category_id=?';$params[]=$category;} if($department){$where[]='p.department_id=?';$params[]=$department;} if(in_array($status,['Active','Inactive'],true)){$where[]='p.status=?';$params[]=$status;}
        $sqlWhere=implode(' AND ',$where); $count=Database::fetch("SELECT COUNT(*) c FROM people p WHERE {$sqlWhere}",$params); $p=paginate((int)$count['c'],10);
        $people=Database::fetchAll("SELECT p.*,c.name category_name,d.name department_name,s.name schedule_name FROM people p JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id LEFT JOIN attendance_schedules s ON s.id=p.schedule_id WHERE {$sqlWhere} ORDER BY p.created_at DESC LIMIT {$p['per_page']} OFFSET {$p['offset']}",$params);
        $categories=Database::fetchAll('SELECT * FROM categories WHERE status="Active" ORDER BY name'); $departments=Database::fetchAll('SELECT * FROM departments WHERE status="Active" ORDER BY name');
        view('people/index',compact('people','categories','departments','p')+['title'=>'People']);
    }

    public function create(): void
    {
        $this->admin(); $this->formView(null);
    }

    public function store(): void
    {
        $this->admin(); $this->csrf();
        try {
            $data=$this->validated(); $photo=$this->photo(); $personId=$this->nextPersonId(); $token=bin2hex(random_bytes(32));
            $id=Database::insert('INSERT INTO people (person_id,qr_token,category_id,department_id,schedule_id,full_name,photo,gender,birthdate,contact_number,email,address,position_role,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[
                $personId,$token,$data['category_id'],$data['department_id'],$data['schedule_id'],$data['full_name'],$photo,$data['gender'],$data['birthdate'],$data['contact_number'],$data['email'],$data['address'],$data['position_role'],$data['status'],Auth::id()
            ]);
            (new QrService())->generateForPerson($id);
            activity('Person Created','people',$id,$personId.' '.$data['full_name']); flash('success','Person registered and QR code generated.'); redirect('people/show',['id'=>$id]);
        } catch(\Throwable $e){ set_old($_POST); flash('error',$e->getMessage()); redirect('people/create'); }
    }

    public function show(): void
    {
        $this->auth(); $id=(int)($_GET['id']??0);
        $person=Database::fetch('SELECT p.*,c.name category_name,d.name department_name,s.name schedule_name FROM people p JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id LEFT JOIN attendance_schedules s ON s.id=p.schedule_id WHERE p.id=?',[$id]);
        if(!$person){http_response_code(404);view('errors/404',['title'=>'Person Not Found']);return;}
        $history=Database::fetchAll('SELECT a.*,s.name schedule_name FROM attendance a LEFT JOIN attendance_schedules s ON s.id=a.schedule_id WHERE a.person_id=? ORDER BY a.attendance_date DESC LIMIT 15',[$id]);
        view('people/show',compact('person','history')+['title'=>$person['full_name']]);
    }

    public function edit(): void
    {
        $this->admin(); $person=Database::fetch('SELECT * FROM people WHERE id=?',[(int)($_GET['id']??0)]); if(!$person){flash('error','Person not found.');redirect('people');} $this->formView($person);
    }

    public function update(): void
    {
        $this->admin(); $this->csrf(); $id=(int)($_POST['id']??0); $person=Database::fetch('SELECT * FROM people WHERE id=?',[$id]); if(!$person){flash('error','Person not found.');redirect('people');}
        try{
            $d=$this->validated(); $photo=$this->photo() ?: $person['photo'];
            Database::execute('UPDATE people SET category_id=?,department_id=?,schedule_id=?,full_name=?,photo=?,gender=?,birthdate=?,contact_number=?,email=?,address=?,position_role=?,status=? WHERE id=?',[$d['category_id'],$d['department_id'],$d['schedule_id'],$d['full_name'],$photo,$d['gender'],$d['birthdate'],$d['contact_number'],$d['email'],$d['address'],$d['position_role'],$d['status'],$id]);
            activity('Person Updated','people',$id,$person['person_id']); clear_old(); flash('success','Person updated successfully.'); redirect('people/show',['id'=>$id]);
        }catch(\Throwable $e){set_old($_POST);flash('error',$e->getMessage());redirect('people/edit',['id'=>$id]);}
    }

    public function archive(): void
    {
        $this->admin();$this->csrf();$id=(int)($_POST['id']??0);Database::execute('UPDATE people SET status=IF(status="Active","Inactive","Active") WHERE id=?',[$id]);activity('Person Status Changed','people',$id);flash('success','Person status updated.');back();
    }

    private function formView(?array $person): void
    {
        $categories=Database::fetchAll('SELECT * FROM categories WHERE status="Active" ORDER BY name');$departments=Database::fetchAll('SELECT * FROM departments WHERE status="Active" ORDER BY name');$schedules=Database::fetchAll('SELECT * FROM attendance_schedules WHERE status="Active" ORDER BY name');
        view('people/form',compact('person','categories','departments','schedules')+['title'=>$person?'Edit Person':'Register Person']);
    }

    private function validated(): array
    {
        $full=trim($_POST['full_name']??'');$category=(int)($_POST['category_id']??0);if($full===''||!Database::fetch('SELECT id FROM categories WHERE id=?',[$category]))throw new RuntimeException('Full name and a valid category are required.');
        $email=trim($_POST['email']??'');if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Enter a valid email address.');
        $gender=$_POST['gender']??null;if($gender!==''&&!in_array($gender,['Male','Female','Other','Prefer not to say'],true))throw new RuntimeException('Invalid gender.');
        $status=in_array($_POST['status']??'Active',['Active','Inactive'],true)?$_POST['status']:'Active';
        return ['full_name'=>$full,'category_id'=>$category,'department_id'=>($_POST['department_id']??'')!==''?(int)$_POST['department_id']:null,'schedule_id'=>($_POST['schedule_id']??'')!==''?(int)$_POST['schedule_id']:null,'gender'=>$gender?:null,'birthdate'=>($_POST['birthdate']??'')?:null,'contact_number'=>trim($_POST['contact_number']??''),'email'=>$email?:null,'address'=>trim($_POST['address']??''),'position_role'=>trim($_POST['position_role']??''),'status'=>$status];
    }

    private function photo(): ?string
    {
        return upload_file('photo','uploads/photos',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']);
    }

    private function nextPersonId(): string
    {
        $prefix=preg_replace('/[^A-Z0-9]/','',strtoupper((string)setting('person_id_prefix','PER')))?:'PER';$digits=max(3,min(10,(int)setting('person_id_digits',6)));
        $row=Database::fetch('SELECT id FROM people ORDER BY id DESC LIMIT 1');$next=(int)($row['id']??0)+1;return $prefix.str_pad((string)$next,$digits,'0',STR_PAD_LEFT);
    }
}
