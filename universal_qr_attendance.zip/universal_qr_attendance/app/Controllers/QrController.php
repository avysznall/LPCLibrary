<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Services\QrService;

final class QrController extends BaseController
{
    public function regenerate(): void
    {
        $this->admin();$this->csrf();$id=(int)($_POST['id']??0);
        try{(new QrService())->generateForPerson($id,true);flash('success','QR code regenerated. The previous QR code is now invalid.');}
        catch(\Throwable $e){flash('error',$e->getMessage());}redirect('people/show',['id'=>$id]);
    }

    public function bulkGenerate(): void
    {
        $this->admin(); $this->csrf();
        $regenerate = ($_POST['regenerate_all'] ?? '0') === '1';
        $people = Database::fetchAll('SELECT id,person_id,qr_image FROM people WHERE status="Active" ORDER BY id');
        $service = new QrService(); $generated = 0; $skipped = 0; $failed = 0;
        foreach ($people as $person) {
            $hasImage = !empty($person['qr_image']) && is_file(PUBLIC_PATH . '/' . $person['qr_image']);
            if (!$regenerate && $hasImage) { $skipped++; continue; }
            try { $service->generateForPerson((int)$person['id'], $regenerate); $generated++; }
            catch (\Throwable) { $failed++; }
        }
        activity($regenerate ? 'Bulk QR Regeneration' : 'Bulk QR Generation', 'qr_codes', null, "Generated {$generated}, skipped {$skipped}, failed {$failed}");
        $message = "{$generated} QR code(s) generated" . ($skipped ? ", {$skipped} already valid" : '') . ($failed ? ", {$failed} failed" : '') . '.';
        flash($failed ? 'error' : 'success', $message);
        redirect('people');
    }

    public function bulk(): void
    {
        $this->admin();$ids=array_map('intval',$_GET['ids']??[]);$where=$ids?'WHERE p.id IN ('.implode(',',$ids).')':'WHERE p.status="Active"';
        $people=Database::fetchAll("SELECT p.*,c.name category_name,d.name department_name FROM people p JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id {$where} ORDER BY p.full_name");
        view('qr/bulk',compact('people')+['title'=>'Bulk QR Cards']);
    }

    public function download(): void
    {
        $this->auth();$person=Database::fetch('SELECT * FROM people WHERE id=?',[(int)($_GET['id']??0)]);if(!$person||!$person['qr_image']||!is_file(PUBLIC_PATH.'/'.$person['qr_image'])){flash('error','QR image not found.');back();}
        activity('QR Downloaded','people',(int)$person['id'],$person['person_id']);header('Content-Type:image/png');header('Content-Disposition:attachment; filename="'.$person['person_id'].'-qr.png"');readfile(PUBLIC_PATH.'/'.$person['qr_image']);exit;
    }
}
