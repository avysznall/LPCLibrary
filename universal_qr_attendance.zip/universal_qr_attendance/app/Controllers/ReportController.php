<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use Dompdf\Dompdf;
use Dompdf\Options;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use RuntimeException;

final class ReportController extends BaseController
{
    public function index(): void
    {
        $this->auth();[$rows,$filters]=$this->data(false);$summary=['total'=>count($rows),'present'=>0,'late'=>0,'absent'=>0,'leave'=>0];foreach($rows as $r){if(in_array($r['status'],['Present','Half-Day'],true))$summary['present']++;elseif($r['status']==='Late')$summary['late']++;elseif($r['status']==='Absent')$summary['absent']++;elseif($r['status']==='On Leave')$summary['leave']++;}
        $categories=Database::fetchAll('SELECT * FROM categories ORDER BY name');$departments=Database::fetchAll('SELECT * FROM departments ORDER BY name');$people=Database::fetchAll('SELECT id,person_id,full_name FROM people ORDER BY full_name');
        view('reports/index',compact('rows','filters','summary','categories','departments','people')+['title'=>'Attendance Reports']);
    }

    public function export(): void
    {
        $this->auth();[$rows,$filters]=$this->data(false);$format=$_GET['format']??'csv';$name='attendance-report-'.date('Ymd-His');activity('Report Generated','reports',null,strtoupper($format).' '.json_encode($filters));
        if($format==='csv'){$this->csv($rows,$name);}
        if($format==='xlsx'){$this->xlsx($rows,$name);}
        if($format==='pdf'){$this->pdf($rows,$name,$filters);}
        if($format==='print'){view('reports/print',compact('rows','filters')+['title'=>'Attendance Report'],false);return;}
        throw new RuntimeException('Unsupported export format.');
    }

    private function data(bool $limit=false): array
    {
        $type=$_GET['type']??'daily';$from=$_GET['from']??date('Y-m-d');$to=$_GET['to']??date('Y-m-d');
        if($type==='weekly'&&!isset($_GET['from'])){$from=date('Y-m-d',strtotime('monday this week'));$to=date('Y-m-d',strtotime('sunday this week'));}
        elseif($type==='monthly'&&!isset($_GET['from'])){$from=date('Y-m-01');$to=date('Y-m-t');}
        elseif($type==='yearly'&&!isset($_GET['from'])){$from=date('Y-01-01');$to=date('Y-12-31');}
        $where=['a.attendance_date BETWEEN ? AND ?'];$params=[$from,$to];
        $person=(int)($_GET['person_id']??0);$category=(int)($_GET['category_id']??0);$department=(int)($_GET['department_id']??0);$status=trim($_GET['status']??'');$q=trim($_GET['q']??'');
        if($type==='late')$status='Late';if($type==='absent')$status='Absent';
        if($person){$where[]='p.id=?';$params[]=$person;}if($category){$where[]='p.category_id=?';$params[]=$category;}if($department){$where[]='p.department_id=?';$params[]=$department;}if(in_array($status,['Present','Late','Absent','On Leave','Holiday','Half-Day'],true)){$where[]='a.status=?';$params[]=$status;}if($q!==''){$where[]='(p.full_name LIKE ? OR p.person_id LIKE ?)';$params[]="%{$q}%";$params[]="%{$q}%";}
        $sql='SELECT a.*,p.person_id AS person_code,p.full_name,c.name category_name,d.name department_name,s.name schedule_name FROM attendance a JOIN people p ON p.id=a.person_id JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id LEFT JOIN attendance_schedules s ON s.id=a.schedule_id WHERE '.implode(' AND ',$where).' ORDER BY a.attendance_date DESC,p.full_name';
        if($limit)$sql.=' LIMIT 500';
        return [Database::fetchAll($sql,$params),compact('type','from','to','person','category','department','status','q')];
    }

    private function headers(): array{return ['QR / Person ID','Name','Category','Department','Schedule','Date','Time In','Time Out','Break Out','Break In','Status','Remarks'];}
    private function row(array $r): array{return [$r['person_code'],$r['full_name'],$r['category_name'],$r['department_name']?:'—',$r['schedule_name']?:'—',$r['attendance_date'],$r['time_in'],$r['time_out'],$r['break_out'],$r['break_in'],$r['status'],$r['remarks']];}

    private function csv(array $rows,string $name): never
    {
        header('Content-Type:text/csv; charset=utf-8');header("Content-Disposition:attachment; filename={$name}.csv");$out=fopen('php://output','w');fputcsv($out,$this->headers());foreach($rows as $r)fputcsv($out,$this->row($r));fclose($out);exit;
    }

    private function xlsx(array $rows,string $name): never
    {
        if(!class_exists(Spreadsheet::class))throw new RuntimeException('PhpSpreadsheet is not installed. Run composer install.');$sheet=(new Spreadsheet())->getActiveSheet();$sheet->setTitle('Attendance');$sheet->fromArray($this->headers(),null,'A1');$index=2;foreach($rows as $r)$sheet->fromArray($this->row($r),null,'A'.$index++);foreach(range('A','L') as $col)$sheet->getColumnDimension($col)->setAutoSize(true);$sheet->getStyle('A1:L1')->getFont()->setBold(true);$writer=new Xlsx($sheet->getParent());header('Content-Type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header("Content-Disposition:attachment; filename={$name}.xlsx");$writer->save('php://output');exit;
    }

    private function pdf(array $rows,string $name,array $filters): never
    {
        if(!class_exists(Dompdf::class))throw new RuntimeException('Dompdf is not installed. Run composer install.');ob_start();$title='Attendance Report';include BASE_PATH.'/app/Views/reports/pdf.php';$html=ob_get_clean();$options=new Options();$options->set('defaultFont','DejaVu Sans');$options->set('isRemoteEnabled',true);$pdf=new Dompdf($options);$pdf->loadHtml($html);$pdf->setPaper('A4','landscape');$pdf->render();$pdf->stream($name.'.pdf',['Attachment'=>true]);exit;
    }
}
