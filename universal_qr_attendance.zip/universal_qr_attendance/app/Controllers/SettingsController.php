<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Services\BackupService;

final class SettingsController extends BaseController
{
    public function index(): void
    {
        $this->superAdmin();$settings=[];foreach(Database::fetchAll('SELECT * FROM settings') as $row)$settings[$row['key']]=$row['value'];$backups=array_map('basename',glob(PUBLIC_PATH.'/backups/*.sql')?:[]);rsort($backups);view('settings/index',compact('settings','backups')+['title'=>'System Settings']);
    }
    public function update(): void
    {
        $this->superAdmin();$this->csrf();$allowed=['organization_name'=>'general','timezone'=>'general','person_id_prefix'=>'people','person_id_digits'=>'people','late_default_minutes'=>'attendance','low_attendance_threshold'=>'attendance','allow_holiday_scan'=>'attendance','qr_size'=>'qr','qr_prefix'=>'qr','scanner_success_sound'=>'qr','public_kiosk_enabled'=>'kiosk','kiosk_title'=>'kiosk','kiosk_location'=>'kiosk','kiosk_auto_start'=>'kiosk','kiosk_confirmation_seconds'=>'kiosk','kiosk_access_key'=>'kiosk'];
        foreach($allowed as $key=>$group){$value=trim((string)($_POST[$key]??''));Database::execute('INSERT INTO settings (`key`,`value`,group_name) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`),group_name=VALUES(group_name)',[$key,$value,$group]);}
        try{$logo=upload_file('organization_logo','uploads/logos',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'],5242880);if($logo)Database::execute('INSERT INTO settings (`key`,`value`,group_name) VALUES (?,?,"general") ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)', ['organization_logo',$logo]);}catch(\Throwable $e){flash('error',$e->getMessage());redirect('settings');}
        activity('System Settings Updated','settings');flash('success','Settings saved. Sign in again if the time zone was changed.');redirect('settings');
    }
    public function backup(): void
    {
        $this->superAdmin();$this->csrf();try{$file=(new BackupService())->create();flash('success',"Backup created: {$file}");}catch(\Throwable $e){flash('error',$e->getMessage());}redirect('settings');
    }
    public function downloadBackup(): void
    {
        $this->superAdmin();$name=basename($_GET['file']??'');$file=PUBLIC_PATH.'/backups/'.$name;if(!$name||!is_file($file)){flash('error','Backup not found.');redirect('settings');}header('Content-Type:application/sql');header('Content-Disposition:attachment; filename="'.$name.'"');readfile($file);exit;
    }
    public function restore(): void
    {
        $this->superAdmin();$this->csrf();if(empty($_FILES['backup']['name'])||strtolower(pathinfo($_FILES['backup']['name'],PATHINFO_EXTENSION))!=='sql'){flash('error','Upload a valid .sql backup file.');redirect('settings');}try{(new BackupService())->restore($_FILES['backup']['tmp_name']);flash('success','Database restored successfully. You may need to sign in again.');}catch(\Throwable $e){flash('error',$e->getMessage());}redirect('settings');
    }
}
