<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use RuntimeException;

final class UserController extends BaseController
{
    public function index(): void
    {
        $this->admin();$users=Database::fetchAll('SELECT u.*,r.name role_name,r.slug role_slug FROM users u JOIN roles r ON r.id=u.role_id ORDER BY u.created_at DESC');$roles=Database::fetchAll('SELECT * FROM roles ORDER BY id');view('users/index',compact('users','roles')+['title'=>'System Users']);
    }
    public function save(): void
    {
        $this->admin();$this->csrf();$id=(int)($_POST['id']??0);$name=trim($_POST['full_name']??'');$username=trim($_POST['username']??'');$email=trim($_POST['email']??'');$role=(int)($_POST['role_id']??0);$status=in_array($_POST['status']??'Active',['Active','Inactive'],true)?$_POST['status']:'Active';
        if($name===''||$username===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||!Database::fetch('SELECT id FROM roles WHERE id=?',[$role])){flash('error','Complete all required user fields.');back();}
        if(Auth::role()!=='super-administrator'){$targetRole=Database::fetch('SELECT slug FROM roles WHERE id=?',[$role]);if(($targetRole['slug']??'')==='super-administrator'){flash('error','Only a Super Administrator can assign that role.');back();}}
        $duplicate=Database::fetch('SELECT id FROM users WHERE (email=? OR username=?) AND id<>?',[$email,$username,$id]);if($duplicate){flash('error','Username or email already exists.');back();}
        try{$photo=upload_file('photo','uploads/photos',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']);if($id){$user=Database::fetch('SELECT * FROM users WHERE id=?',[$id]);if(!$user)throw new RuntimeException('User not found.');if($id===Auth::id()&&$status==='Inactive')throw new RuntimeException('You cannot deactivate your own account.');$photo=$photo?:$user['photo'];$sql='UPDATE users SET role_id=?,full_name=?,username=?,email=?,phone=?,photo=?,status=?';$params=[$role,$name,$username,$email,trim($_POST['phone']??''),$photo,$status];if(!empty($_POST['password'])){if(strlen($_POST['password'])<8)throw new RuntimeException('Password must contain at least 8 characters.');$sql.=',password=?';$params[]=password_hash($_POST['password'],PASSWORD_DEFAULT);}$sql.=' WHERE id=?';$params[]=$id;Database::execute($sql,$params);}else{if(strlen($_POST['password']??'')<8)throw new RuntimeException('A password of at least 8 characters is required.');$id=Database::insert('INSERT INTO users (role_id,full_name,username,email,phone,photo,password,status) VALUES (?,?,?,?,?,?,?,?)',[$role,$name,$username,$email,trim($_POST['phone']??''),$photo,password_hash($_POST['password'],PASSWORD_DEFAULT),$status]);}activity('User Saved','users',$id,$username);flash('success','User account saved.');redirect('users');}catch(\Throwable $e){flash('error',$e->getMessage());back();}
    }
    public function delete(): void
    {
        $this->superAdmin();$this->csrf();$id=(int)($_POST['id']??0);if($id===Auth::id()){flash('error','You cannot delete your own account.');back();}$role=Database::fetch('SELECT r.slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?',[$id]);if(($role['slug']??'')==='super-administrator'){$count=Database::fetch('SELECT COUNT(*) c FROM users u JOIN roles r ON r.id=u.role_id WHERE r.slug="super-administrator"');if((int)$count['c']<=1){flash('error','At least one Super Administrator must remain.');back();}}Database::execute('DELETE FROM users WHERE id=?',[$id]);activity('User Deleted','users',$id);flash('success','User deleted.');back();
    }
}
