<?php
declare(strict_types=1);

namespace App\Core;

final class Auth
{
    private static ?array $user = null;

    public static function boot(): void
    {
        if (!empty($_SESSION['user_id'])) {
            self::$user = Database::fetch(
                'SELECT u.*, r.name AS role_name, r.slug AS role_slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=? AND u.status="Active" LIMIT 1',
                [(int)$_SESSION['user_id']]
            );
            if (!self::$user) {
                unset($_SESSION['user_id']);
            }
        }
    }

    public static function attempt(string $login, string $password): bool
    {
        $user = Database::fetch(
            'SELECT u.*, r.name AS role_name, r.slug AS role_slug FROM users u JOIN roles r ON r.id=u.role_id WHERE (u.email=? OR u.username=?) AND u.status="Active" LIMIT 1',
            [$login, $login]
        );
        if (!$user || !password_verify($password, $user['password'])) {
            return false;
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        self::$user = $user;
        Database::execute('UPDATE users SET last_login=NOW() WHERE id=?', [$user['id']]);
        activity('Login', 'users', (int)$user['id'], 'Successful login');
        return true;
    }

    public static function logout(): void
    {
        if (self::$user) {
            activity('Logout', 'users', (int)self::$user['id'], 'User logged out');
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        self::$user = null;
    }

    public static function check(): bool { return self::$user !== null; }
    public static function user(): ?array { return self::$user; }
    public static function id(): ?int { return self::$user ? (int)self::$user['id'] : null; }
    public static function role(): ?string { return self::$user['role_slug'] ?? null; }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            flash('error', 'Please sign in to continue.');
            redirect('login');
        }
    }

    public static function requireRoles(array $roles): void
    {
        self::requireLogin();
        if (!in_array(self::role(), $roles, true)) {
            http_response_code(403);
            view('errors/403', ['title' => 'Access Denied']);
            exit;
        }
    }

    public static function isAdmin(): bool
    {
        return in_array(self::role(), ['super-administrator', 'administrator'], true);
    }
}
