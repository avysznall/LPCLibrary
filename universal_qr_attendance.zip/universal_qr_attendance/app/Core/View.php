<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    public static function render(string $template, array $data = [], bool $layout = true): void
    {
        extract($data, EXTR_SKIP);
        $file = BASE_PATH . '/app/Views/' . $template . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException("View not found: {$template}");
        }
        if (!$layout) {
            require $file;
            return;
        }
        require BASE_PATH . '/app/Views/layouts/header.php';
        require $file;
        require BASE_PATH . '/app/Views/layouts/footer.php';
    }
}
