<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use DateTimeImmutable;
use RuntimeException;

final class AttendanceService
{
    public function resolveSchedule(array $person, ?string $date = null): ?array
    {
        $dateObj = new DateTimeImmutable($date ?: 'today');
        $day = strtolower($dateObj->format('l'));
        $candidates = [];

        $direct = Database::fetch('SELECT s.* FROM attendance_schedules s JOIN schedule_people sp ON sp.schedule_id=s.id WHERE sp.person_id=? AND s.status="Active" ORDER BY s.id DESC LIMIT 1', [$person['id']]);
        if ($direct) $candidates[] = $direct;
        if (!empty($person['schedule_id'])) {
            $row = Database::fetch('SELECT * FROM attendance_schedules WHERE id=? AND status="Active"', [$person['schedule_id']]);
            if ($row) $candidates[] = $row;
        }
        if (!empty($person['department_id'])) {
            $row = Database::fetch('SELECT s.* FROM attendance_schedules s JOIN schedule_departments sd ON sd.schedule_id=s.id WHERE sd.department_id=? AND s.status="Active" ORDER BY s.id DESC LIMIT 1', [$person['department_id']]);
            if ($row) $candidates[] = $row;
        }
        $row = Database::fetch('SELECT s.* FROM attendance_schedules s JOIN schedule_categories sc ON sc.schedule_id=s.id WHERE sc.category_id=? AND s.status="Active" ORDER BY s.id DESC LIMIT 1', [$person['category_id']]);
        if ($row) $candidates[] = $row;

        foreach ($candidates as $schedule) {
            $days = json_decode($schedule['days_available'] ?? '[]', true) ?: [];
            if (in_array($day, array_map('strtolower', $days), true)) return $schedule;
        }
        return null;
    }

    public function scan(string $rawToken, string $action = 'auto', ?string $location = null, ?string $device = null, string $source = 'Authenticated Scanner'): array
    {
        $prefix = (string)setting('qr_prefix', 'UQAMS:');
        $token = str_starts_with($rawToken, $prefix) ? substr($rawToken, strlen($prefix)) : $rawToken;
        $person = Database::fetch(
            'SELECT p.*, c.name AS category_name, d.name AS department_name FROM people p JOIN categories c ON c.id=p.category_id LEFT JOIN departments d ON d.id=p.department_id WHERE p.qr_token=? LIMIT 1',
            [$token]
        );
        if (!$person) throw new RuntimeException('Invalid or unknown QR code.');
        if ($person['status'] !== 'Active') throw new RuntimeException('This person is inactive.');

        $activeQr = Database::fetch('SELECT id FROM qr_codes WHERE person_id=? AND token=? AND is_active=1 LIMIT 1', [$person['id'],$token]);
        if (!$activeQr) throw new RuntimeException('This QR code has been replaced or disabled.');

        $today = date('Y-m-d');
        $holiday = Database::fetch('SELECT * FROM holidays WHERE holiday_date=? LIMIT 1', [$today]);
        if ($holiday && setting('allow_holiday_scan', '0') !== '1') {
            throw new RuntimeException('Attendance is closed for holiday: ' . $holiday['name']);
        }

        $schedule = $this->resolveSchedule($person, $today);
        if (!$schedule) throw new RuntimeException('No active attendance schedule is assigned for today.');

        $now = new DateTimeImmutable('now');
        $start = new DateTimeImmutable($today . ' ' . $schedule['start_time']);
        $end = new DateTimeImmutable($today . ' ' . $schedule['end_time']);
        if ($end <= $start) $end = $end->modify('+1 day');
        $windowStart = $start->modify('-' . (int)$schedule['scan_before_minutes'] . ' minutes');
        $windowEnd = $end->modify('+' . (int)$schedule['scan_after_minutes'] . ' minutes');
        if ($now < $windowStart || $now > $windowEnd) throw new RuntimeException('Scan is outside the allowed attendance window.');

        $record = Database::fetch('SELECT * FROM attendance WHERE person_id=? AND attendance_date=? AND schedule_id=? LIMIT 1', [$person['id'],$today,$schedule['id']]);
        $actualAction = $action;
        if ($action === 'auto') {
            if (!$record || !$record['time_in']) $actualAction = 'time_in';
            elseif (!$record['time_out']) $actualAction = 'time_out';
            else throw new RuntimeException('Attendance is already completed for today.');
        }

        $time = $now->format('H:i:s');
        $status = 'Present';
        $message = '';
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            if ($actualAction === 'time_in') {
                if ($record && $record['time_in']) throw new RuntimeException('Time In has already been recorded.');
                $lateAt = $start->modify('+' . (int)$schedule['late_threshold_minutes'] . ' minutes');
                $status = $now > $lateAt ? 'Late' : 'Present';
                if ($record) {
                    Database::execute('UPDATE attendance SET time_in=?, status=?, scanner_location=?, device_info=?, updated_by=? WHERE id=?', [$time,$status,$location,$device,Auth::id(),$record['id']]);
                } else {
                    Database::execute('INSERT INTO attendance (person_id,schedule_id,attendance_date,time_in,status,scanner_location,device_info,created_by,updated_by) VALUES (?,?,?,?,?,?,?,?,?)', [$person['id'],$schedule['id'],$today,$time,$status,$location,$device,Auth::id(),Auth::id()]);
                }
                $message = 'Time In recorded successfully.';
            } elseif ($actualAction === 'time_out') {
                if (!$record || !$record['time_in']) throw new RuntimeException('Record Time In before Time Out.');
                if ($record['time_out']) throw new RuntimeException('Time Out has already been recorded.');
                Database::execute('UPDATE attendance SET time_out=?, scanner_location=COALESCE(scanner_location,?), device_info=COALESCE(device_info,?), updated_by=? WHERE id=?', [$time,$location,$device,Auth::id(),$record['id']]);
                $status = $record['status']; $message = 'Time Out recorded successfully.';
            } elseif ($actualAction === 'break_out') {
                if (!$record || !$record['time_in']) throw new RuntimeException('Record Time In before starting a break.');
                if ($record['break_out'] && !$record['break_in']) throw new RuntimeException('A break is already active.');
                Database::execute('UPDATE attendance SET break_out=?, break_in=NULL, updated_by=? WHERE id=?', [$time,Auth::id(),$record['id']]);
                $status = $record['status']; $message = 'Break Out recorded successfully.';
            } elseif ($actualAction === 'break_in') {
                if (!$record || !$record['break_out']) throw new RuntimeException('No active break was found.');
                if ($record['break_in']) throw new RuntimeException('Break In has already been recorded.');
                Database::execute('UPDATE attendance SET break_in=?, updated_by=? WHERE id=?', [$time,Auth::id(),$record['id']]);
                $status = $record['status']; $message = 'Break In recorded successfully.';
            } else {
                throw new RuntimeException('Unsupported attendance action.');
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }

        activity(
            'Attendance Scan: ' . ucwords(str_replace('_',' ',$actualAction)),
            'attendance',
            (int) $person['id'],
            $source . ' | ' . $person['person_id'] . ($location ? ' | ' . $location : '')
        );
        if (Auth::id() !== null) {
            notify_user(Auth::id(), 'success', 'Attendance Recorded', $person['full_name'] . ': ' . $message . ' at ' . $now->format('h:i A'), 'attendance');
        }
        return [
            'person'=>[
                'id'=>$person['id'],'person_id'=>$person['person_id'],'full_name'=>$person['full_name'],
                'photo'=>$person['photo'],'category'=>$person['category_name'],'department'=>$person['department_name'] ?: '—'
            ],
            'action'=>$actualAction,'status'=>$status,'time'=>$now->format('h:i A'),'message'=>$message,
            'schedule'=>$schedule['name']
        ];
    }

    public function markAbsences(string $date): int
    {
        $people = Database::fetchAll('SELECT * FROM people WHERE status="Active"');
        $count = 0;
        foreach ($people as $person) {
            $schedule = $this->resolveSchedule($person, $date);
            if (!$schedule) continue;
            $exists = Database::fetch('SELECT id FROM attendance WHERE person_id=? AND attendance_date=? AND schedule_id=?', [$person['id'],$date,$schedule['id']]);
            if (!$exists) {
                Database::execute('INSERT INTO attendance (person_id,schedule_id,attendance_date,status,remarks,created_by,updated_by) VALUES (?,?,?,"Absent","Automatically marked absent",?,?)', [$person['id'],$schedule['id'],$date,Auth::id(),Auth::id()]);
                $count++;
            }
        }
        activity('Mark Absences', 'attendance', null, "{$count} records for {$date}");
        return $count;
    }
}
