<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use PDO;
use RuntimeException;

final class BackupService
{
    public function create(): string
    {
        $pdo = Database::connection();
        $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        $sql = "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";
        foreach ($tables as $table) {
            $create = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch(PDO::FETCH_NUM);
            $sql .= "DROP TABLE IF EXISTS `{$table}`;\n{$create[1]};\n\n";
            $rows = $pdo->query("SELECT * FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                $columns = implode('`,`', array_keys($row));
                $values = implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), array_values($row)));
                $sql .= "INSERT INTO `{$table}` (`{$columns}`) VALUES ({$values});\n";
            }
            $sql .= "\n";
        }
        $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
        $filename = 'backup-' . date('Ymd-His') . '.sql';
        $path = PUBLIC_PATH . '/backups/' . $filename;
        if (file_put_contents($path, $sql) === false) throw new RuntimeException('Unable to write database backup.');
        activity('Database Backup', 'settings', null, $filename);
        return $filename;
    }

    public function restore(string $file): void
    {
        $sql = file_get_contents($file);
        if ($sql === false || trim($sql) === '') throw new RuntimeException('The uploaded SQL file is empty.');
        $pdo = Database::connection();
        foreach ($this->splitStatements($sql) as $statement) $pdo->exec($statement);
        activity('Database Restore', 'settings', null, basename($file));
    }
    private function splitStatements(string $sql): array
    {
        $statements = []; $buffer = ''; $quote = null; $escaped = false; $length = strlen($sql);
        for ($i = 0; $i < $length; $i++) {
            $char = $sql[$i];
            if ($escaped) { $buffer .= $char; $escaped = false; continue; }
            if ($quote !== null && $char === '\\') { $buffer .= $char; $escaped = true; continue; }
            if ($quote !== null) {
                $buffer .= $char;
                if ($char === $quote) $quote = null;
                continue;
            }
            if (in_array($char, ["'", '"', '`'], true)) { $quote = $char; $buffer .= $char; continue; }
            if ($char === ';') {
                if (trim($buffer) !== '') $statements[] = trim($buffer);
                $buffer = ''; continue;
            }
            $buffer .= $char;
        }
        if (trim($buffer) !== '') $statements[] = trim($buffer);
        return $statements;
    }

}
