<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\RoundBlockSizeMode;
use Endroid\QrCode\Writer\PngWriter;
use RuntimeException;

final class QrService
{
    public function generateForPerson(int $personId, bool $regenerate = false): array
    {
        $person = Database::fetch('SELECT * FROM people WHERE id=? LIMIT 1', [$personId]);
        if (!$person) throw new RuntimeException('Person not found.');

        $token = $regenerate || empty($person['qr_token']) ? bin2hex(random_bytes(32)) : $person['qr_token'];
        $payload = (string)setting('qr_prefix', 'UQAMS:') . $token;
        $size = max(180, min(800, (int)setting('qr_size', 300)));
        $relative = 'uploads/qr/' . $person['person_id'] . '-' . substr($token, 0, 12) . '.png';
        $absolute = PUBLIC_PATH . '/' . $relative;

        if (!class_exists(Builder::class)) {
            throw new RuntimeException('QR library is not installed. Run composer install in the project folder.');
        }

        $builder = new Builder(
            writer: new PngWriter(),
            writerOptions: [],
            validateResult: false,
            data: $payload,
            encoding: new Encoding('UTF-8'),
            errorCorrectionLevel: ErrorCorrectionLevel::High,
            size: $size,
            margin: 10,
            roundBlockSizeMode: RoundBlockSizeMode::Margin
        );
        $builder->build()->saveToFile($absolute);

        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            if ($regenerate) {
                Database::execute('UPDATE qr_codes SET is_active=0 WHERE person_id=?', [$personId]);
            }
            $versionRow = Database::fetch('SELECT COALESCE(MAX(version),0)+1 AS next_version FROM qr_codes WHERE person_id=?', [$personId]);
            Database::execute('UPDATE people SET qr_token=?, qr_image=? WHERE id=?', [$token, $relative, $personId]);
            $existingCode = Database::fetch('SELECT id FROM qr_codes WHERE person_id=? AND token=? LIMIT 1', [$personId, $token]);
            if ($existingCode) {
                Database::execute('UPDATE qr_codes SET image_path=?, is_active=1, generated_by=?, generated_at=NOW() WHERE id=?', [$relative, \App\Core\Auth::id(), $existingCode['id']]);
            } else {
                Database::execute(
                    'INSERT INTO qr_codes (person_id,token,image_path,version,is_active,generated_by,generated_at) VALUES (?,?,?,?,1,?,NOW())',
                    [$personId,$token,$relative,(int)($versionRow['next_version'] ?? 1),\App\Core\Auth::id()]
                );
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            @unlink($absolute);
            throw $e;
        }
        activity($regenerate ? 'QR Regenerated' : 'QR Generated', 'people', $personId, $person['person_id']);
        return ['token'=>$token,'payload'=>$payload,'image_path'=>$relative];
    }
}
