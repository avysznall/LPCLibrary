<?php $v = fn($key, $default = '') => e(old($key, $record[$key] ?? $default)); ?>
<form method="post" action="<?= url($record ? 'attendance/update' : 'attendance/manual') ?>">
    <?= csrf_field() ?><?php if ($record): ?><input type="hidden" name="id" value="<?= $record['id'] ?>"><?php endif; ?>
    <div class="row">
        <div class="col-md-9">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title"><?= $record ? 'Correct Attendance Record' : 'Create Attendance Record' ?></h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-6"><label class="required">Person</label><select
                                class="form-control" name="person_id" required>
                                <option value="">Choose a person</option><?php foreach ($people as $p): ?>
                                    <option value="<?= $p['id'] ?>"
                                        <?= ((int) old('person_id', $record['person_id'] ?? 0) === $p['id']) ? 'selected' : '' ?>>
                                        <?= e($p['person_id'] . ' — ' . $p['full_name']) ?></option><?php endforeach; ?>
                            </select></div>
                        <div class="form-group col-md-3"><label class="required">Date</label><input type="date"
                                class="form-control" name="attendance_date"
                                value="<?= $v('attendance_date', date('Y-m-d')) ?>" required></div>
                        <div class="form-group col-md-3"><label class="required">Status</label><select
                                class="form-control" name="status"
                                required><?php foreach (['Present', 'Late', 'Absent', 'On Leave', 'Holiday', 'Half-Day'] as $s): ?>
                                    <option <?= old('status', $record['status'] ?? 'Present') === $s ? 'selected' : '' ?>><?= $s ?>
                                    </option><?php endforeach; ?>
                            </select></div>
                    </div>
                    <div class="form-group"><label>Attendance Schedule</label><select class="form-control"
                            name="schedule_id">
                            <option value="">No schedule / general attendance</option><?php foreach ($schedules as $s): ?>
                                <option value="<?= $s['id'] ?>"
                                    <?= ((int) old('schedule_id', $record['schedule_id'] ?? 0) === $s['id']) ? 'selected' : '' ?>>
                                    <?= e($s['name'] . ' (' . format_time($s['start_time']) . '–' . format_time($s['end_time']) . ')') ?>
                                </option><?php endforeach; ?>
                        </select></div>
                    <div class="form-row">
                        <div class="form-group col-md-3"><label>Time In</label><input type="time" step="1"
                                class="form-control" name="time_in" value="<?= $v('time_in') ?>"></div>
                        <div class="form-group col-md-3"><label>Break Out</label><input type="time" step="1"
                                class="form-control" name="break_out" value="<?= $v('break_out') ?>"></div>
                        <div class="form-group col-md-3"><label>Break In</label><input type="time" step="1"
                                class="form-control" name="break_in" value="<?= $v('break_in') ?>"></div>
                        <div class="form-group col-md-3"><label>Time Out</label><input type="time" step="1"
                                class="form-control" name="time_out" value="<?= $v('time_out') ?>"></div>
                    </div>
                    <div class="form-group"><label>Scanner Location / Device Label</label><input class="form-control"
                            name="scanner_location" value="<?= $v('scanner_location') ?>"
                            placeholder="e.g., Main Entrance Tablet"></div>
                    <div class="form-group"><label>Remarks</label><textarea class="form-control" rows="3" name="remarks"
                            maxlength="500"><?= $v('remarks') ?></textarea></div>
                </div>
                <div class="card-footer"><button class="btn btn-primary"><i class="fas fa-save mr-1"></i> Save
                        Attendance</button><a href="<?= url('attendance') ?>" class="btn btn-light">Cancel</a></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="alert alert-info">
                <h5><i class="fas fa-info-circle"></i> Validation</h5><small>A person can have only one attendance
                    record for the same date and schedule. Corrections are written to the activity log with the previous
                    and updated values.</small>
            </div>
        </div>
    </div>
</form><?php clear_old(); ?>