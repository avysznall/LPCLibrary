<div class="card filter-card">
    <div class="card-body">
        <form method="get"><input type="hidden" name="route" value="attendance">
            <div class="form-row">
                <div class="form-group col-lg-3"><label>Search</label><input class="form-control" name="q"
                        value="<?= e($_GET['q'] ?? '') ?>" placeholder="Name, ID, or QR token"></div>
                <div class="form-group col-lg-2"><label>From</label><input type="date" class="form-control" name="from"
                        value="<?= e($from) ?>"></div>
                <div class="form-group col-lg-2"><label>To</label><input type="date" class="form-control" name="to"
                        value="<?= e($to) ?>"></div>
                <div class="form-group col-lg-2"><label>Status</label><select class="form-control" name="status">
                        <option value="">All statuses</option>
                        <?php foreach (['Present', 'Late', 'Absent', 'On Leave', 'Holiday', 'Half-Day'] as $s): ?>
                            <option <?= ($_GET['status'] ?? '') === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-3 d-flex align-items-end"><button class="btn btn-primary mr-2"><i
                            class="fas fa-filter mr-1"></i> Filter</button><a href="<?= url('attendance') ?>"
                        class="btn btn-light">Reset</a></div>
            </div>
            <div class="form-row">
                <div class="form-group col-lg-3"><label>Category</label><select class="form-control" name="category_id">
                        <option value="">All</option><?php foreach ($categories as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ((int) ($_GET['category_id'] ?? 0) === $c['id']) ? 'selected' : '' ?>>
                                <?= e($c['name']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-3"><label>Department / Group</label><select class="form-control"
                        name="department_id">
                        <option value="">All</option><?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= ((int) ($_GET['department_id'] ?? 0) === $d['id']) ? 'selected' : '' ?>>
                                <?= e($d['name']) ?></option><?php endforeach; ?>
                    </select></div>
            </div>
        </form>
    </div>
</div>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Attendance Records <span class="badge badge-secondary"><?= $p['total'] ?></span></h3>
        <div class="card-tools"><a href="<?= url('attendance/scanner') ?>" class="btn btn-sm btn-success mr-1"><i
                    class="fas fa-qrcode mr-1"></i> Scan QR</a><a href="<?= url('attendance/manual') ?>"
                class="btn btn-sm btn-primary mr-1"><i class="fas fa-plus mr-1"></i> Manual Attendance</a><a
                href="<?= url('reports') ?>" class="btn btn-sm btn-outline-secondary"><i
                    class="fas fa-file-export mr-1"></i> Reports</a></div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover table-sm mb-0">
            <thead>
                <tr>
                    <th>QR / Person ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Department</th>
                    <th>Date</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Status</th>
                    <th>Remarks</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody><?php foreach ($logs as $r): ?>
                    <tr>
                        <td><code><?= e($r['person_id']) ?></code><br><small
                                class="text-muted"><?= e(substr($r['qr_token'], 0, 8)) ?>…</small></td>
                        <td><strong><?= e($r['full_name']) ?></strong><br><small><?= e($r['schedule_name'] ?: 'No schedule') ?></small>
                        </td>
                        <td><?= e($r['category_name']) ?></td>
                        <td><?= e($r['department_name'] ?: '—') ?></td>
                        <td><?= format_date($r['attendance_date']) ?></td>
                        <td><?= format_time($r['time_in']) ?></td>
                        <td><?= format_time($r['time_out']) ?></td>
                        <td><span class="badge badge-<?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
                        <td><?= e(mb_strimwidth($r['remarks'] ?: '—', 0, 35, '…')) ?></td>
                        <td class="text-right text-nowrap"><a href="<?= url('attendance/edit', ['id' => $r['id']]) ?>"
                                class="btn btn-xs btn-warning"><i
                                    class="fas fa-edit"></i></a><?php if (\App\Core\Auth::isAdmin()): ?>
                                <form method="post" action="<?= url('attendance/delete') ?>" class="d-inline"
                                    data-confirm="Delete this attendance record permanently?"><?= csrf_field() ?><input
                                        type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-xs btn-danger"><i
                                            class="fas fa-trash"></i></button></form><?php endif; ?>
                        </td>
                    </tr><?php endforeach; ?><?php if (!$logs): ?>
                    <tr>
                        <td colspan="10" class="text-center text-muted py-4">No attendance records found.</td>
                    </tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer d-flex justify-content-between">
        <div><?php if (\App\Core\Auth::isAdmin()): ?>
                <form method="post" action="<?= url('attendance/mark-absences') ?>" class="form-inline"
                    data-confirm="Create Absent records for all scheduled active people who have no attendance on this date?">
                    <?= csrf_field() ?><input type="date" name="date" class="form-control form-control-sm mr-2"
                        value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>"><button
                        class="btn btn-sm btn-outline-danger">Mark Missing as Absent</button></form><?php endif; ?>
        </div><?= pagination_links($p) ?>
    </div>
</div>