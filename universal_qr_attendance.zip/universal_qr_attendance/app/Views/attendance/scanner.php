<div class="row">
    <div class="col-lg-7">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-camera mr-2"></i>Camera Scanner</h3>
                <div class="card-tools"><span id="cameraState" class="badge badge-secondary">Not started</span></div>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group col-md-5"><label>Scan Action</label><select id="scanAction"
                            class="form-control">
                            <option value="auto">Auto: Time In then Time Out</option>
                            <option value="time_in">Time In</option>
                            <option value="break_out">Break Out</option>
                            <option value="break_in">Break In</option>
                            <option value="time_out">Time Out</option>
                        </select></div>
                    <div class="form-group col-md-5"><label>Scanner Location</label><input id="scanLocation"
                            class="form-control" placeholder="e.g., Main Entrance"></div>
                    <div class="form-group col-md-2 d-flex align-items-end"><button id="startScanner"
                            class="btn btn-primary btn-block"><i class="fas fa-play"></i> Start</button></div>
                </div>
                <div id="reader" style="max-width:620px;margin:auto"></div>
                <div class="input-group mt-3"><input id="manualToken" class="form-control"
                        placeholder="Paste QR content or token for testing">
                    <div class="input-group-append"><button id="submitToken"
                            class="btn btn-outline-primary">Submit</button></div>
                </div>
                <p class="text-muted small mt-2 mb-0">Camera access requires HTTPS or localhost in most browsers. Mobile
                    rear cameras are selected automatically where available.</p>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Attendance Confirmation</h3>
            </div>
            <div class="card-body text-center" id="resultPanel">
                <div class="py-5 text-muted"><i class="fas fa-qrcode fa-4x mb-3"></i>
                    <p>Scan a registered QR code to display the result.</p>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Recent Scans</h3>
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush" id="recentScans">
                    <li class="list-group-item text-muted">No scans in this session.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php
$successSound = setting('scanner_success_sound', '1') === '1' ? 'true' : 'false';
$scanApiUrl = json_encode(url('api/attendance/scan'), JSON_UNESCAPED_SLASHES);
$publicBase = json_encode(rtrim(config('url'), '/') . '/', JSON_UNESCAPED_SLASHES);
$pageScript = <<<'HTML'
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
const token=document.querySelector('meta[name="csrf-token"]').content;let scanner=null,busy=false,started=false;const successSound=__SUCCESS_SOUND__;const scanApiUrl=__SCAN_API_URL__;const publicBase=__PUBLIC_BASE__;
function beep(ok=true){if(!successSound)return;try{const c=new(window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.frequency.value=ok?880:220;o.connect(g);g.connect(c.destination);g.gain.value=.08;o.start();o.stop(c.currentTime+.16)}catch(e){}}
async function submitScan(value){if(busy||!value.trim())return;busy=true;document.getElementById('cameraState').textContent='Processing';try{const res=await fetch(scanApiUrl,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({_token:token,token:value.trim(),action:document.getElementById('scanAction').value,location:document.getElementById('scanLocation').value})});const data=await res.json();render(data);beep(data.success)}catch(e){render({success:false,message:'Unable to reach the attendance server.'});beep(false)}setTimeout(()=>{busy=false;document.getElementById('cameraState').textContent=started?'Scanning':'Stopped'},1800)}
function render(d){const p=document.getElementById('resultPanel');if(!d.success){p.innerHTML=`<div class="py-4 text-danger"><i class="fas fa-times-circle fa-4x mb-3"></i><h4>Scan Rejected</h4><p>${escapeHtml(d.message)}</p></div>`;return;}const photo=d.person.photo?`<img class="avatar-lg mb-2" src="${publicBase}${d.person.photo}">`:`<div class="avatar-lg mx-auto mb-2 d-flex align-items-center justify-content-center"><i class="fas fa-user fa-3x text-muted"></i></div>`;p.innerHTML=`<div class="py-2">${photo}<h3>${escapeHtml(d.person.full_name)}</h3><p class="mb-1"><code>${escapeHtml(d.person.person_id)}</code></p><p>${escapeHtml(d.person.category)} · ${escapeHtml(d.person.department)}</p><span class="badge badge-${d.status==='Late'?'warning':'success'} p-2">${escapeHtml(d.status)}</span><h4 class="mt-3">${escapeHtml(d.time)}</h4><p class="text-success mb-0"><i class="fas fa-check-circle"></i> ${escapeHtml(d.message)}</p><small class="text-muted">${escapeHtml(d.schedule)}</small></div>`;const li=document.createElement('li');li.className='list-group-item';li.innerHTML=`<strong>${escapeHtml(d.person.full_name)}</strong><span class="float-right badge badge-light">${escapeHtml(d.time)}</span><br><small>${escapeHtml(d.message)}</small>`;const list=document.getElementById('recentScans');if(list.children[0]?.classList.contains('text-muted'))list.innerHTML='';list.prepend(li)}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
document.getElementById('startScanner').onclick=async()=>{if(started){await scanner.stop();started=false;document.getElementById('startScanner').innerHTML='<i class="fas fa-play"></i> Start';document.getElementById('cameraState').textContent='Stopped';return}scanner=new Html5Qrcode('reader');try{await scanner.start({facingMode:'environment'},{fps:10,qrbox:{width:250,height:250}},decoded=>submitScan(decoded),()=>{});started=true;document.getElementById('startScanner').innerHTML='<i class="fas fa-stop"></i> Stop';document.getElementById('cameraState').textContent='Scanning'}catch(e){render({success:false,message:'Camera could not start. Check browser permission or use the manual token field.'})}};
document.getElementById('submitToken').onclick=()=>{submitScan(document.getElementById('manualToken').value);document.getElementById('manualToken').value=''};document.getElementById('manualToken').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('submitToken').click()});
</script>
HTML;
$pageScript = str_replace(
    ['__SUCCESS_SOUND__', '__SCAN_API_URL__', '__PUBLIC_BASE__'],
    [$successSound, $scanApiUrl, $publicBase],
    $pageScript
);
?>