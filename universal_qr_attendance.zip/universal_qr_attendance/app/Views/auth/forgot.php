<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>

<body class="hold-transition login-page bg-light">
    <div class="login-box">
        <div class="card">
            <div class="card-body login-card-body">
                <h4 class="text-center mb-3">Reset Password</h4><?php if ($m = flash('success')): ?>
                    <div class="alert alert-success"><?= e($m) ?></div><?php endif; ?><?php if ($m = flash('error')): ?>
                    <div class="alert alert-danger"><?= e($m) ?></div>
                <?php endif; ?><?php if (!empty($_SESSION['_reset_preview'])): ?>
                    <div class="alert alert-info small"><strong>Local reset link:</strong><br><a class="text-break"
                            href="<?= e($_SESSION['_reset_preview']) ?>"><?= e($_SESSION['_reset_preview']) ?></a></div>
                    <?php unset($_SESSION['_reset_preview']); endif; ?>
                <p>Enter the account email address. Production deployments can replace the local reset-link logger with
                    SMTP delivery.</p>
                <form method="post" action="<?= url('forgot-password') ?>"><?= csrf_field() ?><input type="email"
                        name="email" class="form-control mb-3" placeholder="Email" required><button
                        class="btn btn-primary btn-block">Create Reset Link</button></form>
                <p class="mt-3 mb-0"><a href="<?= url('login') ?>">Back to login</a></p>
            </div>
        </div>
    </div>
</body>

</html>