<?php use App\Core\Csrf; ?><!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login | Universal QR Attendance</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #0f172a, #334155)
        }

        .login-box {
            width: 390px
        }

        .card {
            border: 0;
            border-radius: 12px
        }

        .login-logo a {
            color: white
        }
    </style>
</head>

<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo"><a href="#"><b>Universal QR</b> Attendance</a></div>
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to manage attendance</p><?php if ($m = flash('error')): ?>
                    <div class="alert alert-danger"><?= e($m) ?></div><?php endif; ?><?php if ($m = flash('success')): ?>
                    <div class="alert alert-success"><?= e($m) ?></div><?php endif; ?>
                <form method="post" action="<?= url('login') ?>"><?= csrf_field() ?>
                    <div class="input-group mb-3"><input name="login" class="form-control"
                            placeholder="Email or username" value="<?= e(old('login')) ?>" required autofocus>
                        <div class="input-group-append">
                            <div class="input-group-text"><span class="fas fa-envelope"></span></div>
                        </div>
                    </div>
                    <div class="input-group mb-3"><input type="password" name="password" class="form-control"
                            placeholder="Password" required>
                        <div class="input-group-append">
                            <div class="input-group-text"><span class="fas fa-lock"></span></div>
                        </div>
                    </div><button class="btn btn-primary btn-block">Sign In</button>
                </form>
                <p class="mt-3 mb-0"><a href="<?= url('forgot-password') ?>">Forgot password?</a></p>
                <?php if (setting('public_kiosk_enabled', '1') === '1' && trim((string) setting('kiosk_access_key', '')) === ''): ?>
                    <hr><a class="btn btn-outline-success btn-block" href="<?= e(rtrim(config('url'), '/') . '/kiosk.php') ?>"><i
                            class="fas fa-qrcode mr-1"></i> Open Attendance Kiosk</a><?php endif; ?>
            </div>
        </div>
        <p class="text-center text-white-50 small mt-3">Secure role-based attendance management</p>
    </div>
</body>

</html>