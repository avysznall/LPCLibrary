<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-body box-profile">
                <div class="text-center"><?php if ($user['photo']): ?><img class="profile-user-img img-fluid img-circle"
                            src="<?= upload_url($user['photo']) ?>"><?php else: ?>
                        <div class="mx-auto rounded-circle bg-light d-flex align-items-center justify-content-center"
                            style="width:100px;height:100px"><i class="fas fa-user fa-3x text-muted"></i></div>
                    <?php endif; ?>
                </div>
                <h3 class="profile-username text-center"><?= e($user['full_name']) ?></h3>
                <p class="text-muted text-center"><?= e($user['role_name']) ?></p>
                <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item"><b>Username</b><span
                            class="float-right"><?= e($user['username']) ?></span></li>
                    <li class="list-group-item"><b>Last Login</b><span
                            class="float-right"><?= e($user['last_login'] ? date('d M Y h:i A', strtotime($user['last_login'])) : '—') ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header p-2">
                <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#details" data-toggle="tab">Profile</a></li>
                    <li class="nav-item"><a class="nav-link" href="#password" data-toggle="tab">Change Password</a></li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="active tab-pane" id="details">
                        <form method="post" action="<?= url('profile') ?>" enctype="multipart/form-data"><?= csrf_field() ?>
                            <div class="form-group"><label class="required">Full Name</label><input class="form-control"
                                    name="full_name" value="<?= e($user['full_name']) ?>" required></div>
                            <div class="form-row">
                                <div class="form-group col-md-6"><label class="required">Email</label><input
                                        type="email" class="form-control" name="email" value="<?= e($user['email']) ?>"
                                        required></div>
                                <div class="form-group col-md-6"><label>Phone</label><input class="form-control"
                                        name="phone" value="<?= e($user['phone']) ?>"></div>
                            </div>
                            <div class="form-group"><label>Profile Photo</label><input type="file"
                                    class="form-control-file" name="photo" accept="image/png,image/jpeg,image/webp">
                            </div><button class="btn btn-primary">Save Profile</button>
                        </form>
                    </div>
                    <div class="tab-pane" id="password">
                        <form method="post" action="<?= url('change-password') ?>"><?= csrf_field() ?>
                            <div class="form-group"><label class="required">Current Password</label><input
                                    type="password" class="form-control" name="current_password" required></div>
                            <div class="form-row">
                                <div class="form-group col-md-6"><label class="required">New Password</label><input
                                        type="password" minlength="8" class="form-control" name="new_password" required>
                                </div>
                                <div class="form-group col-md-6"><label class="required">Confirm New
                                        Password</label><input type="password" minlength="8" class="form-control"
                                        name="new_password_confirmation" required></div>
                            </div><button class="btn btn-warning">Change Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>