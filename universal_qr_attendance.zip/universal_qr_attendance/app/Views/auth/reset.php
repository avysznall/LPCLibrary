<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>

<body class="hold-transition login-page bg-light">
    <div class="login-box">
        <div class="card">
            <div class="card-body login-card-body">
                <h4 class="text-center mb-3">Choose New Password</h4><?php if ($m = flash('error')): ?>
                    <div class="alert alert-danger"><?= e($m) ?></div><?php endif; ?>
                <form method="post" action="<?= url('reset-password') ?>"><?= csrf_field() ?><input type="hidden"
                        name="token" value="<?= e($token) ?>"><input type="email" name="email" class="form-control mb-3"
                        value="<?= e($email) ?>" required><input type="password" name="password" minlength="8"
                        class="form-control mb-3" placeholder="New password" required><input type="password"
                        name="password_confirmation" minlength="8" class="form-control mb-3"
                        placeholder="Confirm password" required><button class="btn btn-primary btn-block">Reset
                        Password</button></form>
            </div>
        </div>
    </div>
</body>

</html>