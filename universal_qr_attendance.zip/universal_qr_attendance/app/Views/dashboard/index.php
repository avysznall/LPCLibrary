<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3><?= $stats['people'] ?></h3>
                <p>Registered People</p>
            </div>
            <div class="icon"><i class="fas fa-users"></i></div><a href="<?= url('people') ?>"
                class="small-box-footer">Manage people <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3><?= $stats['present'] ?></h3>
                <p>Today's Present</p>
            </div>
            <div class="icon"><i class="fas fa-user-check"></i></div><a
                href="<?= url('attendance', ['from' => date('Y-m-d'), 'to' => date('Y-m-d'), 'status' => 'Present']) ?>"
                class="small-box-footer">View logs <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3><?= $stats['late'] ?></h3>
                <p>Today's Late</p>
            </div>
            <div class="icon"><i class="fas fa-clock"></i></div><a
                href="<?= url('attendance', ['from' => date('Y-m-d'), 'to' => date('Y-m-d'), 'status' => 'Late']) ?>"
                class="small-box-footer">View late records <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner">
                <h3><?= $stats['absent'] ?></h3>
                <p>Today's Absent</p>
            </div>
            <div class="icon"><i class="fas fa-user-times"></i></div><a
                href="<?= url('attendance', ['from' => date('Y-m-d'), 'to' => date('Y-m-d'), 'status' => 'Absent']) ?>"
                class="small-box-footer">View absences <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">7-Day Attendance Overview</h3>
                <div class="card-tools"><a href="<?= url('attendance/scanner') ?>" class="btn btn-sm btn-primary"><i
                            class="fas fa-qrcode mr-1"></i> Open Scanner</a></div>
            </div>
            <div class="card-body"><canvas id="attendanceChart" height="105"></canvas></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Time In / Time Out</h3>
            </div>
            <div class="card-body">
                <div class="info-box"><span class="info-box-icon bg-primary"><i class="fas fa-sign-in-alt"></i></span>
                    <div class="info-box-content"><span class="info-box-text">Time In Recorded</span><span
                            class="info-box-number"><?= $stats['time_in'] ?></span></div>
                </div>
                <div class="info-box mb-0"><span class="info-box-icon bg-secondary"><i
                            class="fas fa-sign-out-alt"></i></span>
                    <div class="info-box-content"><span class="info-box-text">Time Out Recorded</span><span
                            class="info-box-number"><?= $stats['time_out'] ?></span></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Recent Attendance</h3>
                <div class="card-tools"><a href="<?= url('attendance') ?>" class="btn btn-tool">View all</a></div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Person</th>
                            <th>Category</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody><?php foreach ($recent as $r): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center"><?php if ($r['photo']): ?><img class="avatar mr-2"
                                                src="<?= upload_url($r['photo']) ?>"><?php else: ?><span
                                                class="avatar mr-2 d-flex align-items-center justify-content-center"><i
                                                    class="fas fa-user text-muted"></i></span><?php endif; ?>
                                        <div><strong><?= e($r['full_name']) ?></strong><br><small
                                                class="text-muted"><?= e($r['person_id']) ?></small></div>
                                    </div>
                                </td>
                                <td><?= e($r['category_name']) ?><br><small><?= e($r['department_name'] ?: '—') ?></small></td>
                                <td><?= format_time($r['time_in']) ?></td>
                                <td><?= format_time($r['time_out']) ?></td>
                                <td><span class="badge badge-<?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span>
                                </td>
                            </tr><?php endforeach; ?><?php if (!$recent): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">No attendance recorded yet.</td>
                            </tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">System Announcements</h3>
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush"><?php foreach ($announcements as $a): ?>
                        <li class="list-group-item"><strong><?= e($a['title']) ?></strong>
                            <p class="mb-0 text-muted small"><?= nl2br(e($a['message'])) ?></p>
                        </li><?php endforeach; ?><?php if (!$announcements): ?>
                        <li class="list-group-item text-muted">No active announcements.</li><?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php
$labels = [];
$present = [];
$late = [];
$absent = [];
foreach ($chart as $c) {
    $labels[] = date('d M', strtotime($c['attendance_date']));
    $present[] = (int) $c['present_count'];
    $late[] = (int) $c['late_count'];
    $absent[] = (int) $c['absent_count'];
}
$pageScript = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script><script>new Chart(document.getElementById("attendanceChart"),{type:"line",data:{labels:' . json_encode($labels) . ',datasets:[{label:"Present",data:' . json_encode($present) . ',borderColor:"#28a745",backgroundColor:"rgba(40,167,69,.12)",tension:.3,fill:true},{label:"Late",data:' . json_encode($late) . ',borderColor:"#ffc107",tension:.3},{label:"Absent",data:' . json_encode($absent) . ',borderColor:"#dc3545",tension:.3}]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});</script>';
?>