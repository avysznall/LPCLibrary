<div class="error-page">
    <h2 class="headline text-warning">403</h2>
    <div class="error-content">
        <h3><i class="fas fa-exclamation-triangle text-warning"></i> Access denied.</h3>
        <p>Your role does not have permission to open this page. <a href="<?= url('dashboard') ?>">Return to
                dashboard</a>.</p>
    </div>
</div>