<div class="error-page">
    <h2 class="headline text-warning">404</h2>
    <div class="error-content">
        <h3><i class="fas fa-exclamation-triangle text-warning"></i> Page not found.</h3>
        <p>The requested record or page does not exist. <a href="<?= url('dashboard') ?>">Return to dashboard</a>.</p>
    </div>
</div>