<div class="error-page">
    <h2 class="headline text-danger">500</h2>
    <div class="error-content">
        <h3><i class="fas fa-exclamation-triangle text-danger"></i> System error.</h3>
        <p><?= e($message ?? 'An unexpected error occurred.') ?> <a href="<?= url('dashboard') ?>">Return to dashboard</a>.
        </p>
    </div>
</div>