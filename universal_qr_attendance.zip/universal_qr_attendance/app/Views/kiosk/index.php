<?php
use App\Core\Csrf;

$scanApiUrl = url('api/kiosk/scan');
$publicBase = rtrim(config('url'), '/') . '/';
$logoUrl = $logo ? upload_url($logo) : '';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="<?= e(Csrf::token()) ?>">
    <title><?= e($title) ?> | <?= e($organization) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <style>
        :root {
            --kiosk-navy: #0f172a;
            --kiosk-slate: #334155;
            --kiosk-muted: #64748b;
            --kiosk-border: #dbe3ee;
            --kiosk-surface: #ffffff;
            --kiosk-soft: #f8fafc;
            --kiosk-blue: #2563eb;
            --kiosk-blue-dark: #1d4ed8;
            --kiosk-green: #16a34a;
            --kiosk-red: #dc2626;
            --kiosk-amber: #d97706;
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
            background: #eef3f9;
        }

        body {
            min-height: 100vh;
            min-height: 100dvh;
            margin: 0;
            overflow-x: hidden;
            color: var(--kiosk-navy);
            background:
                radial-gradient(circle at 10% 10%, rgba(37, 99, 235, .12), transparent 30rem),
                radial-gradient(circle at 90% 90%, rgba(14, 165, 233, .10), transparent 28rem),
                #eef3f9;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        }

        button,
        input,
        select,
        textarea {
            font: inherit;
        }

        .kiosk-shell {
            min-height: 100vh;
            min-height: 100dvh;
            display: grid;
            grid-template-rows: auto 1fr auto;
        }

        .kiosk-header {
            position: relative;
            z-index: 10;
            color: #fff;
            background: linear-gradient(110deg, #0f172a 0%, #16233d 58%, #1e3a5f 100%);
            box-shadow: 0 8px 24px rgba(15, 23, 42, .16);
        }

        .kiosk-header-inner {
            width: min(100%, 1320px);
            min-height: 76px;
            margin: 0 auto;
            padding: max(12px, env(safe-area-inset-top)) clamp(16px, 3vw, 34px) 12px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
        }

        .kiosk-brand {
            min-width: 0;
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .brand-logo,
        .brand-mark {
            width: 48px;
            height: 48px;
            flex: 0 0 48px;
            border-radius: 14px;
        }

        .brand-logo {
            object-fit: contain;
            padding: 5px;
            background: #fff;
            box-shadow: 0 5px 16px rgba(0, 0, 0, .18);
        }

        .brand-mark {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            background: rgba(255, 255, 255, .12);
            border: 1px solid rgba(255, 255, 255, .16);
        }

        .brand-copy {
            min-width: 0;
        }

        .brand-name {
            display: block;
            overflow: hidden;
            color: #fff;
            font-size: clamp(.98rem, 2vw, 1.12rem);
            font-weight: 700;
            line-height: 1.25;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .brand-subtitle {
            display: block;
            overflow: hidden;
            margin-top: 3px;
            color: rgba(255, 255, 255, .68);
            font-size: clamp(.76rem, 1.7vw, .88rem);
            line-height: 1.2;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .kiosk-clock-wrap {
            flex: 0 0 auto;
            text-align: right;
        }

        .clock {
            font-variant-numeric: tabular-nums;
            letter-spacing: .02em;
        }

        #kioskClock {
            color: #fff;
            font-size: 1rem;
            font-weight: 700;
            line-height: 1.2;
        }

        #kioskDate {
            display: block;
            margin-top: 4px;
            color: rgba(255, 255, 255, .62);
            font-size: .78rem;
            line-height: 1.2;
        }

        .kiosk-main {
            width: min(100%, 1320px);
            margin: 0 auto;
            padding: clamp(16px, 3vw, 34px);
            display: flex;
            align-items: center;
        }

        .kiosk-workspace,
        .kiosk-state-card {
            width: 100%;
            overflow: hidden;
            background: rgba(255, 255, 255, .96);
            border: 1px solid rgba(203, 213, 225, .78);
            border-radius: 24px;
            box-shadow: 0 24px 70px rgba(15, 23, 42, .14);
        }

        .kiosk-workspace {
            display: grid;
            grid-template-columns: minmax(0, 1.35fr) minmax(340px, .85fr);
        }

        .scanner-panel {
            min-width: 0;
            padding: clamp(20px, 3vw, 36px);
            background: var(--kiosk-surface);
        }

        .panel-heading {
            margin-bottom: 20px;
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
        }

        .panel-title-wrap {
            min-width: 0;
        }

        .panel-eyebrow {
            margin: 0 0 6px;
            color: var(--kiosk-blue);
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .12em;
            text-transform: uppercase;
        }

        .panel-title {
            margin: 0;
            color: var(--kiosk-navy);
            font-size: clamp(1.38rem, 2.7vw, 2rem);
            font-weight: 750;
            letter-spacing: -.025em;
            line-height: 1.15;
        }

        .panel-description {
            max-width: 590px;
            margin: 8px 0 0;
            color: var(--kiosk-muted);
            font-size: clamp(.9rem, 1.7vw, 1rem);
            line-height: 1.55;
        }

        .camera-status {
            min-height: 36px;
            flex: 0 0 auto;
            padding: 8px 12px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #475569;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 999px;
            font-size: .8rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .status-dot {
            width: 9px;
            height: 9px;
            flex: 0 0 9px;
            border-radius: 50%;
            background: #94a3b8;
            box-shadow: 0 0 0 4px rgba(148, 163, 184, .12);
        }

        .status-dot.active {
            background: #22c55e;
            box-shadow: 0 0 0 5px rgba(34, 197, 94, .14);
        }

        .camera-card {
            padding: clamp(10px, 1.8vw, 16px);
            background: #f8fafc;
            border: 1px solid var(--kiosk-border);
            border-radius: 20px;
        }

        .camera-surface {
            position: relative;
            width: 100%;
            aspect-ratio: 4 / 3;
            overflow: hidden;
            isolation: isolate;
            background:
                radial-gradient(circle at center, rgba(59, 130, 246, .12), transparent 45%),
                #08111f;
            border-radius: 15px;
        }

        #reader {
            position: absolute;
            inset: 0;
            width: 100% !important;
            height: 100% !important;
            border: 0 !important;
            overflow: hidden;
            border-radius: inherit;
        }

        #reader>div,
        #reader__scan_region {
            width: 100% !important;
            height: 100% !important;
            min-height: 100% !important;
        }

        #reader video,
        #reader canvas {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            border-radius: inherit;
        }

        #reader__dashboard,
        #reader__header_message {
            display: none !important;
        }

        .camera-placeholder {
            position: absolute;
            inset: 0;
            z-index: 2;
            padding: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #cbd5e1;
            text-align: center;
            pointer-events: none;
            transition: opacity .2s ease, visibility .2s ease;
        }

        .camera-placeholder-icon {
            width: 76px;
            height: 76px;
            margin-bottom: 15px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #bfdbfe;
            background: rgba(37, 99, 235, .18);
            border: 1px solid rgba(147, 197, 253, .24);
            border-radius: 22px;
            font-size: 1.8rem;
        }

        .camera-placeholder strong {
            color: #f8fafc;
            font-size: 1.05rem;
        }

        .camera-placeholder small {
            max-width: 350px;
            margin-top: 7px;
            color: #94a3b8;
            line-height: 1.5;
        }

        .camera-surface.camera-live .camera-placeholder {
            opacity: 0;
            visibility: hidden;
        }

        .scan-guide {
            position: absolute;
            inset: 14% 22%;
            z-index: 4;
            pointer-events: none;
            opacity: .94;
        }

        .scan-guide span {
            position: absolute;
            width: 36px;
            height: 36px;
            border-color: #60a5fa;
            border-style: solid;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, .45));
        }

        .scan-guide .top-left {
            top: 0;
            left: 0;
            border-width: 4px 0 0 4px;
            border-radius: 9px 0 0 0;
        }

        .scan-guide .top-right {
            top: 0;
            right: 0;
            border-width: 4px 4px 0 0;
            border-radius: 0 9px 0 0;
        }

        .scan-guide .bottom-left {
            bottom: 0;
            left: 0;
            border-width: 0 0 4px 4px;
            border-radius: 0 0 0 9px;
        }

        .scan-guide .bottom-right {
            right: 0;
            bottom: 0;
            border-width: 0 4px 4px 0;
            border-radius: 0 0 9px 0;
        }

        .camera-caption {
            margin: 11px 4px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            color: var(--kiosk-muted);
            font-size: .82rem;
            line-height: 1.4;
            text-align: center;
        }

        .start-button {
            width: 100%;
            min-height: 52px;
            margin-top: 15px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            color: #fff;
            background: linear-gradient(135deg, var(--kiosk-blue), var(--kiosk-blue-dark));
            border: 0;
            border-radius: 14px;
            box-shadow: 0 10px 22px rgba(37, 99, 235, .22);
            font-weight: 750;
            transition: transform .16s ease, box-shadow .16s ease, opacity .16s ease;
        }

        .start-button:hover,
        .start-button:focus {
            color: #fff;
            transform: translateY(-1px);
            box-shadow: 0 13px 28px rgba(37, 99, 235, .28);
        }

        .start-button:disabled {
            opacity: .7;
            transform: none;
        }

        .attendance-note {
            margin-top: 15px;
            padding: 13px 15px;
            display: flex;
            align-items: flex-start;
            gap: 11px;
            color: #334155;
            background: #eff6ff;
            border: 1px solid #dbeafe;
            border-radius: 14px;
            font-size: .88rem;
            line-height: 1.5;
        }

        .attendance-note i {
            margin-top: 2px;
            color: var(--kiosk-blue);
        }

        .privacy-note {
            margin: 13px 4px 0;
            color: var(--kiosk-muted);
            font-size: .76rem;
            line-height: 1.45;
            text-align: center;
        }

        .confirmation-panel {
            min-width: 0;
            padding: clamp(20px, 3vw, 34px);
            display: flex;
            align-items: center;
            justify-content: center;
            background:
                radial-gradient(circle at 75% 14%, rgba(59, 130, 246, .12), transparent 16rem),
                linear-gradient(145deg, #f8fbff 0%, #edf4fb 100%);
            border-left: 1px solid var(--kiosk-border);
        }

        .result-surface {
            width: 100%;
            max-width: 430px;
            min-height: 410px;
            padding: clamp(22px, 3vw, 34px);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            background: rgba(255, 255, 255, .84);
            border: 1px solid rgba(203, 213, 225, .86);
            border-radius: 22px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, .08);
            backdrop-filter: blur(8px);
        }

        #resultPanel {
            width: 100%;
        }

        .result-icon {
            width: 92px;
            height: 92px;
            margin: 0 auto 22px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 28px;
            font-size: 2.4rem;
        }

        .result-icon--ready {
            color: var(--kiosk-blue);
            background: #eaf2ff;
            box-shadow: 0 12px 26px rgba(37, 99, 235, .14);
        }

        .result-icon--error {
            color: var(--kiosk-red);
            background: #fef2f2;
        }

        .result-title {
            margin: 0;
            color: var(--kiosk-navy);
            font-size: clamp(1.28rem, 2.5vw, 1.72rem);
            font-weight: 760;
            letter-spacing: -.02em;
            line-height: 1.2;
        }

        .result-copy {
            max-width: 330px;
            margin: 10px auto 0;
            color: var(--kiosk-muted);
            font-size: .92rem;
            line-height: 1.55;
        }

        .person-photo,
        .person-placeholder {
            width: 112px;
            height: 112px;
            margin: 0 auto 16px;
            border-radius: 50%;
            border: 5px solid #fff;
            box-shadow: 0 12px 28px rgba(15, 23, 42, .16);
        }

        .person-photo {
            display: block;
            object-fit: cover;
            background: #e2e8f0;
        }

        .person-placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            background: #e2e8f0;
            font-size: 2.4rem;
        }

        .person-name {
            margin: 0;
            color: var(--kiosk-navy);
            font-size: clamp(1.3rem, 2.6vw, 1.8rem);
            font-weight: 780;
            letter-spacing: -.025em;
            line-height: 1.2;
            overflow-wrap: anywhere;
        }

        .person-id {
            display: inline-flex;
            margin-top: 8px;
            padding: 5px 10px;
            color: #475569;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 999px;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            font-size: .78rem;
            font-weight: 700;
        }

        .person-meta {
            margin: 10px 0 0;
            color: var(--kiosk-muted);
            font-size: .88rem;
            line-height: 1.45;
            overflow-wrap: anywhere;
        }

        .attendance-tags {
            margin-top: 17px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .attendance-tag {
            min-height: 30px;
            padding: 6px 11px;
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            font-size: .76rem;
            font-weight: 800;
            line-height: 1;
        }

        .attendance-tag--success {
            color: #166534;
            background: #dcfce7;
        }

        .attendance-tag--warning {
            color: #92400e;
            background: #fef3c7;
        }

        .attendance-tag--primary {
            color: #1e40af;
            background: #dbeafe;
        }

        .recorded-label {
            margin-top: 22px;
            color: #94a3b8;
            font-size: .7rem;
            font-weight: 800;
            letter-spacing: .12em;
            text-transform: uppercase;
        }

        .recorded-time {
            margin-top: 4px;
            color: var(--kiosk-navy);
            font-size: clamp(1.8rem, 4vw, 2.35rem);
            font-weight: 800;
            line-height: 1.05;
        }

        .result-message {
            margin: 14px 0 0;
            color: var(--kiosk-green);
            font-size: .9rem;
            font-weight: 750;
            line-height: 1.4;
        }

        .result-schedule {
            display: block;
            margin-top: 5px;
            color: var(--kiosk-muted);
            font-size: .78rem;
            line-height: 1.4;
        }

        .error-message {
            max-width: 340px;
            margin: 11px auto 0;
            color: var(--kiosk-red);
            font-size: .94rem;
            font-weight: 650;
            line-height: 1.5;
        }

        .error-help {
            display: block;
            max-width: 330px;
            margin: 8px auto 0;
            color: var(--kiosk-muted);
            font-size: .8rem;
            line-height: 1.45;
        }

        .kiosk-state-card {
            min-height: 420px;
            padding: clamp(36px, 7vw, 78px) clamp(20px, 5vw, 50px);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .state-content {
            max-width: 520px;
        }

        .state-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            background: #f1f5f9;
            border-radius: 28px;
            font-size: 2.7rem;
        }

        .state-icon--danger {
            color: var(--kiosk-red);
            background: #fef2f2;
        }

        .kiosk-footer {
            padding: 0 clamp(16px, 3vw, 34px) max(16px, env(safe-area-inset-bottom));
            color: #7b8ba1;
            font-size: .76rem;
            line-height: 1.4;
            text-align: center;
        }

        .pulse-icon {
            animation: kioskPulse 2.1s ease-in-out infinite;
        }

        @keyframes kioskPulse {

            0%,
            100% {
                transform: scale(1);
                box-shadow: 0 12px 26px rgba(37, 99, 235, .14);
            }

            50% {
                transform: scale(1.045);
                box-shadow: 0 15px 34px rgba(37, 99, 235, .23);
            }
        }

        @media (max-width: 991.98px) {
            .kiosk-main {
                align-items: flex-start;
            }

            .kiosk-workspace {
                grid-template-columns: 1fr;
            }

            .confirmation-panel {
                border-top: 1px solid var(--kiosk-border);
                border-left: 0;
            }

            .result-surface {
                max-width: 680px;
                min-height: 310px;
            }
        }

        @media (max-width: 640px) {
            .kiosk-header-inner {
                min-height: 68px;
                padding-right: 14px;
                padding-left: 14px;
                gap: 10px;
            }

            .brand-logo,
            .brand-mark {
                width: 42px;
                height: 42px;
                flex-basis: 42px;
                border-radius: 12px;
            }

            .kiosk-clock-wrap {
                max-width: 84px;
            }

            #kioskClock {
                font-size: .88rem;
            }

            #kioskDate {
                display: none;
            }

            .kiosk-main {
                padding: 12px;
            }

            .kiosk-workspace,
            .kiosk-state-card {
                border-radius: 18px;
            }

            .scanner-panel,
            .confirmation-panel {
                padding: 17px;
            }

            .panel-heading {
                margin-bottom: 15px;
                flex-direction: column;
                gap: 11px;
            }

            .camera-status {
                align-self: flex-start;
                min-height: 32px;
                padding: 6px 10px;
            }

            .camera-card {
                padding: 8px;
                border-radius: 15px;
            }

            .camera-surface {
                border-radius: 11px;
            }

            .scan-guide {
                inset: 15% 19%;
            }

            .scan-guide span {
                width: 28px;
                height: 28px;
            }

            .start-button {
                min-height: 50px;
                border-radius: 12px;
            }

            .attendance-note {
                padding: 12px 13px;
                font-size: .82rem;
            }

            .privacy-note {
                font-size: .72rem;
            }

            .confirmation-panel {
                display: none;
            }

            .confirmation-panel.has-result {
                position: fixed;
                inset: 0;
                z-index: 120;
                padding: max(18px, env(safe-area-inset-top)) 16px max(18px, env(safe-area-inset-bottom));
                display: flex;
                overflow-y: auto;
                background: rgba(238, 243, 249, .96);
                border: 0;
                backdrop-filter: blur(10px);
            }

            .result-surface {
                min-height: 285px;
                padding: 24px 18px;
                border-radius: 17px;
            }

            .result-icon {
                width: 78px;
                height: 78px;
                margin-bottom: 18px;
                border-radius: 23px;
                font-size: 2rem;
            }

            .person-photo,
            .person-placeholder {
                width: 96px;
                height: 96px;
                margin-bottom: 13px;
            }

            .kiosk-footer {
                padding-top: 2px;
                font-size: .7rem;
            }
        }

        @media (max-width: 374px) {
            .brand-subtitle {
                max-width: 185px;
            }

            .kiosk-clock-wrap {
                display: none;
            }

            .camera-placeholder-icon {
                width: 64px;
                height: 64px;
            }

            .scan-guide {
                inset: 16% 17%;
            }
        }

        @media (max-height: 650px) and (min-width: 992px) {
            .kiosk-header-inner {
                min-height: 66px;
            }

            .kiosk-main {
                padding-top: 18px;
                padding-bottom: 18px;
            }

            .scanner-panel,
            .confirmation-panel {
                padding-top: 22px;
                padding-bottom: 22px;
            }

            .camera-surface {
                max-height: 430px;
            }

            .result-surface {
                min-height: 360px;
            }
        }

        @media (prefers-reduced-motion: reduce) {

            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>

<body>
    <div class="kiosk-shell">
        <header class="kiosk-header">
            <div class="kiosk-header-inner">
                <div class="kiosk-brand">
                    <?php if ($logoUrl): ?>
                        <img class="brand-logo" src="<?= e($logoUrl) ?>" alt="Organization logo">
                    <?php else: ?>
                        <span class="brand-mark" aria-hidden="true"><i class="fas fa-qrcode fa-lg"></i></span>
                    <?php endif; ?>
                    <div class="brand-copy">
                        <strong class="brand-name"><?= e($organization) ?></strong>
                        <span class="brand-subtitle"><?= e($title) ?> &middot; <?= e($location) ?></span>
                    </div>
                </div>
                <div class="kiosk-clock-wrap" aria-label="Current date and time">
                    <div id="kioskClock" class="clock"></div>
                    <small id="kioskDate"></small>
                </div>
            </div>
        </header>

        <main class="kiosk-main">
            <?php if (!$enabled): ?>
                <section class="kiosk-state-card">
                    <div class="state-content">
                        <div class="state-icon"><i class="fas fa-power-off"></i></div>
                        <h1 class="result-title">Attendance Kiosk Disabled</h1>
                        <p class="result-copy">This self-service attendance page is currently unavailable. Please contact an
                            administrator.</p>
                    </div>
                </section>
            <?php elseif (!$authorized): ?>
                <section class="kiosk-state-card">
                    <div class="state-content">
                        <div class="state-icon state-icon--danger"><i class="fas fa-lock"></i></div>
                        <h1 class="result-title">Invalid Kiosk Link</h1>
                        <p class="result-copy">Open the complete kiosk URL provided by an administrator to access this
                            scanner.</p>
                    </div>
                </section>
            <?php else: ?>
                <div class="kiosk-workspace">
                    <section class="scanner-panel">
                        <div class="panel-heading">
                            <div class="panel-title-wrap">
                                <p class="panel-eyebrow">Self-service attendance</p>
                                <h1 class="panel-title">Scan Your QR Code</h1>
                                <p class="panel-description">Hold your QR card steadily inside the frame. Attendance will be
                                    recorded automatically.</p>
                            </div>
                            <div class="camera-status" role="status">
                                <span id="statusDot" class="status-dot"></span>
                                <span id="cameraState">Starting camera</span>
                            </div>
                        </div>

                        <div class="camera-card">
                            <div id="cameraSurface" class="camera-surface">
                                <div id="reader"></div>
                                <div class="camera-placeholder" id="cameraPlaceholder">
                                    <span class="camera-placeholder-icon"><i class="fas fa-camera"></i></span>
                                    <strong>Camera preview</strong>
                                    <small>Allow camera access when prompted, then place the QR code inside the
                                        guide.</small>
                                </div>
                                <div class="scan-guide" aria-hidden="true">
                                    <span class="top-left"></span>
                                    <span class="top-right"></span>
                                    <span class="bottom-left"></span>
                                    <span class="bottom-right"></span>
                                </div>
                            </div>
                            <p class="camera-caption"><i class="fas fa-mobile-alt"></i> Keep the QR code clear, flat, and
                                well lit.</p>
                        </div>

                        <button id="startScanner" type="button" class="start-button">
                            <i class="fas fa-camera"></i><span>Start Camera</span>
                        </button>

                        <div class="attendance-note">
                            <i class="fas fa-info-circle"></i>
                            <div><strong>Automatic attendance:</strong> your first accepted scan records Time In. Your next
                                accepted scan records Time Out.</div>
                        </div>
                        <p class="privacy-note"><i class="fas fa-shield-alt mr-1"></i>Camera video is processed only for QR
                            detection and is not stored by this page.</p>
                    </section>

                    <aside id="confirmationPanel" class="confirmation-panel" aria-live="polite" aria-atomic="true">
                        <div class="result-surface">
                            <div id="resultPanel">
                                <div class="result-icon result-icon--ready pulse-icon"><i class="fas fa-qrcode"></i></div>
                                <h2 class="result-title">Ready for Attendance</h2>
                                <p class="result-copy">Your attendance confirmation will appear here after a valid scan.</p>
                            </div>
                        </div>
                    </aside>
                </div>
            <?php endif; ?>
        </main>

        <footer class="kiosk-footer">Universal QR Attendance &middot; Public self-service kiosk</footer>
    </div>

    <?php if ($enabled && $authorized): ?>
        <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
        <script>
            const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
            const scanApiUrl = <?= json_encode($scanApiUrl, JSON_UNESCAPED_SLASHES) ?>;
            const publicBase = <?= json_encode($publicBase, JSON_UNESCAPED_SLASHES) ?>;
            const autoStart = <?= $autoStart ? 'true' : 'false' ?>;
            const confirmationMilliseconds = <?= (int) $confirmationSeconds * 1000 ?>;
            const successSound = <?= setting('scanner_success_sound', '1') === '1' ? 'true' : 'false' ?>;
            let scanner = null;
            let started = false;
            let busy = false;
            let resetTimer = null;
            let lastSuccessfulToken = '';
            let lastSuccessfulAt = 0;

            function escapeHtml(value) {
                return String(value ?? '').replace(/[&<>'"]/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'}[char]));
            }

            function setCameraState(text, active = false) {
                document.getElementById('cameraState').textContent = text;
                document.getElementById('statusDot').classList.toggle('active', active);
            }

            function setCameraLive(active) {
                document.getElementById('cameraSurface').classList.toggle('camera-live', active);
            }

            function beep(ok = true) {
                if (!successSound) return;
                try {
                    const context = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = context.createOscillator();
                    const gain = context.createGain();
                    oscillator.frequency.value = ok ? 880 : 220;
                    oscillator.connect(gain);
                    gain.connect(context.destination);
                    gain.gain.value = .08;
                    oscillator.start();
                    oscillator.stop(context.currentTime + (ok ? .16 : .28));
                } catch (error) { }
            }

            function setResultVisibility(active) {
                document.getElementById('confirmationPanel').classList.toggle('has-result', active);
            }

            function readyPanel() {
                document.getElementById('resultPanel').innerHTML = `
        <div class="result-icon result-icon--ready pulse-icon"><i class="fas fa-qrcode"></i></div>
        <h2 class="result-title">Ready for Attendance</h2>
        <p class="result-copy">Your attendance confirmation will appear here after a valid scan.</p>`;
                setResultVisibility(false);
            }

            function renderResult(data) {
                clearTimeout(resetTimer);
                const panel = document.getElementById('resultPanel');
                setResultVisibility(true);

                if (!data.success) {
                    panel.innerHTML = `
            <div class="result-icon result-icon--error"><i class="fas fa-times"></i></div>
            <h2 class="result-title">Scan Not Accepted</h2>
            <p class="error-message">${escapeHtml(data.message)}</p>
            <small class="error-help">Check your QR card or ask an operator for assistance.</small>`;
                    resetTimer = setTimeout(readyPanel, confirmationMilliseconds);
                    return;
                }

                const photo = data.person.photo
                    ? `<img class="person-photo" src="${publicBase}${encodeURI(data.person.photo)}" alt="Photo of ${escapeHtml(data.person.full_name)}">`
                    : `<div class="person-placeholder"><i class="fas fa-user"></i></div>`;
                const statusClass = data.status === 'Late' ? 'warning' : 'success';
                const actionLabel = data.action === 'time_out' ? 'Time Out' : 'Time In';

                panel.innerHTML = `
        ${photo}
        <h2 class="person-name">${escapeHtml(data.person.full_name)}</h2>
        <span class="person-id">${escapeHtml(data.person.person_id)}</span>
        <p class="person-meta">${escapeHtml(data.person.category)} &middot; ${escapeHtml(data.person.department)}</p>
        <div class="attendance-tags">
            <span class="attendance-tag attendance-tag--${statusClass}">${escapeHtml(data.status)}</span>
            <span class="attendance-tag attendance-tag--primary">${actionLabel}</span>
        </div>
        <div class="recorded-label">Recorded at</div>
        <div class="recorded-time clock">${escapeHtml(data.time)}</div>
        <p class="result-message"><i class="fas fa-check-circle mr-1"></i>${escapeHtml(data.message)}</p>
        <small class="result-schedule">${escapeHtml(data.schedule)}</small>`;
                resetTimer = setTimeout(readyPanel, confirmationMilliseconds);
            }

            async function submitScan(value) {
                const normalizedValue = String(value).trim();
                if (busy || !normalizedValue) return;
                if (normalizedValue === lastSuccessfulToken && Date.now() - lastSuccessfulAt < 30000) return;

                busy = true;
                setCameraState('Recording attendance', true);

                try {
                    const response = await fetch(scanApiUrl, {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
                        body: JSON.stringify({_token: csrfToken, token: normalizedValue})
                    });
                    const data = await response.json();
                    renderResult(data);
                    if (data.success) {
                        lastSuccessfulToken = normalizedValue;
                        lastSuccessfulAt = Date.now();
                    }
                    beep(data.success);
                } catch (error) {
                    renderResult({success: false, message: 'Unable to reach the attendance server.'});
                    beep(false);
                }

                setTimeout(() => {
                    busy = false;
                    setCameraState(started ? 'Camera active' : 'Camera stopped', started);
                }, 2200);
            }

            function responsiveQrBox(viewfinderWidth, viewfinderHeight) {
                const shortestSide = Math.min(viewfinderWidth, viewfinderHeight);
                const size = Math.floor(Math.min(300, Math.max(180, shortestSide * .62)));
                return {width: size, height: size};
            }

            async function startScanner() {
                if (started) return;

                const button = document.getElementById('startScanner');
                const buttonLabel = button.querySelector('span');
                button.disabled = true;
                buttonLabel.textContent = 'Requesting Camera';
                setCameraState('Requesting camera', false);
                scanner = scanner || new Html5Qrcode('reader');

                try {
                    await scanner.start(
                        {facingMode: 'environment'},
                        {fps: 10, qrbox: responsiveQrBox, aspectRatio: 4 / 3},
                        decodedText => submitScan(decodedText),
                        () => { }
                    );
                    started = true;
                    setCameraLive(true);
                    setCameraState('Camera active', true);
                    button.classList.add('d-none');
                } catch (error) {
                    setCameraLive(false);
                    setCameraState('Camera permission needed', false);
                    button.disabled = false;
                    button.querySelector('i').className = 'fas fa-redo';
                    buttonLabel.textContent = 'Allow Camera & Try Again';
                    renderResult({success: false, message: 'Camera could not start. Allow camera permission, then try again.'});
                }
            }

            function updateClock() {
                const now = new Date();
                document.getElementById('kioskClock').textContent = now.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', second: '2-digit'});
                document.getElementById('kioskDate').textContent = now.toLocaleDateString([], {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'});
            }

            document.getElementById('startScanner').addEventListener('click', startScanner);
            updateClock();
            setInterval(updateClock, 1000);
            if (autoStart) window.addEventListener('load', () => setTimeout(startScanner, 350));
        </script>
    <?php endif; ?>
</body>

</html>