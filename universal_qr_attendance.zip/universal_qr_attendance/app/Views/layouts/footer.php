</div>
</section>
</div>
<footer class="main-footer"><strong>&copy; <?= date('Y') ?>
        <?= e(setting('organization_name', 'Universal Organization')) ?>.</strong>
    <div class="float-right d-none d-sm-inline">QR Attendance: codeastro.com</div>
</footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>document.querySelectorAll('form[data-confirm]').forEach(f => f.addEventListener('submit', e => {e.preventDefault(); Swal.fire({title: 'Are you sure?', text: f.dataset.confirm || 'This action cannot be undone.', icon: 'warning', showCancelButton: true, confirmButtonText: 'Continue'}).then(r => {if (r.isConfirmed) f.submit()})}));</script>
<?php if (!empty($pageScript))
    echo $pageScript; ?></body>

</html>