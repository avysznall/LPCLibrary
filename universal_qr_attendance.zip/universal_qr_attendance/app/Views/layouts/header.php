<?php
use App\Core\Auth;
use App\Core\Database;
$user = Auth::user();
$current = trim($_GET['route'] ?? 'dashboard', '/');
$unread = (int) (Database::fetch('SELECT COUNT(*) c FROM notifications WHERE is_read=0 AND (user_id IS NULL OR user_id=?)', [Auth::id()])['c'] ?? 0);
$notices = Database::fetchAll('SELECT * FROM notifications WHERE is_read=0 AND (user_id IS NULL OR user_id=?) ORDER BY created_at DESC LIMIT 6', [Auth::id()]);
$org = setting('organization_name', 'Universal Organization');
$logo = setting('organization_logo', '');
function nav_active(string|array $route, string $current): string
{
    $routes = (array) $route;
    foreach ($routes as $r)
        if ($current === $r || str_starts_with($current, $r . '/'))
            return 'active';
    return '';
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?= e(\App\Core\Csrf::token()) ?>">
    <title><?= e($title ?? 'Dashboard') ?> | <?= e($org) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <style>
        :root {
            --brand: #0f172a
        }

        .brand-link {
            background: var(--brand) !important
        }

        .main-sidebar {
            background: var(--brand)
        }

        .content-wrapper {
            background: #f4f6f9
        }

        .table td,
        .table th {
            vertical-align: middle
        }

        .avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            object-fit: cover;
            background: #e9ecef
        }

        .avatar-lg {
            width: 120px;
            height: 120px;
            border-radius: 10px;
            object-fit: cover;
            background: #e9ecef
        }

        .filter-card {
            border-top: 3px solid #6c5ce7
        }

        .qr-preview {
            max-width: 280px;
            width: 100%
        }

        .required:after {
            content: ' *';
            color: #dc3545
        }

        .content-header h1 {
            font-weight: 600
        }

        .small-box .icon>i {
            font-size: 58px;
            top: 18px
        }

        .nav-sidebar .nav-link {
            margin-bottom: 3px
        }

        .table-responsive {
            min-height: 120px
        }
    </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block"><a href="<?= url('attendance/scanner') ?>"
                        class="nav-link"><i class="fas fa-qrcode mr-1"></i> Scanner</a></li>
                <?php if (setting('public_kiosk_enabled', '1') === '1'):
                    $kioskNavUrl = rtrim(config('url'), '/') . '/kiosk.php';
                    $kioskNavKey = trim((string) setting('kiosk_access_key', ''));
                    if ($kioskNavKey !== '')
                        $kioskNavUrl .= '?' . http_build_query(['key' => $kioskNavKey]); ?>
                    <li class="nav-item d-none d-md-inline-block"><a href="<?= e($kioskNavUrl) ?>" target="_blank"
                            rel="noopener" class="nav-link"><i class="fas fa-desktop mr-1"></i> Public Kiosk</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown"><a class="nav-link" data-toggle="dropdown" href="#"><i
                            class="far fa-bell"></i><?php if ($unread): ?><span
                                class="badge badge-warning navbar-badge"><?= $unread ?></span><?php endif; ?></a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right"><span
                            class="dropdown-item dropdown-header"><?= $unread ?> unread notification(s)</span>
                        <div class="dropdown-divider"></div><?php foreach ($notices as $n): ?>
                            <form method="post" action="<?= url('notifications/read') ?>"><?= csrf_field() ?><input
                                    type="hidden" name="id" value="<?= $n['id'] ?>"><input type="hidden" name="target"
                                    value="<?= e($n['url']) ?>"><button class="dropdown-item text-left"><i
                                        class="fas fa-info-circle mr-2"></i><?= e($n['title']) ?><span
                                        class="float-right text-muted text-sm"><?= e(date('d M', strtotime($n['created_at']))) ?></span></button>
                            </form>
                            <div class="dropdown-divider"></div><?php endforeach; ?><a href="<?= url('notifications') ?>"
                            class="dropdown-item dropdown-footer">View all notifications</a>
                    </div>
                </li>
                <li class="nav-item dropdown"><a class="nav-link" data-toggle="dropdown" href="#"><i
                            class="far fa-user mr-1"></i><span
                            class="d-none d-md-inline"><?= e($user['full_name']) ?></span></a>
                    <div class="dropdown-menu dropdown-menu-right"><a href="<?= url('profile') ?>"
                            class="dropdown-item"><i class="fas fa-id-card mr-2"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <form method="post" action="<?= url('logout') ?>"><?= csrf_field() ?><button
                                class="dropdown-item text-danger"><i class="fas fa-sign-out-alt mr-2"></i> Sign
                                out</button></form>
                    </div>
                </li>
            </ul>
        </nav>
        <aside class="main-sidebar sidebar-dark-primary elevation-4"><a href="<?= url('dashboard') ?>"
                class="brand-link"><?php if ($logo): ?><img src="<?= upload_url($logo) ?>"
                        class="brand-image img-circle elevation-2" style="opacity:.9"><?php else: ?><span
                        class="brand-image text-center"><i class="fas fa-qrcode"></i></span><?php endif; ?><span
                    class="brand-text font-weight-light"><?= e(mb_strimwidth($org, 0, 22, '…')) ?></span></a>
            <div class="sidebar">
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image"><?php if ($user['photo']): ?><img src="<?= upload_url($user['photo']) ?>"
                                class="img-circle elevation-2" alt="User"><?php else: ?><span
                                class="d-inline-flex align-items-center justify-content-center bg-secondary img-circle"
                                style="width:34px;height:34px"><i class="fas fa-user"></i></span><?php endif; ?></div>
                    <div class="info"><a href="<?= url('profile') ?>" class="d-block"><?= e($user['full_name']) ?></a><small
                            class="text-muted"><?= e($user['role_name']) ?></small></div>
                </div>
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <li class="nav-item"><a href="<?= url('dashboard') ?>"
                                class="nav-link <?= nav_active('dashboard', $current) ?>"><i
                                    class="nav-icon fas fa-tachometer-alt"></i>
                                <p>Dashboard</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('attendance/scanner') ?>"
                                class="nav-link <?= nav_active('attendance/scanner', $current) ?>"><i
                                    class="nav-icon fas fa-camera"></i>
                                <p>QR Scanner</p>
                            </a></li>
                        <li class="nav-header">ATTENDANCE</li>
                        <li class="nav-item"><a href="<?= url('attendance') ?>"
                                class="nav-link <?= ($current === 'attendance' || str_starts_with($current, 'attendance/edit') || str_starts_with($current, 'attendance/manual')) ? 'active' : '' ?>"><i
                                    class="nav-icon fas fa-clipboard-check"></i>
                                <p>Attendance Logs</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('reports') ?>"
                                class="nav-link <?= nav_active('reports', $current) ?>"><i
                                    class="nav-icon fas fa-chart-bar"></i>
                                <p>Reports & Export</p>
                            </a></li>
                        <li class="nav-header">PEOPLE & RULES</li>
                        <li class="nav-item"><a href="<?= url('people') ?>"
                                class="nav-link <?= nav_active('people', $current) ?>"><i
                                    class="nav-icon fas fa-users"></i>
                                <p>People</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('categories') ?>"
                                class="nav-link <?= nav_active('categories', $current) ?>"><i
                                    class="nav-icon fas fa-tags"></i>
                                <p>Categories</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('departments') ?>"
                                class="nav-link <?= nav_active('departments', $current) ?>"><i
                                    class="nav-icon fas fa-sitemap"></i>
                                <p>Departments / Groups</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('schedules') ?>"
                                class="nav-link <?= nav_active('schedules', $current) ?>"><i
                                    class="nav-icon fas fa-calendar-alt"></i>
                                <p>Schedules</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('holidays') ?>"
                                class="nav-link <?= nav_active('holidays', $current) ?>"><i
                                    class="nav-icon fas fa-umbrella-beach"></i>
                                <p>Holidays</p>
                            </a></li>
                        <li class="nav-item"><a href="<?= url('announcements') ?>"
                                class="nav-link <?= nav_active('announcements', $current) ?>"><i
                                    class="nav-icon fas fa-bullhorn"></i>
                                <p>Announcements</p>
                            </a></li>
                        <?php if (\App\Core\Auth::isAdmin()): ?>
                            <li class="nav-header">ADMINISTRATION</li>
                            <li class="nav-item"><a href="<?= url('users') ?>"
                                    class="nav-link <?= nav_active('users', $current) ?>"><i
                                        class="nav-icon fas fa-user-shield"></i>
                                    <p>System Users</p>
                                </a></li>
                            <li class="nav-item"><a href="<?= url('activity-logs') ?>"
                                    class="nav-link <?= nav_active('activity-logs', $current) ?>"><i
                                        class="nav-icon fas fa-history"></i>
                                    <p>Activity Logs</p>
                                </a></li><?php endif; ?>
                        <?php if (\App\Core\Auth::role() === 'super-administrator'): ?>
                            <li class="nav-item"><a href="<?= url('settings') ?>"
                                    class="nav-link <?= nav_active('settings', $current) ?>"><i
                                        class="nav-icon fas fa-cogs"></i>
                                    <p>System Settings</p>
                                </a></li><?php endif; ?>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-8">
                            <h1><?= e($title ?? '') ?></h1>
                        </div>
                        <div class="col-sm-4">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?= url('dashboard') ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= e($title ?? '') ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>
            <section class="content">
                <div class="container-fluid"><?php if ($msg = flash('success')): ?>
                        <div class="alert alert-success alert-dismissible"><button class="close"
                                data-dismiss="alert">&times;</button><?= e($msg) ?></div>
                    <?php endif; ?><?php if ($msg = flash('error')): ?>
                        <div class="alert alert-danger alert-dismissible"><button class="close"
                                data-dismiss="alert">&times;</button><?= e($msg) ?></div><?php endif; ?>