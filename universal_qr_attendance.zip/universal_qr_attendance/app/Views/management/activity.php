<div class="card filter-card">
    <div class="card-body">
        <form method="get" class="form-inline"><input type="hidden" name="route" value="activity-logs"><input
                class="form-control mr-2" style="min-width:320px" name="q" value="<?= e($_GET['q'] ?? '') ?>"
                placeholder="Search action, user, or details"><button class="btn btn-primary mr-2"><i
                    class="fas fa-search"></i></button><a href="<?= url('activity-logs') ?>"
                class="btn btn-light">Reset</a></form>
    </div>
</div>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">User Actions and System Audit Trail</h3>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-hover mb-0">
            <thead>
                <tr>
                    <th>Date / Time</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Details</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody><?php foreach ($items as $i): ?>
                    <tr>
                        <td><?= date('d M Y h:i:s A', strtotime($i['created_at'])) ?></td>
                        <td><?= e($i['full_name'] ?: 'System / Guest') ?></td>
                        <td><span class="badge badge-light border"><?= e($i['action']) ?></span></td>
                        <td><?= e($i['entity_type'] ?: '—') ?><?= isset($i['entity_id']) && $i['entity_id'] !== null ? ' #' . e($i['entity_id']) : '' ?>
                        </td>
                        <td style="max-width:400px;white-space:normal"><?= e(mb_strimwidth($i['details'] ?: '—', 0, 300, '…')) ?>
                        </td>
                        <td><code><?= e($i['ip_address'] ?: '—') ?></code></td>
                    </tr><?php endforeach; ?><?php if (!$items): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No activity logs matched.</td>
                    </tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer d-flex justify-content-between"><small><?= $p['total'] ?> logged
            action(s)</small><?= pagination_links($p) ?></div>
</div>