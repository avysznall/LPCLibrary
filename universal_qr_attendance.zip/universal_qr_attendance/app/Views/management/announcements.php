<div class="row">
    <div class="col-lg-5"><?php if (\App\Core\Auth::isAdmin()): ?>
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title" id="formTitle">New Announcement</h3>
                </div>
                <form method="post" action="<?= url('announcements/save') ?>"><?= csrf_field() ?><input type="hidden" name="id"
                        id="itemId">
                    <div class="card-body">
                        <div class="form-group"><label class="required">Title</label><input class="form-control"
                                name="title" id="itemTitle" required></div>
                        <div class="form-group"><label class="required">Message</label><textarea class="form-control"
                                name="message" id="itemMessage" rows="5" required></textarea></div>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Starts At</label><input type="datetime-local"
                                    class="form-control" name="starts_at" id="itemStart"></div>
                            <div class="form-group col-md-6"><label>Ends At</label><input type="datetime-local"
                                    class="form-control" name="ends_at" id="itemEnd"></div>
                        </div>
                        <div class="form-group"><label>Status</label><select class="form-control" name="status"
                                id="itemStatus">
                                <option>Active</option>
                                <option>Inactive</option>
                            </select></div>
                    </div>
                    <div class="card-footer"><button class="btn btn-primary">Save Announcement</button><button type="button"
                            class="btn btn-light" onclick="resetForm()">Clear</button></div>
                </form>
            </div><?php endif; ?>
    </div>
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">System Announcements</h3>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush"><?php foreach ($items as $i): ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between">
                                <h5 class="mb-1"><?= e($i['title']) ?></h5><span
                                    class="badge badge-<?= badge_class($i['status']) ?>"><?= e($i['status']) ?></span>
                            </div>
                            <p class="mb-2"><?= nl2br(e($i['message'])) ?></p><small
                                class="text-muted"><?= e($i['creator_name'] ?: 'System') ?> ·
                                <?= date('d M Y h:i A', strtotime($i['created_at'])) ?></small><?php if (\App\Core\Auth::isAdmin()): ?>
                                <div class="float-right"><button class="btn btn-xs btn-warning"
                                        onclick='editAnnouncement(<?= json_encode($i, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i
                                            class="fas fa-edit"></i></button>
                                    <form method="post" action="<?= url('announcements/delete') ?>" class="d-inline"
                                        data-confirm="Delete this announcement?"><?= csrf_field() ?><input type="hidden" name="id"
                                            value="<?= $i['id'] ?>"><button class="btn btn-xs btn-danger"><i
                                                class="fas fa-trash"></i></button></form>
                                </div><?php endif; ?>
                        </div><?php endforeach; ?><?php if (!$items): ?>
                        <div class="list-group-item text-muted">No announcements.</div><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $pageScript = '<script>function dt(v){return v?String(v).replace(" ","T").slice(0,16):""}function editAnnouncement(i){itemId.value=i.id;itemTitle.value=i.title;itemMessage.value=i.message;itemStart.value=dt(i.starts_at);itemEnd.value=dt(i.ends_at);itemStatus.value=i.status;formTitle.textContent="Edit Announcement";window.scrollTo({top:0,behavior:"smooth"})}function resetForm(){itemId.value="";itemTitle.value="";itemMessage.value="";itemStart.value="";itemEnd.value="";itemStatus.value="Active";formTitle.textContent="New Announcement"}</script>'; ?>