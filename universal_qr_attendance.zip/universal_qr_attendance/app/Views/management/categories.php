<div class="row">
    <div class="col-lg-4"><?php if (\App\Core\Auth::isAdmin()): ?>
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title" id="formTitle">Add Category</h3>
                </div>
                <form method="post" action="<?= url('categories/save') ?>"><?= csrf_field() ?><input type="hidden" name="id"
                        id="itemId">
                    <div class="card-body">
                        <div class="form-group"><label class="required">Category Name</label><input class="form-control"
                                name="name" id="itemName" placeholder="e.g., Student or Employee" required></div>
                        <div class="form-group"><label>Description</label><textarea class="form-control" name="description"
                                id="itemDescription" rows="3"></textarea></div>
                        <div class="form-group"><label>Status</label><select class="form-control" name="status"
                                id="itemStatus">
                                <option>Active</option>
                                <option>Inactive</option>
                            </select></div>
                    </div>
                    <div class="card-footer"><button class="btn btn-primary">Save Category</button><button type="button"
                            class="btn btn-light" onclick="resetForm()">Clear</button></div>
                </form>
            </div><?php else: ?>
            <div class="alert alert-info">Your role has read-only access to categories.</div><?php endif; ?>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Configurable Categories</h3>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>People</th>
                            <th>Status</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody><?php foreach ($items as $i): ?>
                            <tr>
                                <td><strong><?= e($i['name']) ?></strong></td>
                                <td><?= e($i['description'] ?: '—') ?></td>
                                <td><?= $i['people_count'] ?></td>
                                <td><span class="badge badge-<?= badge_class($i['status']) ?>"><?= e($i['status']) ?></span>
                                </td>
                                <td class="text-right"><?php if (\App\Core\Auth::isAdmin()): ?><button
                                            class="btn btn-xs btn-warning"
                                            onclick='editCategory(<?= json_encode($i, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i
                                                class="fas fa-edit"></i></button>
                                        <form method="post" action="<?= url('categories/delete') ?>" class="d-inline"
                                            data-confirm="Delete this category?"><?= csrf_field() ?><input type="hidden" name="id"
                                                value="<?= $i['id'] ?>"><button class="btn btn-xs btn-danger"
                                                <?= $i['people_count'] ? 'disabled' : '' ?>><i class="fas fa-trash"></i></button>
                                        </form><?php endif; ?>
                                </td>
                            </tr><?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $pageScript = '<script>function editCategory(i){itemId.value=i.id;itemName.value=i.name;itemDescription.value=i.description||"";itemStatus.value=i.status;formTitle.textContent="Edit Category";window.scrollTo({top:0,behavior:"smooth"})}function resetForm(){itemId.value="";itemName.value="";itemDescription.value="";itemStatus.value="Active";formTitle.textContent="Add Category"}</script>'; ?>