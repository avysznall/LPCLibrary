<div class="row">
    <div class="col-lg-4"><?php if (\App\Core\Auth::isAdmin()): ?>
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title" id="formTitle">Add Department / Group</h3>
                </div>
                <form method="post" action="<?= url('departments/save') ?>"><?= csrf_field() ?><input type="hidden" name="id"
                        id="itemId">
                    <div class="card-body">
                        <div class="form-group"><label>Parent Group</label><select class="form-control" name="parent_id"
                                id="itemParent">
                                <option value="">None</option><?php foreach ($items as $p): ?>
                                    <option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?>
                            </select></div>
                        <div class="form-group"><label class="required">Name</label><input class="form-control" name="name"
                                id="itemName" required placeholder="e.g., IT or Committee A"></div>
                        <div class="form-group"><label>Code</label><input class="form-control" name="code" id="itemCode"
                                maxlength="40"></div>
                        <div class="form-group"><label>Description</label><textarea class="form-control" name="description"
                                id="itemDescription" rows="2"></textarea></div>
                        <div class="form-group"><label>Status</label><select class="form-control" name="status"
                                id="itemStatus">
                                <option>Active</option>
                                <option>Inactive</option>
                            </select></div>
                    </div>
                    <div class="card-footer"><button class="btn btn-primary">Save Group</button><button type="button"
                            class="btn btn-light" onclick="resetForm()">Clear</button></div>
                </form>
            </div><?php endif; ?>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Departments / Groups</h3>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Parent</th>
                            <th>Code</th>
                            <th>People</th>
                            <th>Status</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody><?php foreach ($items as $i): ?>
                            <tr>
                                <td><strong><?= e($i['name']) ?></strong><br><small><?= e($i['description'] ?: '') ?></small></td>
                                <td><?= e($i['parent_name'] ?: '—') ?></td>
                                <td><?= e($i['code'] ?: '—') ?></td>
                                <td><?= $i['people_count'] ?></td>
                                <td><span class="badge badge-<?= badge_class($i['status']) ?>"><?= e($i['status']) ?></span>
                                </td>
                                <td class="text-right"><?php if (\App\Core\Auth::isAdmin()): ?><button
                                            class="btn btn-xs btn-warning"
                                            onclick='editDepartment(<?= json_encode($i, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i
                                                class="fas fa-edit"></i></button>
                                        <form method="post" action="<?= url('departments/delete') ?>" class="d-inline"
                                            data-confirm="Delete this department/group?"><?= csrf_field() ?><input type="hidden"
                                                name="id" value="<?= $i['id'] ?>"><button class="btn btn-xs btn-danger"
                                                <?= $i['people_count'] ? 'disabled' : '' ?>><i class="fas fa-trash"></i></button>
                                        </form><?php endif; ?>
                                </td>
                            </tr><?php endforeach; ?><?php if (!$items): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">No departments or groups yet.</td>
                            </tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $pageScript = '<script>function editDepartment(i){itemId.value=i.id;itemParent.value=i.parent_id||"";itemName.value=i.name;itemCode.value=i.code||"";itemDescription.value=i.description||"";itemStatus.value=i.status;formTitle.textContent="Edit Department / Group";window.scrollTo({top:0,behavior:"smooth"})}function resetForm(){itemId.value="";itemParent.value="";itemName.value="";itemCode.value="";itemDescription.value="";itemStatus.value="Active";formTitle.textContent="Add Department / Group"}</script>'; ?>