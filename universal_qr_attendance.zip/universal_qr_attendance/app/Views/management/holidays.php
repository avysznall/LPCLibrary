<div class="row">
    <div class="col-lg-4"><?php if (\App\Core\Auth::isAdmin()): ?>
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title" id="formTitle">Add Holiday</h3>
                </div>
                <form method="post" action="<?= url('holidays/save') ?>"><?= csrf_field() ?><input type="hidden" name="id"
                        id="itemId">
                    <div class="card-body">
                        <div class="form-group"><label class="required">Date</label><input type="date" class="form-control"
                                name="holiday_date" id="itemDate" required></div>
                        <div class="form-group"><label class="required">Holiday Name</label><input class="form-control"
                                name="name" id="itemName" required></div>
                        <div class="form-group"><label>Description</label><textarea class="form-control" name="description"
                                id="itemDescription" rows="3"></textarea></div>
                    </div>
                    <div class="card-footer"><button class="btn btn-primary">Save Holiday</button><button type="button"
                            class="btn btn-light" onclick="resetForm()">Clear</button></div>
                </form>
            </div><?php endif; ?>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Holiday Calendar</h3>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody><?php foreach ($items as $i): ?>
                            <tr>
                                <td><?= format_date($i['holiday_date']) ?></td>
                                <td><strong><?= e($i['name']) ?></strong></td>
                                <td><?= e($i['description'] ?: '—') ?></td>
                                <td class="text-right"><?php if (\App\Core\Auth::isAdmin()): ?><button
                                            class="btn btn-xs btn-warning"
                                            onclick='editHoliday(<?= json_encode($i, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i
                                                class="fas fa-edit"></i></button>
                                        <form method="post" action="<?= url('holidays/delete') ?>" class="d-inline"
                                            data-confirm="Delete this holiday?"><?= csrf_field() ?><input type="hidden" name="id"
                                                value="<?= $i['id'] ?>"><button class="btn btn-xs btn-danger"><i
                                                    class="fas fa-trash"></i></button></form><?php endif; ?>
                                </td>
                            </tr><?php endforeach; ?><?php if (!$items): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">No holidays configured.</td>
                            </tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $pageScript = '<script>function editHoliday(i){itemId.value=i.id;itemDate.value=i.holiday_date;itemName.value=i.name;itemDescription.value=i.description||"";formTitle.textContent="Edit Holiday";window.scrollTo({top:0,behavior:"smooth"})}function resetForm(){itemId.value="";itemDate.value="";itemName.value="";itemDescription.value="";formTitle.textContent="Add Holiday"}</script>'; ?>