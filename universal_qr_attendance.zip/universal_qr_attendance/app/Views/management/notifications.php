<div class="card">
    <div class="card-header">
        <h3 class="card-title">In-App Notifications</h3>
        <div class="card-tools">
            <form method="post" action="<?= url('notifications/read-all') ?>"><?= csrf_field() ?><button
                    class="btn btn-sm btn-outline-primary">Mark All Read</button></form>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="list-group list-group-flush"><?php foreach ($items as $n): ?>
                <div class="list-group-item <?= $n['is_read'] ? '' : 'bg-light' ?>">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1"><i
                                    class="fas fa-<?= $n['type'] === 'warning' ? 'exclamation-triangle' : ($n['type'] === 'success' ? 'check-circle' : 'info-circle') ?> mr-2"></i><?= e($n['title']) ?>
                            </h5>
                            <p class="mb-1"><?= e($n['message']) ?></p><small
                                class="text-muted"><?= date('d M Y h:i A', strtotime($n['created_at'])) ?></small>
                        </div><?php if (!$n['is_read']): ?>
                            <form method="post" action="<?= url('notifications/read') ?>"><?= csrf_field() ?><input type="hidden"
                                    name="id" value="<?= $n['id'] ?>"><input type="hidden" name="target"
                                    value="<?= e($n['url']) ?>"><button class="btn btn-sm btn-outline-secondary">Mark
                                    Read</button></form><?php endif; ?>
                    </div>
                </div><?php endforeach; ?><?php if (!$items): ?>
                <div class="list-group-item text-muted text-center py-4">No notifications.</div><?php endif; ?>
        </div>
    </div>
</div>