<?php $v = fn($key, $default = '') => e(old($key, $person[$key] ?? $default)); ?>
<form method="post" action="<?= url($person ? 'people/update' : 'people/store') ?>" enctype="multipart/form-data">
    <?= csrf_field() ?><?php if ($person): ?><input type="hidden" name="id" value="<?= $person['id'] ?>"><?php endif; ?>
    <div class="row">
        <div class="col-md-8">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">Person Details</h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-7"><label class="required">Full Name</label><input
                                class="form-control" name="full_name" value="<?= $v('full_name') ?>" required
                                maxlength="160"></div>
                        <div class="form-group col-md-5"><label>Position / Role</label><input class="form-control"
                                name="position_role" value="<?= $v('position_role') ?>" placeholder="Optional"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4"><label class="required">Category</label><select
                                class="form-control" name="category_id" required>
                                <option value="">Choose</option><?php foreach ($categories as $c): ?>
                                    <option value="<?= $c['id'] ?>"
                                        <?= ((int) old('category_id', $person['category_id'] ?? 0) === $c['id']) ? 'selected' : '' ?>>
                                        <?= e($c['name']) ?></option><?php endforeach; ?>
                            </select></div>
                        <div class="form-group col-md-4"><label>Department / Group</label><select class="form-control"
                                name="department_id">
                                <option value="">None</option><?php foreach ($departments as $d): ?>
                                    <option value="<?= $d['id'] ?>"
                                        <?= ((int) old('department_id', $person['department_id'] ?? 0) === $d['id']) ? 'selected' : '' ?>>
                                        <?= e($d['name']) ?></option><?php endforeach; ?>
                            </select></div>
                        <div class="form-group col-md-4"><label>Direct Schedule</label><select class="form-control"
                                name="schedule_id">
                                <option value="">Use category/department</option><?php foreach ($schedules as $s): ?>
                                    <option value="<?= $s['id'] ?>"
                                        <?= ((int) old('schedule_id', $person['schedule_id'] ?? 0) === $s['id']) ? 'selected' : '' ?>>
                                        <?= e($s['name']) ?></option><?php endforeach; ?>
                            </select></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4"><label>Gender</label><select class="form-control"
                                name="gender">
                                <option value="">Not specified</option>
                                <?php foreach (['Male', 'Female', 'Other', 'Prefer not to say'] as $g): ?>
                                    <option <?= old('gender', $person['gender'] ?? '') === $g ? 'selected' : '' ?>><?= $g ?></option>
                                <?php endforeach; ?>
                            </select></div>
                        <div class="form-group col-md-4"><label>Birthdate</label><input type="date" class="form-control"
                                name="birthdate" value="<?= $v('birthdate') ?>" max="<?= date('Y-m-d') ?>"></div>
                        <div class="form-group col-md-4"><label>Status</label><select class="form-control"
                                name="status">
                                <option <?= old('status', $person['status'] ?? 'Active') === 'Active' ? 'selected' : '' ?>>Active
                                </option>
                                <option <?= old('status', $person['status'] ?? '') === 'Inactive' ? 'selected' : '' ?>>Inactive
                                </option>
                            </select></div>
                    </div>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-6"><label>Contact Number</label><input class="form-control"
                                name="contact_number" value="<?= $v('contact_number') ?>"></div>
                        <div class="form-group col-md-6"><label>Email</label><input type="email" class="form-control"
                                name="email" value="<?= $v('email') ?>"></div>
                    </div>
                    <div class="form-group"><label>Address</label><textarea class="form-control" rows="3"
                            name="address"><?= $v('address') ?></textarea></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Photo & QR</h3>
                </div>
                <div class="card-body">
                    <div class="text-center mb-3"><?php if (!empty($person['photo'])): ?><img
                                src="<?= upload_url($person['photo']) ?>" class="avatar-lg" id="photoPreview"><?php else: ?>
                            <div class="avatar-lg mx-auto d-flex align-items-center justify-content-center"
                                id="photoPlaceholder"><i class="fas fa-user fa-3x text-muted"></i></div><img
                                class="avatar-lg d-none" id="photoPreview"><?php endif; ?>
                    </div>
                    <div class="form-group"><label>Photo</label><input type="file" class="form-control-file"
                            name="photo" id="photoInput" accept="image/png,image/jpeg,image/webp"><small
                            class="text-muted">JPG, PNG, or WebP. Maximum 3 MB.</small></div><?php if ($person): ?>
                        <div class="alert alert-info small"><strong>Person ID:</strong> <?= e($person['person_id']) ?><br>The
                            existing QR remains valid unless you regenerate it from the profile page.</div><?php else: ?>
                        <div class="alert alert-light border small">A unique Person ID and secure QR token will be generated
                            automatically after registration.</div><?php endif; ?>
                </div>
            </div><button class="btn btn-primary btn-block"><i class="fas fa-save mr-1"></i>
                <?= $person ? 'Save Changes' : 'Register & Generate QR' ?></button><a href="<?= url('people') ?>"
                class="btn btn-light btn-block">Cancel</a>
        </div>
    </div>
</form>
<?php $pageScript = '<script>document.getElementById("photoInput").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const img=document.getElementById("photoPreview");img.src=URL.createObjectURL(f);img.classList.remove("d-none");document.getElementById("photoPlaceholder")?.classList.add("d-none")});</script>';
clear_old(); ?>