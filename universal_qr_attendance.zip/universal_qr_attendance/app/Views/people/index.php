<div class="card filter-card">
    <div class="card-body">
        <form method="get"><input type="hidden" name="route" value="people">
            <div class="form-row">
                <div class="form-group col-lg-4"><label>Search</label><input class="form-control" name="q"
                        value="<?= e($_GET['q'] ?? '') ?>" placeholder="Name, Person ID, or email"></div>
                <div class="form-group col-lg-2"><label>Category</label><select class="form-control" name="category_id">
                        <option value="">All</option><?php foreach ($categories as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ((int) ($_GET['category_id'] ?? 0) === $c['id']) ? 'selected' : '' ?>>
                                <?= e($c['name']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-2"><label>Department</label><select class="form-control"
                        name="department_id">
                        <option value="">All</option><?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= ((int) ($_GET['department_id'] ?? 0) === $d['id']) ? 'selected' : '' ?>>
                                <?= e($d['name']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-2"><label>Status</label><select class="form-control" name="status">
                        <option value="">All</option>
                        <option <?= ($_GET['status'] ?? '') === 'Active' ? 'selected' : '' ?>>Active</option>
                        <option <?= ($_GET['status'] ?? '') === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select></div>
                <div class="form-group col-lg-2 d-flex align-items-end"><button class="btn btn-primary mr-2"><i
                            class="fas fa-search"></i></button><a href="<?= url('people') ?>"
                        class="btn btn-light">Reset</a></div>
            </div>
        </form>
    </div>
</div>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Registered People <span class="badge badge-secondary"><?= $p['total'] ?></span></h3>
        <div class="card-tools"><?php if (\App\Core\Auth::isAdmin()): ?>
                <form method="post" action="<?= url('qr/bulk-generate') ?>" class="d-inline"
                    data-confirm="Generate QR images only for active people whose QR image is missing?">
                    <?= csrf_field() ?><button class="btn btn-sm btn-outline-info mr-1"><i class="fas fa-qrcode mr-1"></i>
                        Generate Missing QR</button></form><a href="<?= url('qr/bulk') ?>" target="_blank"
                    class="btn btn-sm btn-outline-secondary mr-1"><i class="fas fa-print mr-1"></i> Bulk QR Cards</a><a
                    href="<?= url('people/create') ?>" class="btn btn-sm btn-primary"><i class="fas fa-plus mr-1"></i>
                    Register Person</a><?php endif; ?>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Person</th>
                    <th>ID / QR</th>
                    <th>Category</th>
                    <th>Department / Group</th>
                    <th>Schedule</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody><?php foreach ($people as $person): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center"><?php if ($person['photo']): ?><img
                                        src="<?= upload_url($person['photo']) ?>" class="avatar mr-2"><?php else: ?><span
                                        class="avatar mr-2 d-flex align-items-center justify-content-center"><i
                                            class="fas fa-user text-muted"></i></span><?php endif; ?>
                                <div><strong><?= e($person['full_name']) ?></strong><br><small
                                        class="text-muted"><?= e($person['email'] ?: 'No email') ?></small></div>
                            </div>
                        </td>
                        <td><code><?= e($person['person_id']) ?></code><br><small
                                class="text-muted"><?= e(substr($person['qr_token'], 0, 12)) ?>…</small></td>
                        <td><?= e($person['category_name']) ?></td>
                        <td><?= e($person['department_name'] ?: '—') ?></td>
                        <td><?= e($person['schedule_name'] ?: 'Inherited assignment') ?></td>
                        <td><span class="badge badge-<?= badge_class($person['status']) ?>"><?= e($person['status']) ?></span>
                        </td>
                        <td class="text-right text-nowrap"><a class="btn btn-xs btn-info"
                                href="<?= url('people/show', ['id' => $person['id']]) ?>"><i
                                    class="fas fa-eye"></i></a><?php if (\App\Core\Auth::isAdmin()): ?><a
                                    class="btn btn-xs btn-warning" href="<?= url('people/edit', ['id' => $person['id']]) ?>"><i
                                        class="fas fa-edit"></i></a>
                                <form method="post" action="<?= url('people/archive') ?>" class="d-inline"
                                    data-confirm="Change this person's active status?"><?= csrf_field() ?><input type="hidden"
                                        name="id" value="<?= $person['id'] ?>"><button
                                        class="btn btn-xs btn-<?= $person['status'] === 'Active' ? 'danger' : 'success' ?>"><i
                                            class="fas fa-<?= $person['status'] === 'Active' ? 'ban' : 'check' ?>"></i></button></form>
                            <?php endif; ?>
                        </td>
                    </tr><?php endforeach; ?><?php if (!$people): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">No people matched your filters.</td>
                    </tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer d-flex justify-content-between"><small>Showing <?= count($people) ?> of <?= $p['total'] ?>
            record(s)</small><?= pagination_links($p) ?></div>
</div>