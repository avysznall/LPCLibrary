<div class="row">
    <div class="col-md-4">
        <div class="card card-primary card-outline">
            <div class="card-body box-profile">
                <div class="text-center"><?php if ($person['photo']): ?><img class="profile-user-img img-fluid img-circle"
                            style="width:110px;height:110px;object-fit:cover"
                            src="<?= upload_url($person['photo']) ?>"><?php else: ?>
                        <div class="mx-auto rounded-circle bg-light d-flex align-items-center justify-content-center"
                            style="width:110px;height:110px"><i class="fas fa-user fa-3x text-muted"></i></div>
                    <?php endif; ?>
                </div>
                <h3 class="profile-username text-center"><?= e($person['full_name']) ?></h3>
                <p class="text-muted text-center"><?= e($person['position_role'] ?: $person['category_name']) ?></p>
                <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item"><b>Person ID</b><span
                            class="float-right"><code><?= e($person['person_id']) ?></code></span></li>
                    <li class="list-group-item"><b>Category</b><span
                            class="float-right"><?= e($person['category_name']) ?></span></li>
                    <li class="list-group-item"><b>Department</b><span
                            class="float-right"><?= e($person['department_name'] ?: '—') ?></span></li>
                    <li class="list-group-item"><b>Schedule</b><span
                            class="float-right"><?= e($person['schedule_name'] ?: 'Inherited') ?></span></li>
                    <li class="list-group-item"><b>Status</b><span
                            class="float-right badge badge-<?= badge_class($person['status']) ?>"><?= e($person['status']) ?></span>
                    </li>
                </ul><?php if (\App\Core\Auth::isAdmin()): ?><a href="<?= url('people/edit', ['id' => $person['id']]) ?>"
                        class="btn btn-primary btn-block"><i class="fas fa-edit mr-1"></i> Edit Person</a><?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">QR Code & Contact Details</h3>
                <div class="card-tools"><a href="<?= url('qr/bulk', ['ids' => [$person['id']]]) ?>" target="_blank"
                        class="btn btn-sm btn-outline-secondary"><i class="fas fa-print mr-1"></i> Print Card</a></div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-5 text-center"><?php if ($person['qr_image']): ?><img
                                src="<?= upload_url($person['qr_image']) ?>" class="qr-preview border p-2 mb-2">
                            <div><a href="<?= url('qr/download', ['id' => $person['id']]) ?>" class="btn btn-sm btn-success"><i
                                        class="fas fa-download mr-1"></i> Download
                                    QR</a><?php if (\App\Core\Auth::isAdmin()): ?>
                                    <form method="post" action="<?= url('qr/regenerate') ?>" class="d-inline"
                                        data-confirm="The current QR code will stop working immediately.">
                                        <?= csrf_field() ?><input type="hidden" name="id" value="<?= $person['id'] ?>"><button
                                            class="btn btn-sm btn-warning"><i class="fas fa-sync mr-1"></i> Regenerate</button>
                                    </form><?php endif; ?>
                            </div><?php else: ?>
                            <div class="alert alert-warning">QR image is missing. Regenerate it.</div><?php endif; ?>
                    </div>
                    <div class="col-md-7">
                        <dl class="row">
                            <dt class="col-sm-4">Gender</dt>
                            <dd class="col-sm-8"><?= e($person['gender'] ?: '—') ?></dd>
                            <dt class="col-sm-4">Birthdate</dt>
                            <dd class="col-sm-8"><?= format_date($person['birthdate']) ?></dd>
                            <dt class="col-sm-4">Contact</dt>
                            <dd class="col-sm-8"><?= e($person['contact_number'] ?: '—') ?></dd>
                            <dt class="col-sm-4">Email</dt>
                            <dd class="col-sm-8"><?= e($person['email'] ?: '—') ?></dd>
                            <dt class="col-sm-4">Address</dt>
                            <dd class="col-sm-8"><?= nl2br(e($person['address'] ?: '—')) ?></dd>
                        </dl>
                        <div class="alert alert-light border small mb-0"><strong>QR validation token:</strong><br><code
                                class="text-break"><?= e($person['qr_token']) ?></code></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Recent Attendance History</h3>
        <div class="card-tools"><a href="<?= url('reports', ['person_id' => $person['id'], 'type' => 'individual']) ?>"
                class="btn btn-sm btn-outline-primary">Full Individual Report</a></div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-hover mb-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Schedule</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Break</th>
                    <th>Status</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody><?php foreach ($history as $r): ?>
                    <tr>
                        <td><?= format_date($r['attendance_date']) ?></td>
                        <td><?= e($r['schedule_name'] ?: '—') ?></td>
                        <td><?= format_time($r['time_in']) ?></td>
                        <td><?= format_time($r['time_out']) ?></td>
                        <td><?= format_time($r['break_out']) ?> – <?= format_time($r['break_in']) ?></td>
                        <td><span class="badge badge-<?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
                        <td><?= e($r['remarks'] ?: '—') ?></td>
                    </tr><?php endforeach; ?><?php if (!$history): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-3">No attendance history.</td>
                    </tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>