<?php
$organizationName = trim((string) setting('organization_name', 'Universal Organization'));
$organizationLogo = trim((string) setting('organization_logo', ''));
$cardSheets = array_chunk($people, 8);
$totalCards = count($people);

$firstCharacter = static function (string $value): string {
    return function_exists('mb_substr') ? mb_substr($value, 0, 1) : substr($value, 0, 1);
};

$upper = static function (string $value): string {
    return function_exists('mb_strtoupper') ? mb_strtoupper($value) : strtoupper($value);
};

$initials = static function (string $name) use ($firstCharacter, $upper): string {
    $parts = preg_split('/\s+/u', trim($name), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    if (!$parts) {
        return 'ID';
    }

    $letters = $firstCharacter($parts[0]);
    if (count($parts) > 1) {
        $letters .= $firstCharacter($parts[count($parts) - 1]);
    }

    return $upper($letters);
};
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light">
    <title>Bulk QR Cards | <?= e($organizationName) ?></title>
    <style>
        :root {
            --brand: #0f172a;
            --brand-soft: #1e293b;
            --accent: #2563eb;
            --accent-soft: #dbeafe;
            --success: #15803d;
            --surface: #ffffff;
            --canvas: #eef2f7;
            --line: #d8e0ea;
            --muted: #64748b;
            --text: #172033;
        }

        * {
            box-sizing: border-box;
        }

        html {
            background: var(--canvas);
        }

        body {
            margin: 0;
            min-width: 320px;
            color: var(--text);
            background: var(--canvas);
            font-family: "Source Sans Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            text-rendering: optimizeLegibility;
        }

        button,
        a {
            font: inherit;
        }

        .print-toolbar {
            position: sticky;
            top: 0;
            z-index: 20;
            border-bottom: 1px solid #dbe2ea;
            background: rgba(255, 255, 255, .96);
            box-shadow: 0 5px 18px rgba(15, 23, 42, .07);
            backdrop-filter: blur(12px);
        }

        .toolbar-inner {
            width: min(1180px, calc(100% - 32px));
            min-height: 78px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            padding: 13px 0;
        }

        .toolbar-copy {
            min-width: 0;
        }

        .toolbar-eyebrow {
            display: block;
            margin-bottom: 2px;
            color: var(--accent);
            font-size: 12px;
            font-weight: 700;
            letter-spacing: .09em;
            text-transform: uppercase;
        }

        .toolbar-title {
            margin: 0;
            color: var(--brand);
            font-size: clamp(20px, 2.4vw, 28px);
            font-weight: 700;
            line-height: 1.15;
        }

        .toolbar-subtitle {
            margin: 5px 0 0;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.35;
        }

        .toolbar-actions {
            display: flex;
            flex: 0 0 auto;
            align-items: center;
            gap: 10px;
        }

        .btn {
            min-height: 42px;
            padding: 9px 15px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: 1px solid transparent;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            line-height: 1;
            transition: transform .15s ease, box-shadow .15s ease, background .15s ease;
        }

        .btn:hover {
            transform: translateY(-1px);
        }

        .btn-secondary {
            border-color: #cbd5e1;
            color: #334155;
            background: #fff;
        }

        .btn-secondary:hover {
            background: #f8fafc;
        }

        .btn-primary {
            color: #fff;
            background: var(--accent);
            box-shadow: 0 7px 14px rgba(37, 99, 235, .2);
        }

        .btn-primary:hover {
            background: #1d4ed8;
        }

        .btn svg {
            width: 17px;
            height: 17px;
            flex: 0 0 auto;
        }

        .print-note {
            width: min(1180px, calc(100% - 32px));
            margin: 18px auto 0;
            padding: 12px 15px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
            border: 1px solid #bfdbfe;
            border-radius: 10px;
            color: #1e3a8a;
            background: #eff6ff;
            font-size: 13px;
            line-height: 1.45;
        }

        .print-note svg {
            width: 18px;
            height: 18px;
            margin-top: 1px;
            flex: 0 0 auto;
        }

        .preview-area {
            width: 100%;
            padding: 22px 16px 42px;
        }

        .card-sheet {
            width: min(1040px, 100%);
            margin: 0 auto 24px;
            padding: clamp(16px, 3vw, 30px);
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: clamp(16px, 2.4vw, 26px);
            border: 1px solid #dde4ec;
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 14px 34px rgba(15, 23, 42, .08);
        }

        .sheet-label {
            grid-column: 1 / -1;
            margin: -2px 0 -2px;
            color: #94a3b8;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .06em;
            text-transform: uppercase;
        }

        .identity-card {
            position: relative;
            width: 100%;
            aspect-ratio: 85.6 / 54;
            min-width: 0;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid #cbd5e1;
            border-radius: 3.8cqw;
            color: var(--text);
            background:
                radial-gradient(circle at 101% -10%, rgba(37, 99, 235, .12) 0, rgba(37, 99, 235, 0) 34%),
                linear-gradient(135deg, #ffffff 0%, #ffffff 68%, #f8fafc 100%);
            box-shadow: 0 8px 20px rgba(15, 23, 42, .1);
            container-type: inline-size;
            break-inside: avoid;
            page-break-inside: avoid;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .identity-card::before {
            content: "";
            position: absolute;
            inset: 0 auto 0 0;
            width: 2.1cqw;
            background: linear-gradient(180deg, var(--accent), var(--brand));
        }

        .card-inner {
            height: 100%;
            min-height: 0;
            padding: 3.8cqw 4.2cqw 3.1cqw 5.8cqw;
            display: flex;
            flex-direction: column;
        }

        .card-header {
            min-width: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 2.4cqw;
        }

        .brand-lockup {
            min-width: 0;
            display: flex;
            align-items: center;
            gap: 2.5cqw;
        }

        .brand-mark {
            width: 9.2cqw;
            height: 9.2cqw;
            flex: 0 0 auto;
            overflow: hidden;
            display: grid;
            place-items: center;
            border: .6cqw solid #e2e8f0;
            border-radius: 2.2cqw;
            color: #fff;
            background: var(--brand);
            font-size: 3.5cqw;
            font-weight: 800;
            letter-spacing: -.04em;
        }

        .brand-mark img {
            width: 100%;
            height: 100%;
            padding: .7cqw;
            object-fit: contain;
            background: #fff;
        }

        .brand-copy {
            min-width: 0;
        }

        .organization-name {
            max-width: 43cqw;
            overflow: hidden;
            color: var(--brand);
            font-size: 3.35cqw;
            font-weight: 750;
            line-height: 1.05;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .card-type {
            margin-top: .7cqw;
            color: var(--muted);
            font-size: 2.05cqw;
            font-weight: 700;
            letter-spacing: .11em;
            line-height: 1;
            text-transform: uppercase;
        }

        .status-chip {
            flex: 0 0 auto;
            padding: 1.1cqw 1.8cqw;
            display: inline-flex;
            align-items: center;
            gap: 1cqw;
            border: .25cqw solid #bbf7d0;
            border-radius: 999px;
            color: #166534;
            background: #f0fdf4;
            font-size: 2.05cqw;
            font-weight: 700;
            line-height: 1;
            text-transform: uppercase;
        }

        .status-chip::before {
            content: "";
            width: 1.45cqw;
            height: 1.45cqw;
            border-radius: 50%;
            background: #22c55e;
            box-shadow: 0 0 0 .7cqw rgba(34, 197, 94, .13);
        }

        .status-chip.inactive {
            border-color: #fecaca;
            color: #991b1b;
            background: #fef2f2;
        }

        .status-chip.inactive::before {
            background: #ef4444;
            box-shadow: 0 0 0 .7cqw rgba(239, 68, 68, .12);
        }

        .card-content {
            min-height: 0;
            flex: 1 1 auto;
            margin-top: 3cqw;
            display: grid;
            grid-template-columns: 21.5cqw minmax(0, 1fr) 25.5cqw;
            align-items: center;
            gap: 3.1cqw;
        }

        .person-photo,
        .person-placeholder {
            width: 21.5cqw;
            height: 25.8cqw;
            border: .55cqw solid #fff;
            border-radius: 2.8cqw;
            box-shadow: 0 0 0 .35cqw #cbd5e1, 0 2cqw 4cqw rgba(15, 23, 42, .12);
        }

        .person-photo {
            display: block;
            object-fit: cover;
            background: #e2e8f0;
        }

        .person-placeholder {
            display: grid;
            place-items: center;
            color: #334155;
            background: linear-gradient(145deg, #e2e8f0, #f8fafc);
            font-size: 6.2cqw;
            font-weight: 800;
            letter-spacing: -.04em;
        }

        .person-details {
            min-width: 0;
        }

        .person-name {
            max-height: 10.2cqw;
            overflow: hidden;
            display: -webkit-box;
            color: var(--brand);
            font-size: 4.25cqw;
            font-weight: 780;
            letter-spacing: -.025em;
            line-height: 1.06;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
        }

        .person-role {
            margin-top: 1.25cqw;
            overflow: hidden;
            color: var(--accent);
            font-size: 2.65cqw;
            font-weight: 700;
            line-height: 1.2;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .detail-list {
            margin-top: 2.2cqw;
            display: grid;
            gap: 1.05cqw;
        }

        .detail-row {
            min-width: 0;
            display: grid;
            grid-template-columns: 9.5cqw minmax(0, 1fr);
            align-items: baseline;
            gap: 1.2cqw;
        }

        .detail-label {
            color: #94a3b8;
            font-size: 1.85cqw;
            font-weight: 700;
            letter-spacing: .055em;
            line-height: 1.1;
            text-transform: uppercase;
        }

        .detail-value {
            overflow: hidden;
            color: #334155;
            font-size: 2.35cqw;
            font-weight: 650;
            line-height: 1.15;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .qr-panel {
            min-width: 0;
            align-self: center;
            text-align: center;
        }

        .qr-frame {
            width: 25.5cqw;
            height: 25.5cqw;
            padding: 1.35cqw;
            display: grid;
            place-items: center;
            border: .35cqw solid #dbe4ee;
            border-radius: 2.7cqw;
            background: #fff;
            box-shadow: 0 1.2cqw 3.2cqw rgba(15, 23, 42, .08);
        }

        .qr-image {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: contain;
            image-rendering: auto;
        }

        .qr-missing {
            padding: 1.4cqw;
            color: #b91c1c;
            font-size: 2.15cqw;
            font-weight: 700;
            line-height: 1.15;
        }

        .qr-caption {
            margin-top: 1.2cqw;
            color: var(--muted);
            font-size: 1.85cqw;
            font-weight: 700;
            letter-spacing: .055em;
            line-height: 1.15;
            text-transform: uppercase;
        }

        .card-footer {
            min-width: 0;
            margin-top: 2.1cqw;
            padding-top: 1.7cqw;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 2.2cqw;
            border-top: .25cqw solid #e2e8f0;
        }

        .person-id {
            min-width: 0;
            overflow: hidden;
            color: var(--brand);
            font-size: 2.35cqw;
            font-weight: 800;
            letter-spacing: .045em;
            line-height: 1;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .person-id span {
            margin-right: 1.2cqw;
            color: #94a3b8;
            font-size: 1.8cqw;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
        }

        .property-note {
            min-width: 0;
            overflow: hidden;
            color: #94a3b8;
            font-size: 1.65cqw;
            font-weight: 600;
            line-height: 1;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .empty-state {
            width: min(620px, calc(100% - 32px));
            margin: 56px auto;
            padding: 42px 28px;
            border: 1px solid #dbe2ea;
            border-radius: 14px;
            text-align: center;
            background: #fff;
            box-shadow: 0 14px 34px rgba(15, 23, 42, .08);
        }

        .empty-state h2 {
            margin: 0 0 8px;
            color: var(--brand);
            font-size: 24px;
        }

        .empty-state p {
            margin: 0;
            color: var(--muted);
        }

        @media (max-width: 840px) {
            .toolbar-inner {
                min-height: 0;
                align-items: flex-start;
                flex-direction: column;
                gap: 13px;
                padding: 15px 0;
            }

            .toolbar-actions {
                width: 100%;
            }

            .toolbar-actions .btn {
                flex: 1 1 0;
            }

            .card-sheet {
                grid-template-columns: minmax(0, 1fr);
            }
        }

        @media (max-width: 520px) {

            .toolbar-inner,
            .print-note {
                width: min(100% - 24px, 1180px);
            }

            .toolbar-subtitle {
                font-size: 13px;
            }

            .btn {
                min-height: 40px;
                padding: 9px 12px;
            }

            .preview-area {
                padding: 14px 10px 28px;
            }

            .card-sheet {
                margin-bottom: 14px;
                padding: 10px;
                gap: 12px;
                border-radius: 10px;
            }

            .sheet-label {
                padding: 2px 2px 0;
            }
        }

        @media print {
            @page {
                size: A4 portrait;
                margin: 10mm;
            }

            html,
            body {
                width: 210mm;
                min-width: 0;
                margin: 0;
                background: #fff !important;
            }

            .print-toolbar,
            .print-note,
            .sheet-label,
            .empty-state {
                display: none !important;
            }

            .preview-area {
                width: auto;
                margin: 0;
                padding: 0;
            }

            .card-sheet {
                width: 190mm;
                min-height: 0;
                margin: 0;
                padding: 0;
                grid-template-columns: repeat(2, 85.6mm);
                grid-auto-rows: 54mm;
                column-gap: 8.8mm;
                row-gap: 7mm;
                align-content: start;
                border: 0;
                border-radius: 0;
                background: transparent;
                box-shadow: none;
                break-after: page;
                page-break-after: always;
            }

            .card-sheet:last-child {
                break-after: auto;
                page-break-after: auto;
            }

            .identity-card {
                width: 85.6mm;
                height: 54mm;
                border-width: .25mm;
                border-radius: 3.2mm;
                box-shadow: none;
            }
        }
    </style>
</head>

<body>
    <header class="print-toolbar">
        <div class="toolbar-inner">
            <div class="toolbar-copy">
                <span class="toolbar-eyebrow">QR Card Printing</span>
                <h1 class="toolbar-title">Professional Attendance ID Cards</h1>
                <p class="toolbar-subtitle"><?= number_format($totalCards) ?> card<?= $totalCards === 1 ? '' : 's' ?>
                    prepared · standard CR80 identity-card size · up to 8 cards per A4 page</p>
            </div>
            <div class="toolbar-actions">
                <a class="btn btn-secondary" href="<?= url('people') ?>">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor"
                            d="M15.7 5.3a1 1 0 0 1 0 1.4L10.4 12l5.3 5.3a1 1 0 1 1-1.4 1.4l-6-6a1 1 0 0 1 0-1.4l6-6a1 1 0 0 1 1.4 0Z" />
                    </svg>
                    Back to People
                </a>
                <?php if ($totalCards > 0): ?>
                    <button class="btn btn-primary" type="button" onclick="window.print()">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path fill="currentColor"
                                d="M7 3a2 2 0 0 0-2 2v3h2V5h10v3h2V5a2 2 0 0 0-2-2H7Zm10 12H7v6h10v-6Zm-2 4H9v-2h6v2Zm5-10H4a3 3 0 0 0-3 3v5h4v-4h14v4h4v-5a3 3 0 0 0-3-3Zm0 3a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z" />
                        </svg>
                        Print Cards
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <?php if ($totalCards > 0): ?>
        <div class="print-note">
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path fill="currentColor"
                    d="M11 17h2v-6h-2v6Zm1-15a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16ZM11 9h2V7h-2v2Z" />
            </svg>
            <div><strong>Recommended print settings:</strong> A4 portrait, scale 100% or Actual Size, default 10 mm margins,
                and Background graphics enabled. The cards use the standard 85.6 × 54 mm identity-card format.</div>
        </div>

        <main class="preview-area">
            <?php foreach ($cardSheets as $sheetIndex => $sheet): ?>
                <section class="card-sheet" aria-label="QR card sheet <?= $sheetIndex + 1 ?>">
                    <div class="sheet-label">A4 Sheet <?= $sheetIndex + 1 ?> of <?= count($cardSheets) ?></div>

                    <?php foreach ($sheet as $person): ?>
                        <?php
                        $status = (string) ($person['status'] ?? 'Active');
                        $role = trim((string) ($person['position_role'] ?? '')) ?: (string) $person['category_name'];
                        $department = trim((string) ($person['department_name'] ?? '')) ?: 'Not assigned';
                        ?>
                        <article class="identity-card">
                            <div class="card-inner">
                                <div class="card-header">
                                    <div class="brand-lockup">
                                        <div class="brand-mark" aria-hidden="true">
                                            <?php if ($organizationLogo !== ''): ?>
                                                <img src="<?= upload_url($organizationLogo) ?>" alt="">
                                            <?php else: ?>
                                                <?= e($upper($firstCharacter($organizationName))) ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="brand-copy">
                                            <div class="organization-name"><?= e($organizationName) ?></div>
                                            <div class="card-type">Attendance Identity Card</div>
                                        </div>
                                    </div>
                                    <div class="status-chip <?= strcasecmp($status, 'Active') === 0 ? '' : 'inactive' ?>">
                                        <?= e($status) ?></div>
                                </div>

                                <div class="card-content">
                                    <div>
                                        <?php if (!empty($person['photo'])): ?>
                                            <img class="person-photo" src="<?= upload_url($person['photo']) ?>"
                                                alt="Photo of <?= e($person['full_name']) ?>">
                                        <?php else: ?>
                                            <div class="person-placeholder" aria-label="No profile photo">
                                                <?= e($initials((string) $person['full_name'])) ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="person-details">
                                        <div class="person-name"><?= e($person['full_name']) ?></div>
                                        <div class="person-role"><?= e($role) ?></div>
                                        <div class="detail-list">
                                            <div class="detail-row">
                                                <div class="detail-label">Category</div>
                                                <div class="detail-value"><?= e($person['category_name']) ?></div>
                                            </div>
                                            <div class="detail-row">
                                                <div class="detail-label">Group</div>
                                                <div class="detail-value"><?= e($department) ?></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="qr-panel">
                                        <div class="qr-frame">
                                            <?php if (!empty($person['qr_image'])): ?>
                                                <img class="qr-image" src="<?= upload_url($person['qr_image']) ?>"
                                                    alt="Attendance QR code for <?= e($person['full_name']) ?>">
                                            <?php else: ?>
                                                <div class="qr-missing">QR code unavailable</div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qr-caption">Scan for attendance</div>
                                    </div>
                                </div>

                                <div class="card-footer">
                                    <div class="person-id"><span>Person ID</span><?= e($person['person_id']) ?></div>
                                    <div class="property-note">Property of <?= e($organizationName) ?></div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </section>
            <?php endforeach; ?>
        </main>
    <?php else: ?>
        <div class="empty-state">
            <h2>No QR cards available</h2>
            <p>No matching people were found. Return to People Management and select active people with generated QR codes.
            </p>
        </div>
    <?php endif; ?>
</body>

</html>