<div class="row">
    <div class="col-lg-3 col-6">
        <div class="info-box"><span class="info-box-icon bg-info"><i class="fas fa-list"></i></span>
            <div class="info-box-content"><span class="info-box-text">Records</span><span
                    class="info-box-number"><?= $summary['total'] ?></span></div>
        </div>
    </div>
    <div class="col-lg-2 col-6">
        <div class="info-box"><span class="info-box-icon bg-success"><i class="fas fa-check"></i></span>
            <div class="info-box-content"><span class="info-box-text">Present</span><span
                    class="info-box-number"><?= $summary['present'] ?></span></div>
        </div>
    </div>
    <div class="col-lg-2 col-6">
        <div class="info-box"><span class="info-box-icon bg-warning"><i class="fas fa-clock"></i></span>
            <div class="info-box-content"><span class="info-box-text">Late</span><span
                    class="info-box-number"><?= $summary['late'] ?></span></div>
        </div>
    </div>
    <div class="col-lg-2 col-6">
        <div class="info-box"><span class="info-box-icon bg-danger"><i class="fas fa-times"></i></span>
            <div class="info-box-content"><span class="info-box-text">Absent</span><span
                    class="info-box-number"><?= $summary['absent'] ?></span></div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="info-box"><span class="info-box-icon bg-primary"><i class="fas fa-plane"></i></span>
            <div class="info-box-content"><span class="info-box-text">On Leave</span><span
                    class="info-box-number"><?= $summary['leave'] ?></span></div>
        </div>
    </div>
</div>
<div class="card filter-card">
    <div class="card-header">
        <h3 class="card-title">Report Filters</h3>
    </div>
    <div class="card-body">
        <form method="get" id="reportForm"><input type="hidden" name="route" value="reports">
            <div class="form-row">
                <div class="form-group col-lg-2"><label>Report Type</label><select class="form-control" name="type">
                        <option value="daily" <?= $filters['type'] === 'daily' ? 'selected' : '' ?>>Daily</option>
                        <option value="weekly" <?= $filters['type'] === 'weekly' ? 'selected' : '' ?>>Weekly</option>
                        <option value="monthly" <?= $filters['type'] === 'monthly' ? 'selected' : '' ?>>Monthly</option>
                        <option value="yearly" <?= $filters['type'] === 'yearly' ? 'selected' : '' ?>>Yearly</option>
                        <option value="individual" <?= $filters['type'] === 'individual' ? 'selected' : '' ?>>Individual
                        </option>
                        <option value="department" <?= $filters['type'] === 'department' ? 'selected' : '' ?>>Department
                        </option>
                        <option value="category" <?= $filters['type'] === 'category' ? 'selected' : '' ?>>Category</option>
                        <option value="late" <?= $filters['type'] === 'late' ? 'selected' : '' ?>>Late Report</option>
                        <option value="absent" <?= $filters['type'] === 'absent' ? 'selected' : '' ?>>Absent Report</option>
                    </select></div>
                <div class="form-group col-lg-2"><label>From</label><input type="date" class="form-control" name="from"
                        value="<?= e($filters['from']) ?>"></div>
                <div class="form-group col-lg-2"><label>To</label><input type="date" class="form-control" name="to"
                        value="<?= e($filters['to']) ?>"></div>
                <div class="form-group col-lg-3"><label>Person</label><select class="form-control" name="person_id">
                        <option value="">All people</option><?php foreach ($people as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= $filters['person'] === $p['id'] ? 'selected' : '' ?>>
                                <?= e($p['person_id'] . ' — ' . $p['full_name']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-3"><label>Status</label><select class="form-control" name="status">
                        <option value="">All statuses</option>
                        <?php foreach (['Present', 'Late', 'Absent', 'On Leave', 'Holiday', 'Half-Day'] as $s): ?>
                            <option <?= $filters['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
                    </select></div>
            </div>
            <div class="form-row">
                <div class="form-group col-lg-3"><label>Category</label><select class="form-control" name="category_id">
                        <option value="">All categories</option><?php foreach ($categories as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= $filters['category'] === $c['id'] ? 'selected' : '' ?>>
                                <?= e($c['name']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-3"><label>Department / Group</label><select class="form-control"
                        name="department_id">
                        <option value="">All departments</option><?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>" <?= $filters['department'] === $d['id'] ? 'selected' : '' ?>>
                                <?= e($d['name']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="form-group col-lg-3"><label>Search</label><input class="form-control" name="q"
                        value="<?= e($filters['q']) ?>" placeholder="Name or Person ID"></div>
                <div class="form-group col-lg-3 d-flex align-items-end"><button class="btn btn-primary mr-2"><i
                            class="fas fa-chart-bar mr-1"></i> Generate</button><a href="<?= url('reports') ?>"
                        class="btn btn-light">Reset</a></div>
            </div>
        </form>
    </div>
    <div class="card-footer">
        <div class="btn-group"><a href="#" data-format="pdf" class="btn btn-danger export-link"><i
                    class="fas fa-file-pdf mr-1"></i> PDF</a><a href="#" data-format="xlsx"
                class="btn btn-success export-link"><i class="fas fa-file-excel mr-1"></i> Excel</a><a href="#"
                data-format="csv" class="btn btn-info export-link"><i class="fas fa-file-csv mr-1"></i> CSV</a><a
                href="#" data-format="print" target="_blank" class="btn btn-secondary export-link"><i
                    class="fas fa-print mr-1"></i> Print</a></div>
    </div>
</div>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Report Results</h3>
        <div class="card-tools"><span class="text-muted small"><?= format_date($filters['from']) ?> –
                <?= format_date($filters['to']) ?></span></div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-bordered table-hover mb-0">
            <thead>
                <tr>
                    <th>Person ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Department</th>
                    <th>Date</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Status</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody><?php foreach ($rows as $r): ?>
                    <tr>
                        <td><code><?= e($r['person_code']) ?></code></td>
                        <td><?= e($r['full_name']) ?></td>
                        <td><?= e($r['category_name']) ?></td>
                        <td><?= e($r['department_name'] ?: '—') ?></td>
                        <td><?= format_date($r['attendance_date']) ?></td>
                        <td><?= format_time($r['time_in']) ?></td>
                        <td><?= format_time($r['time_out']) ?></td>
                        <td><span class="badge badge-<?= badge_class($r['status']) ?>"><?= e($r['status']) ?></span></td>
                        <td><?= e($r['remarks'] ?: '—') ?></td>
                    </tr><?php endforeach; ?><?php if (!$rows): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">No records matched the report filters.</td>
                    </tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer"><small class="text-muted">Showing <?= $summary['total'] ?> report record(s). For very large
            datasets, narrow the date range before exporting.</small></div>
</div>
<?php $exportBase = url('reports/export');
$pageScript = <<<HTML
<script>document.querySelectorAll('.export-link').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const form=document.getElementById('reportForm'),params=new URLSearchParams(new FormData(form));params.delete('route');params.set('format',a.dataset.format);const target='{$exportBase}&'+params.toString();if(a.dataset.format==='print')window.open(target,'_blank');else window.location.href=target;}));</script>
HTML; ?>