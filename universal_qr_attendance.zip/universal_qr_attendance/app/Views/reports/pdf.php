<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <style>
        @page {
            margin: 20px
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 9px;
            color: #222
        }

        h1 {
            font-size: 18px;
            margin: 0
        }

        h2 {
            font-size: 13px;
            margin: 3px 0 10px
        }

        .meta {
            margin-bottom: 10px;
            color: #555
        }

        table {
            width: 100%;
            border-collapse: collapse
        }

        th,
        td {
            border: 1px solid #888;
            padding: 4px;
            vertical-align: top
        }

        th {
            background: #e9ecef
        }
    </style>
</head>

<body>
    <h1><?= e(setting('organization_name', 'Universal Organization')) ?></h1>
    <h2>Attendance Report</h2>
    <div class="meta"><?= format_date($filters['from']) ?> to <?= format_date($filters['to']) ?> · Generated
        <?= date('d M Y h:i A') ?></div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Department</th>
                <th>Schedule</th>
                <th>Date</th>
                <th>In</th>
                <th>Out</th>
                <th>Status</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody><?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= e($r['person_code']) ?></td>
                    <td><?= e($r['full_name']) ?></td>
                    <td><?= e($r['category_name']) ?></td>
                    <td><?= e($r['department_name'] ?: '—') ?></td>
                    <td><?= e($r['schedule_name'] ?: '—') ?></td>
                    <td><?= e($r['attendance_date']) ?></td>
                    <td><?= e($r['time_in'] ?: '—') ?></td>
                    <td><?= e($r['time_out'] ?: '—') ?></td>
                    <td><?= e($r['status']) ?></td>
                    <td><?= e($r['remarks'] ?: '—') ?></td>
                </tr><?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>