<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Attendance Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #222;
            margin: 20px
        }

        h1 {
            margin-bottom: 4px
        }

        .meta {
            color: #666;
            margin-bottom: 18px
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px
        }

        th,
        td {
            border: 1px solid #aaa;
            padding: 6px;
            text-align: left
        }

        th {
            background: #eee
        }

        .toolbar {
            text-align: right;
            margin-bottom: 10px
        }

        @media print {
            .toolbar {
                display: none
            }
        }
    </style>
</head>

<body>
    <div class="toolbar"><button onclick="window.print()">Print Report</button></div>
    <h1><?= e(setting('organization_name', 'Universal Organization')) ?></h1>
    <h2>Attendance Report</h2>
    <div class="meta"><?= format_date($filters['from']) ?> to <?= format_date($filters['to']) ?> · Generated
        <?= date('d M Y h:i A') ?></div>
    <table>
        <thead>
            <tr>
                <th>Person ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Department</th>
                <th>Schedule</th>
                <th>Date</th>
                <th>In</th>
                <th>Out</th>
                <th>Status</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody><?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= e($r['person_code']) ?></td>
                    <td><?= e($r['full_name']) ?></td>
                    <td><?= e($r['category_name']) ?></td>
                    <td><?= e($r['department_name'] ?: '—') ?></td>
                    <td><?= e($r['schedule_name'] ?: '—') ?></td>
                    <td><?= e($r['attendance_date']) ?></td>
                    <td><?= e($r['time_in'] ?: '—') ?></td>
                    <td><?= e($r['time_out'] ?: '—') ?></td>
                    <td><?= e($r['status']) ?></td>
                    <td><?= e($r['remarks'] ?: '—') ?></td>
                </tr><?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>