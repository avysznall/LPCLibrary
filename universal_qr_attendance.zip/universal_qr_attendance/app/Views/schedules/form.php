<?php $v = fn($key, $default = '') => e(old($key, $schedule[$key] ?? $default));
$selectedDays = json_decode($schedule['days_available'] ?? '[]', true) ?: []; ?>
<form method="post" action="<?= url($schedule ? 'schedules/update' : 'schedules/store') ?>">
    <?= csrf_field() ?><?php if ($schedule): ?><input type="hidden" name="id" value="<?= $schedule['id'] ?>"><?php endif; ?>
    <div class="row">
        <div class="col-lg-7">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">Schedule Rules</h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-8"><label class="required">Schedule Name</label><input
                                class="form-control" name="name" value="<?= $v('name') ?>"
                                placeholder="e.g., Office Hours or Morning Class" required></div>
                        <div class="form-group col-md-4"><label>Status</label><select class="form-control"
                                name="status">
                                <option <?= old('status', $schedule['status'] ?? 'Active') === 'Active' ? 'selected' : '' ?>>Active
                                </option>
                                <option <?= old('status', $schedule['status'] ?? '') === 'Inactive' ? 'selected' : '' ?>>Inactive
                                </option>
                            </select></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6"><label class="required">Start Time</label><input type="time"
                                class="form-control" name="start_time" value="<?= $v('start_time', '09:00') ?>" required>
                        </div>
                        <div class="form-group col-md-6"><label class="required">End Time</label><input type="time"
                                class="form-control" name="end_time" value="<?= $v('end_time', '17:00') ?>" required></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4"><label>Late Threshold</label>
                            <div class="input-group"><input type="number" min="0" max="240" class="form-control"
                                    name="late_threshold_minutes" value="<?= $v('late_threshold_minutes', 10) ?>">
                                <div class="input-group-append"><span class="input-group-text">minutes</span></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4"><label>Scan Before Start</label>
                            <div class="input-group"><input type="number" min="0" max="720" class="form-control"
                                    name="scan_before_minutes" value="<?= $v('scan_before_minutes', 60) ?>">
                                <div class="input-group-append"><span class="input-group-text">minutes</span></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4"><label>Scan After End</label>
                            <div class="input-group"><input type="number" min="0" max="720" class="form-control"
                                    name="scan_after_minutes" value="<?= $v('scan_after_minutes', 120) ?>">
                                <div class="input-group-append"><span class="input-group-text">minutes</span></div>
                            </div>
                        </div>
                    </div><label class="required d-block">Days Available</label>
                    <div class="d-flex flex-wrap">
                        <?php foreach (['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as $d): ?>
                            <div class="custom-control custom-checkbox mr-4 mb-2"><input type="checkbox"
                                    class="custom-control-input" id="day_<?= $d ?>" name="days_available[]" value="<?= $d ?>"
                                    <?= in_array($d, old('days_available', $selectedDays), true) ? 'checked' : '' ?>><label
                                    class="custom-control-label" for="day_<?= $d ?>"><?= ucfirst($d) ?></label></div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Assign Schedule</h3>
                </div>
                <div class="card-body">
                    <div class="form-group"><label>Categories</label><select multiple size="6" class="form-control"
                            name="category_ids[]"><?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= in_array($c['id'], $assigned['categories']) ? 'selected' : '' ?>>
                                    <?= e($c['name']) ?></option><?php endforeach; ?>
                        </select><small class="text-muted">Use Ctrl/Cmd to choose multiple.</small></div>
                    <div class="form-group"><label>Departments / Groups</label><select multiple size="6"
                            class="form-control" name="department_ids[]"><?php foreach ($departments as $d): ?>
                                <option value="<?= $d['id'] ?>"
                                    <?= in_array($d['id'], $assigned['departments']) ? 'selected' : '' ?>><?= e($d['name']) ?>
                                </option><?php endforeach; ?>
                        </select></div>
                    <div class="form-group"><label>Specific People</label><select multiple size="7" class="form-control"
                            name="person_ids[]"><?php foreach ($people as $p): ?>
                                <option value="<?= $p['id'] ?>" <?= in_array($p['id'], $assigned['people']) ? 'selected' : '' ?>>
                                    <?= e($p['person_id'] . ' — ' . $p['full_name']) ?></option><?php endforeach; ?>
                        </select></div>
                </div>
            </div><button class="btn btn-primary btn-block"><i class="fas fa-save mr-1"></i> Save Schedule</button><a
                href="<?= url('schedules') ?>" class="btn btn-light btn-block">Cancel</a>
        </div>
    </div>
</form><?php clear_old(); ?>