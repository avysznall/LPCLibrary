<div class="card">
    <div class="card-header">
        <h3 class="card-title">Attendance Schedules</h3>
        <div class="card-tools"><?php if (\App\Core\Auth::isAdmin()): ?><a href="<?= url('schedules/create') ?>"
                    class="btn btn-sm btn-primary"><i class="fas fa-plus mr-1"></i> Create Schedule</a><?php endif; ?></div>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Hours</th>
                    <th>Late After</th>
                    <th>Allowed Scan Window</th>
                    <th>Available Days</th>
                    <th>Assignments</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody><?php foreach ($schedules as $s):
                $days = json_decode($s['days_available'], true) ?: []; ?>
                    <tr>
                        <td><strong><?= e($s['name']) ?></strong></td>
                        <td><?= format_time($s['start_time']) ?> – <?= format_time($s['end_time']) ?></td>
                        <td><?= $s['late_threshold_minutes'] ?> min</td>
                        <td><?= $s['scan_before_minutes'] ?> min before<br><?= $s['scan_after_minutes'] ?> min after</td>
                        <td><?php foreach ($days as $d): ?><span
                                    class="badge badge-light border mr-1"><?= e(ucfirst(substr($d, 0, 3))) ?></span><?php endforeach; ?>
                        </td>
                        <td><small><?= $s['category_count'] ?> categories<br><?= $s['department_count'] ?> groups ·
                                <?= $s['people_count'] ?> people</small></td>
                        <td><span class="badge badge-<?= badge_class($s['status']) ?>"><?= e($s['status']) ?></span></td>
                        <td class="text-right text-nowrap"><?php if (\App\Core\Auth::isAdmin()): ?><a
                                    href="<?= url('schedules/edit', ['id' => $s['id']]) ?>" class="btn btn-xs btn-warning"><i
                                        class="fas fa-edit"></i></a>
                                <form method="post" action="<?= url('schedules/delete') ?>" class="d-inline"
                                    data-confirm="Delete or deactivate this schedule?"><?= csrf_field() ?><input type="hidden"
                                        name="id" value="<?= $s['id'] ?>"><button class="btn btn-xs btn-danger"><i
                                            class="fas fa-trash"></i></button></form><?php endif; ?>
                        </td>
                    </tr><?php endforeach; ?><?php if (!$schedules): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">No attendance schedules created.</td>
                    </tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="alert alert-info"><i class="fas fa-layer-group mr-2"></i>Schedule priority is: individual assignment, direct
    schedule on the person, department/group assignment, then category assignment.</div>