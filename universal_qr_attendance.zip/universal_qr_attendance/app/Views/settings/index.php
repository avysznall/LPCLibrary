<?php
$kioskUrl = rtrim(config('url'), '/') . '/kiosk.php';
$kioskKey = trim((string) ($settings['kiosk_access_key'] ?? ''));
if ($kioskKey !== '') {
    $kioskUrl .= '?' . http_build_query(['key' => $kioskKey]);
}
?>
<div class="row">
    <div class="col-lg-8">
        <form method="post" action="<?= url('settings') ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">Organization & Attendance Rules</h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label>Organization Name</label>
                            <input class="form-control" name="organization_name"
                                value="<?= e($settings['organization_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Time Zone</label>
                            <input class="form-control" name="timezone"
                                value="<?= e($settings['timezone'] ?? 'Australia/Sydney') ?>" list="timezones" required>
                            <datalist id="timezones">
                                <option>Australia/Sydney</option>
                                <option>UTC</option>
                                <option>America/New_York</option>
                                <option>Europe/London</option>
                                <option>Asia/Kathmandu</option>
                                <option>Asia/Manila</option>
                            </datalist>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Organization Logo</label>
                        <input type="file" class="form-control-file" name="organization_logo"
                            accept="image/png,image/jpeg,image/webp">
                        <?php if (!empty($settings['organization_logo'])): ?><img
                                src="<?= upload_url($settings['organization_logo']) ?>" class="mt-2" style="max-height:70px"
                                alt="Organization logo"><?php endif; ?>
                    </div>

                    <hr>
                    <h5>Person ID Rules</h5>
                    <div class="form-row">
                        <div class="form-group col-md-6"><label>Person ID Prefix</label><input class="form-control"
                                name="person_id_prefix" value="<?= e($settings['person_id_prefix'] ?? 'PER') ?>"></div>
                        <div class="form-group col-md-6"><label>Number of Digits</label><input type="number" min="3"
                                max="10" class="form-control" name="person_id_digits"
                                value="<?= e($settings['person_id_digits'] ?? '6') ?>"></div>
                    </div>

                    <hr>
                    <h5>Attendance & Alert Rules</h5>
                    <div class="form-row">
                        <div class="form-group col-md-4"><label>Default Late Threshold</label>
                            <div class="input-group"><input type="number" min="0" class="form-control"
                                    name="late_default_minutes"
                                    value="<?= e($settings['late_default_minutes'] ?? '10') ?>">
                                <div class="input-group-append"><span class="input-group-text">min</span></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4"><label>Low Attendance Alert</label>
                            <div class="input-group"><input type="number" min="1" max="100" class="form-control"
                                    name="low_attendance_threshold"
                                    value="<?= e($settings['low_attendance_threshold'] ?? '75') ?>">
                                <div class="input-group-append"><span class="input-group-text">%</span></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4"><label>Allow Holiday Scans</label><select class="form-control"
                                name="allow_holiday_scan">
                                <option value="0" <?= ($settings['allow_holiday_scan'] ?? '0') === '0' ? 'selected' : '' ?>>No</option>
                                <option value="1" <?= ($settings['allow_holiday_scan'] ?? '0') === '1' ? 'selected' : '' ?>>Yes</option>
                            </select></div>
                    </div>

                    <hr>
                    <h5>QR Settings</h5>
                    <div class="form-row">
                        <div class="form-group col-md-4"><label>QR Image Size</label>
                            <div class="input-group"><input type="number" min="180" max="800" class="form-control"
                                    name="qr_size" value="<?= e($settings['qr_size'] ?? '300') ?>">
                                <div class="input-group-append"><span class="input-group-text">px</span></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4"><label>QR Payload Prefix</label><input class="form-control"
                                name="qr_prefix" value="<?= e($settings['qr_prefix'] ?? 'UQAMS:') ?>"></div>
                        <div class="form-group col-md-4"><label>Success Sound</label><select class="form-control"
                                name="scanner_success_sound">
                                <option value="1" <?= ($settings['scanner_success_sound'] ?? '1') === '1' ? 'selected' : '' ?>>Enabled</option>
                                <option value="0" <?= ($settings['scanner_success_sound'] ?? '1') === '0' ? 'selected' : '' ?>>Disabled</option>
                            </select></div>
                    </div>

                    <hr>
                    <div class="d-flex align-items-center justify-content-between">
                        <h5 class="mb-0">Public Attendance Kiosk</h5><span class="badge badge-info">Self-service
                            scanner</span>
                    </div>
                    <p class="text-muted small mt-2">This separate page allows people to scan their own QR cards without
                        signing into the administration panel.</p>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Kiosk Status</label>
                            <select class="form-control" name="public_kiosk_enabled">
                                <option value="1" <?= ($settings['public_kiosk_enabled'] ?? '1') === '1' ? 'selected' : '' ?>>Enabled</option>
                                <option value="0" <?= ($settings['public_kiosk_enabled'] ?? '1') === '0' ? 'selected' : '' ?>>Disabled</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Automatic Camera Start</label>
                            <select class="form-control" name="kiosk_auto_start">
                                <option value="1" <?= ($settings['kiosk_auto_start'] ?? '1') === '1' ? 'selected' : '' ?>>
                                    Enabled</option>
                                <option value="0" <?= ($settings['kiosk_auto_start'] ?? '1') === '0' ? 'selected' : '' ?>>
                                    Disabled</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Confirmation Duration</label>
                            <div class="input-group"><input type="number" min="3" max="20" class="form-control"
                                    name="kiosk_confirmation_seconds"
                                    value="<?= e($settings['kiosk_confirmation_seconds'] ?? '5') ?>">
                                <div class="input-group-append"><span class="input-group-text">sec</span></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6"><label>Kiosk Page Title</label><input class="form-control"
                                name="kiosk_title" value="<?= e($settings['kiosk_title'] ?? 'Attendance Kiosk') ?>"
                                placeholder="Attendance Kiosk"></div>
                        <div class="form-group col-md-6"><label>Scanner Location</label><input class="form-control"
                                name="kiosk_location" value="<?= e($settings['kiosk_location'] ?? 'Main Entrance') ?>"
                                placeholder="Main Entrance"></div>
                    </div>
                    <div class="form-group">
                        <label>Optional Kiosk Access Key</label>
                        <div class="input-group">
                            <input id="kioskAccessKey" class="form-control" name="kiosk_access_key"
                                value="<?= e($kioskKey) ?>" maxlength="120" autocomplete="off"
                                placeholder="Leave blank for a fully public kiosk URL">
                            <div class="input-group-append"><button id="generateKioskKey" type="button"
                                    class="btn btn-outline-secondary"><i class="fas fa-random mr-1"></i>
                                    Generate</button></div>
                        </div>
                        <small class="text-muted">When set, only the complete URL containing this key can activate the
                            kiosk. This is recommended for a dedicated entrance device.</small>
                    </div>
                </div>
                <div class="card-footer"><button class="btn btn-primary"><i class="fas fa-save mr-1"></i> Save
                        Settings</button></div>
            </div>
        </form>
    </div>

    <div class="col-lg-4">
        <div class="card card-success card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-desktop mr-2"></i>Attendance Kiosk URL</h3>
            </div>
            <div class="card-body">
                <p class="small text-muted">Open this URL on the shared phone, tablet, or computer used for
                    self-attendance.</p>
                <div class="input-group input-group-sm mb-3">
                    <input id="kioskUrl" class="form-control" value="<?= e($kioskUrl) ?>" readonly>
                    <div class="input-group-append"><button id="copyKioskUrl" type="button"
                            class="btn btn-outline-secondary" title="Copy URL"><i class="fas fa-copy"></i></button>
                    </div>
                </div>
                <a class="btn btn-success btn-block" href="<?= e($kioskUrl) ?>" target="_blank" rel="noopener"><i
                        class="fas fa-external-link-alt mr-1"></i> Open Public Kiosk</a>
                <hr>
                <ul class="small text-muted pl-3 mb-0">
                    <li>No administrator login is required.</li>
                    <li>First accepted scan records Time In.</li>
                    <li>Second accepted scan records Time Out.</li>
                    <li>No admin navigation or manual controls are shown.</li>
                </ul>
            </div>
        </div>

        <div class="card card-warning card-outline">
            <div class="card-header">
                <h3 class="card-title">Database Backup</h3>
            </div>
            <div class="card-body">
                <form method="post" action="<?= url('settings/backup') ?>"><?= csrf_field() ?><button
                        class="btn btn-warning btn-block"><i class="fas fa-database mr-1"></i> Create SQL
                        Backup</button></form>
                <hr>
                <h6>Available Backups</h6>
                <div class="list-group" style="max-height:220px;overflow:auto">
                    <?php foreach ($backups as $b): ?><a class="list-group-item list-group-item-action py-2"
                            href="<?= url('settings/backup/download', ['file' => $b]) ?>"><i
                                class="fas fa-download mr-2"></i><?= e($b) ?></a><?php endforeach; ?>
                    <?php if (!$backups): ?>
                        <div class="text-muted small">No backups created yet.</div><?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card card-danger card-outline">
            <div class="card-header">
                <h3 class="card-title">Restore Database</h3>
            </div>
            <form method="post" action="<?= url('settings/restore') ?>" enctype="multipart/form-data"
                data-confirm="Restoring will replace current database contents with the uploaded SQL backup. Continue?">
                <?= csrf_field() ?>
                <div class="card-body"><input type="file" class="form-control-file" name="backup" accept=".sql"
                        required><small class="text-muted">Use only backups created by this system and from a compatible
                        schema version.</small></div>
                <div class="card-footer"><button class="btn btn-danger btn-block"><i class="fas fa-undo mr-1"></i>
                        Restore SQL Backup</button></div>
            </form>
        </div>
    </div>
</div>
<?php
$pageScript = <<<'HTML'
<script>
document.getElementById('generateKioskKey')?.addEventListener('click', () => {
    const bytes = new Uint8Array(24);
    crypto.getRandomValues(bytes);
    document.getElementById('kioskAccessKey').value = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
});
document.getElementById('copyKioskUrl')?.addEventListener('click', async () => {
    const input = document.getElementById('kioskUrl');
    try { await navigator.clipboard.writeText(input.value); } catch (error) { input.select(); document.execCommand('copy'); }
    const button = document.getElementById('copyKioskUrl');
    button.innerHTML = '<i class="fas fa-check"></i>';
    setTimeout(() => button.innerHTML = '<i class="fas fa-copy"></i>', 1400);
});
</script>
HTML;
?>