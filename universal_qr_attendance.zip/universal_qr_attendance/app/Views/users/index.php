<div class="row">
    <div class="col-lg-4">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title" id="formTitle">Add System User</h3>
            </div>
            <form method="post" action="<?= url('users/save') ?>" enctype="multipart/form-data"><?= csrf_field() ?><input
                    type="hidden" name="id" id="userId">
                <div class="card-body">
                    <div class="form-group"><label class="required">Full Name</label><input class="form-control"
                            name="full_name" id="userName" required></div>
                    <div class="form-row">
                        <div class="form-group col-md-6"><label class="required">Username</label><input
                                class="form-control" name="username" id="userUsername" required></div>
                        <div class="form-group col-md-6"><label>Phone</label><input class="form-control" name="phone"
                                id="userPhone"></div>
                    </div>
                    <div class="form-group"><label class="required">Email</label><input type="email"
                            class="form-control" name="email" id="userEmail" required></div>
                    <div class="form-row">
                        <div class="form-group col-md-7"><label class="required">Role</label><select
                                class="form-control" name="role_id" id="userRole"
                                required><?php foreach ($roles as $r): ?><?php if (\App\Core\Auth::role() === 'super-administrator' || $r['slug'] !== 'super-administrator'): ?>
                                        <option value="<?= $r['id'] ?>"><?= e($r['name']) ?></option>
                                    <?php endif; ?><?php endforeach; ?>
                            </select></div>
                        <div class="form-group col-md-5"><label>Status</label><select class="form-control" name="status"
                                id="userStatus">
                                <option>Active</option>
                                <option>Inactive</option>
                            </select></div>
                    </div>
                    <div class="form-group"><label>Password <small class="text-muted" id="passwordHint">required for new
                                users</small></label><input type="password" minlength="8" class="form-control"
                            name="password"></div>
                    <div class="form-group"><label>Photo</label><input type="file" class="form-control-file"
                            name="photo" accept="image/png,image/jpeg,image/webp"></div>
                </div>
                <div class="card-footer"><button class="btn btn-primary">Save User</button><button type="button"
                        class="btn btn-light" onclick="resetUser()">Clear</button></div>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Authorized Users</h3>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody><?php foreach ($users as $u): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center"><?php if ($u['photo']): ?><img class="avatar mr-2"
                                                src="<?= upload_url($u['photo']) ?>"><?php else: ?><span
                                                class="avatar mr-2 d-flex align-items-center justify-content-center"><i
                                                    class="fas fa-user text-muted"></i></span><?php endif; ?>
                                        <div><strong><?= e($u['full_name']) ?></strong><br><small><?= e($u['email']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= e($u['username']) ?></td>
                                <td><?= e($u['role_name']) ?></td>
                                <td><span class="badge badge-<?= badge_class($u['status']) ?>"><?= e($u['status']) ?></span>
                                </td>
                                <td><?= e($u['last_login'] ? date('d M Y h:i A', strtotime($u['last_login'])) : 'Never') ?></td>
                                <td class="text-right"><button class="btn btn-xs btn-warning"
                                        onclick='editUser(<?= json_encode($u, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i
                                            class="fas fa-edit"></i></button><?php if (\App\Core\Auth::role() === 'super-administrator' && $u['id'] !== \App\Core\Auth::id()): ?>
                                        <form method="post" action="<?= url('users/delete') ?>" class="d-inline"
                                            data-confirm="Delete this system user?"><?= csrf_field() ?><input type="hidden"
                                                name="id" value="<?= $u['id'] ?>"><button class="btn btn-xs btn-danger"><i
                                                    class="fas fa-trash"></i></button></form><?php endif; ?>
                                </td>
                            </tr><?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $pageScript = '<script>function editUser(u){userId.value=u.id;userName.value=u.full_name;userUsername.value=u.username;userPhone.value=u.phone||"";userEmail.value=u.email;userRole.value=u.role_id;userStatus.value=u.status;formTitle.textContent="Edit System User";passwordHint.textContent="leave blank to keep current password";window.scrollTo({top:0,behavior:"smooth"})}function resetUser(){userId.value="";userName.value="";userUsername.value="";userPhone.value="";userEmail.value="";userStatus.value="Active";formTitle.textContent="Add System User";passwordHint.textContent="required for new users"}</script>'; ?>