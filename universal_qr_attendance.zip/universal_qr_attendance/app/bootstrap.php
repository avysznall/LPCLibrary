<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Database;

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('uqams_session');
    session_start();
}

define('BASE_PATH', dirname(__DIR__));
define('PUBLIC_PATH', BASE_PATH . '/public');

function loadEnv(string $path): void
{
    if (!is_file($path)) {
        return;
    }
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$name, $value] = array_map('trim', explode('=', $line, 2));
        if (strlen($value) >= 2 && $value[0] === '"' && $value[strlen($value)-1] === '"') {
            $decoded = json_decode($value, true);
            $value = is_string($decoded) ? $decoded : trim($value, '"');
        } elseif (strlen($value) >= 2 && $value[0] === "'" && $value[strlen($value)-1] === "'") {
            $value = substr($value, 1, -1);
        }
        if (getenv($name) === false) {
            putenv("{$name}={$value}");
            $_ENV[$name] = $value;
        }
    }
}

function env(string $key, mixed $default = null): mixed
{
    $value = $_ENV[$key] ?? getenv($key);
    if ($value === false || $value === null) {
        return $default;
    }
    return match (strtolower((string)$value)) {
        'true', '(true)' => true,
        'false', '(false)' => false,
        'null', '(null)' => null,
        default => $value,
    };
}

loadEnv(BASE_PATH . '/.env');
$GLOBALS['config'] = require BASE_PATH . '/config/app.php';

$vendor = BASE_PATH . '/vendor/autoload.php';
if (is_file($vendor)) {
    require $vendor;
} else {
    spl_autoload_register(function (string $class): void {
        $prefix = 'App\\';
        if (!str_starts_with($class, $prefix)) {
            return;
        }
        $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
        $file = BASE_PATH . '/app/' . $relative . '.php';
        if (is_file($file)) {
            require $file;
        }
    });
}

require BASE_PATH . '/app/helpers.php';

if (is_file(BASE_PATH . '/.env')) {
    try {
        $timezone = setting('timezone', 'Australia/Sydney');
        date_default_timezone_set($timezone ?: 'Australia/Sydney');
        Auth::boot();
    } catch (Throwable $e) {
        if (($GLOBALS['config']['debug'] ?? false) === true) {
            throw $e;
        }
    }
}
