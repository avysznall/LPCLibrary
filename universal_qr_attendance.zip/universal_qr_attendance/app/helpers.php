<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\View;

function config(string $key, mixed $default = null): mixed
{
    $value = $GLOBALS['config'] ?? [];
    foreach (explode('.', $key) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) return $default;
        $value = $value[$segment];
    }
    return $value;
}

function url(string $route = '', array $params = []): string
{
    $base = config('url');
    $query = $route !== '' ? ['route' => $route] : [];
    $query = array_merge($query, $params);
    return $base . '/index.php' . ($query ? '?' . http_build_query($query) : '');
}

function upload_url(?string $path, string $fallback = ''): string
{
    if (!$path) return $fallback;
    return config('url') . '/' . ltrim($path, '/');
}

function e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function csrf_field(): string { return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">'; }
function redirect(string $route, array $params = []): never { header('Location: ' . url($route, $params)); exit; }
function back(): never { header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? url('dashboard'))); exit; }
function view(string $template, array $data = [], bool $layout = true): void { View::render($template, $data, $layout); }
function flash(string $key, ?string $message = null): mixed
{
    if ($message !== null) { $_SESSION['_flash'][$key] = $message; return null; }
    $value = $_SESSION['_flash'][$key] ?? null; unset($_SESSION['_flash'][$key]); return $value;
}
function old(string $key, mixed $default = ''): mixed { return $_SESSION['_old'][$key] ?? $default; }
function set_old(array $data): void { $_SESSION['_old'] = $data; }
function clear_old(): void { unset($_SESSION['_old']); }

function setting(string $key, mixed $default = null): mixed
{
    static $cache = [];
    if (array_key_exists($key, $cache)) return $cache[$key];
    try {
        $row = Database::fetch('SELECT value FROM settings WHERE `key`=? LIMIT 1', [$key]);
        return $cache[$key] = ($row['value'] ?? $default);
    } catch (Throwable) {
        return $default;
    }
}

function activity(string $action, string $entityType = '', ?int $entityId = null, string $details = ''): void
{
    try {
        Database::execute(
            'INSERT INTO activity_logs (user_id,action,entity_type,entity_id,details,ip_address,user_agent,created_at) VALUES (?,?,?,?,?,?,?,NOW())',
            [Auth::id(), $action, $entityType, $entityId, $details, $_SERVER['REMOTE_ADDR'] ?? null, substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500)]
        );
    } catch (Throwable) {}
}

function notify_user(?int $userId, string $type, string $title, string $message, string $route = ''): void
{
    Database::execute('INSERT INTO notifications (user_id,type,title,message,url,is_read,created_at) VALUES (?,?,?,?,?,0,NOW())', [$userId, $type, $title, $message, $route]);
}

function paginate(int $total, int $perPage = 10): array
{
    $page = max(1, (int)($_GET['page'] ?? 1));
    $pages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $pages);
    return ['page'=>$page,'per_page'=>$perPage,'pages'=>$pages,'offset'=>($page-1)*$perPage,'total'=>$total];
}

function pagination_links(array $p): string
{
    if (($p['pages'] ?? 1) <= 1) return '';
    $html = '<nav><ul class="pagination pagination-sm mb-0">';
    for ($i=1; $i <= $p['pages']; $i++) {
        $query = $_GET; $query['page'] = $i;
        $html .= '<li class="page-item ' . ($i === $p['page'] ? 'active' : '') . '"><a class="page-link" href="?' . e(http_build_query($query)) . '">' . $i . '</a></li>';
    }
    return $html . '</ul></nav>';
}

function upload_file(string $field, string $folder, array $allowed, int $maxBytes = 3145728): ?string
{
    if (empty($_FILES[$field]['name'])) return null;
    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > $maxBytes) throw new RuntimeException('Upload failed or file is too large.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime])) throw new RuntimeException('Unsupported file type.');
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    $relative = trim($folder, '/') . '/' . $name;
    $target = PUBLIC_PATH . '/' . $relative;
    if (!is_dir(dirname($target))) mkdir(dirname($target), 0775, true);
    if (!move_uploaded_file($file['tmp_name'], $target)) throw new RuntimeException('Unable to save uploaded file.');
    return $relative;
}

function format_date(?string $date): string { return $date ? date('d M Y', strtotime($date)) : '—'; }
function format_time(?string $time): string { return $time ? date('h:i A', strtotime($time)) : '—'; }
function badge_class(string $status): string
{
    return match ($status) {
        'Present','Active' => 'success', 'Late' => 'warning', 'Absent','Inactive' => 'danger',
        'On Leave' => 'info', 'Holiday' => 'secondary', 'Half-Day' => 'primary', default => 'light'
    };
}
