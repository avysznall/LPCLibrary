<?php
return [
    'name' => env('APP_NAME', 'Universal QR Attendance'),
    'url' => rtrim(env('APP_URL', 'http://localhost/universal_qr_attendance/public'), '/'),
    'env' => env('APP_ENV', 'production'),
    'debug' => filter_var(env('APP_DEBUG', false), FILTER_VALIDATE_BOOL),
    'key' => env('APP_KEY', 'replace-this-key'),
    'db' => [
        'host' => env('DB_HOST', '127.0.0.1'),
        'port' => env('DB_PORT', '3306'),
        'name' => env('DB_NAME', 'universal_qr_attendance'),
        'user' => env('DB_USER', 'root'),
        'pass' => env('DB_PASS', ''),
        'charset' => 'utf8mb4',
    ],
];
