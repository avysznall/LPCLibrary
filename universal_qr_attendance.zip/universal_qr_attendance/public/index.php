<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Controllers\AttendanceController;
use App\Controllers\AuthController;
use App\Controllers\DashboardController;
use App\Controllers\KioskController;
use App\Controllers\ManagementController;
use App\Controllers\PeopleController;
use App\Controllers\QrController;
use App\Controllers\ReportController;
use App\Controllers\ScheduleController;
use App\Controllers\SettingsController;
use App\Controllers\UserController;

if (!is_file(dirname(__DIR__) . '/.env')) {
    header('Location: install.php');
    exit;
}

$route = trim($_GET['route'] ?? 'dashboard', '/');
$method = strtoupper($_SERVER['REQUEST_METHOD']);
$key = $method . ' ' . $route;

$routes = [
    'GET login' => [AuthController::class, 'loginForm'],
    'POST login' => [AuthController::class, 'login'],
    'POST logout' => [AuthController::class, 'logout'],
    'GET forgot-password' => [AuthController::class, 'forgotForm'],
    'POST forgot-password' => [AuthController::class, 'forgot'],
    'GET reset-password' => [AuthController::class, 'resetForm'],
    'POST reset-password' => [AuthController::class, 'reset'],
    'GET profile' => [AuthController::class, 'profile'],
    'POST profile' => [AuthController::class, 'updateProfile'],
    'POST change-password' => [AuthController::class, 'changePassword'],
    'GET dashboard' => [DashboardController::class, 'index'],
    'GET kiosk' => [KioskController::class, 'index'],
    'POST api/kiosk/scan' => [KioskController::class, 'scanApi'],
    'GET people' => [PeopleController::class, 'index'],
    'GET people/create' => [PeopleController::class, 'create'],
    'POST people/store' => [PeopleController::class, 'store'],
    'GET people/show' => [PeopleController::class, 'show'],
    'GET people/edit' => [PeopleController::class, 'edit'],
    'POST people/update' => [PeopleController::class, 'update'],
    'POST people/archive' => [PeopleController::class, 'archive'],
    'POST qr/regenerate' => [QrController::class, 'regenerate'],
    'POST qr/bulk-generate' => [QrController::class, 'bulkGenerate'],
    'GET qr/bulk' => [QrController::class, 'bulk'],
    'GET qr/download' => [QrController::class, 'download'],
    'GET attendance' => [AttendanceController::class, 'index'],
    'GET attendance/scanner' => [AttendanceController::class, 'scanner'],
    'POST api/attendance/scan' => [AttendanceController::class, 'scanApi'],
    'GET attendance/manual' => [AttendanceController::class, 'manualForm'],
    'POST attendance/manual' => [AttendanceController::class, 'manualStore'],
    'GET attendance/edit' => [AttendanceController::class, 'edit'],
    'POST attendance/update' => [AttendanceController::class, 'update'],
    'POST attendance/delete' => [AttendanceController::class, 'delete'],
    'POST attendance/mark-absences' => [AttendanceController::class, 'markAbsences'],
    'GET schedules' => [ScheduleController::class, 'index'],
    'GET schedules/create' => [ScheduleController::class, 'create'],
    'POST schedules/store' => [ScheduleController::class, 'store'],
    'GET schedules/edit' => [ScheduleController::class, 'edit'],
    'POST schedules/update' => [ScheduleController::class, 'update'],
    'POST schedules/delete' => [ScheduleController::class, 'delete'],
    'GET reports' => [ReportController::class, 'index'],
    'GET reports/export' => [ReportController::class, 'export'],
    'GET categories' => [ManagementController::class, 'categories'],
    'POST categories/save' => [ManagementController::class, 'saveCategory'],
    'POST categories/delete' => [ManagementController::class, 'deleteCategory'],
    'GET departments' => [ManagementController::class, 'departments'],
    'POST departments/save' => [ManagementController::class, 'saveDepartment'],
    'POST departments/delete' => [ManagementController::class, 'deleteDepartment'],
    'GET holidays' => [ManagementController::class, 'holidays'],
    'POST holidays/save' => [ManagementController::class, 'saveHoliday'],
    'POST holidays/delete' => [ManagementController::class, 'deleteHoliday'],
    'GET announcements' => [ManagementController::class, 'announcements'],
    'POST announcements/save' => [ManagementController::class, 'saveAnnouncement'],
    'POST announcements/delete' => [ManagementController::class, 'deleteAnnouncement'],
    'GET activity-logs' => [ManagementController::class, 'activityLogs'],
    'GET notifications' => [ManagementController::class, 'notifications'],
    'POST notifications/read' => [ManagementController::class, 'readNotification'],
    'POST notifications/read-all' => [ManagementController::class, 'readAllNotifications'],
    'GET users' => [UserController::class, 'index'],
    'POST users/save' => [UserController::class, 'save'],
    'POST users/delete' => [UserController::class, 'delete'],
    'GET settings' => [SettingsController::class, 'index'],
    'POST settings' => [SettingsController::class, 'update'],
    'POST settings/backup' => [SettingsController::class, 'backup'],
    'GET settings/backup/download' => [SettingsController::class, 'downloadBackup'],
    'POST settings/restore' => [SettingsController::class, 'restore'],
];

if (!isset($routes[$key])) {
    http_response_code(404);
    view('errors/404', ['title' => 'Page Not Found']);
    exit;
}
[$controller, $action] = $routes[$key];
try {
    (new $controller())->$action();
} catch (Throwable $e) {
    if (config('debug', false))
        throw $e;
    http_response_code(500);
    view('errors/500', ['title' => 'System Error', 'message' => 'An unexpected error occurred. Check storage/logs and the server error log.']);
}
