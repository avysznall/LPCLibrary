<?php
declare(strict_types=1);

$basePath = dirname(__DIR__);

function splitSqlStatements(string $sql): array
{
    $statements = [];
    $buffer = '';
    $quote = null;
    $escaped = false;
    $length = strlen($sql);
    for ($i = 0; $i < $length; $i++) {
        $char = $sql[$i];
        if ($escaped) {
            $buffer .= $char;
            $escaped = false;
            continue;
        }
        if ($quote !== null && $char === '\\') {
            $buffer .= $char;
            $escaped = true;
            continue;
        }
        if ($quote !== null) {
            $buffer .= $char;
            if ($char === $quote)
                $quote = null;
            continue;
        }
        if (in_array($char, ["'", '"', '`'], true)) {
            $quote = $char;
            $buffer .= $char;
            continue;
        }
        if ($char === ';') {
            if (trim($buffer) !== '')
                $statements[] = trim($buffer);
            $buffer = '';
            continue;
        }
        $buffer .= $char;
    }
    if (trim($buffer) !== '')
        $statements[] = trim($buffer);
    return $statements;
}

$installed = is_file($basePath . '/.env');
$requirements = [
    'PHP 8.2+' => version_compare(PHP_VERSION, '8.2.0', '>='),
    'PDO MySQL' => extension_loaded('pdo_mysql'),
    'GD' => extension_loaded('gd'),
    'Mbstring' => extension_loaded('mbstring'),
    'ZIP' => extension_loaded('zip'),
    'DOM' => extension_loaded('dom'),
    'Fileinfo' => extension_loaded('fileinfo'),
    'Composer dependencies' => is_file($basePath . '/vendor/autoload.php'),
];
$missingRequirements = array_keys(array_filter($requirements, fn(bool $ok): bool => !$ok));
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
    if ($missingRequirements) {
        $error = 'Missing requirements: ' . implode(', ', $missingRequirements) . '. Install/enable them before continuing.';
    } else {
        $host = trim($_POST['db_host'] ?? '127.0.0.1');
        $port = trim($_POST['db_port'] ?? '3306');
        $name = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['db_name'] ?? 'universal_qr_attendance');
        $user = trim($_POST['db_user'] ?? 'root');
        $pass = $_POST['db_pass'] ?? '';
        $appUrl = rtrim(trim($_POST['app_url'] ?? ''), '/');
        $adminName = trim($_POST['admin_name'] ?? 'System Administrator');
        $adminEmail = trim($_POST['admin_email'] ?? 'admin@example.com');
        $adminUser = trim($_POST['admin_username'] ?? 'admin');
        $adminPassword = $_POST['admin_password'] ?? '';

        try {
            if (!$name || !$appUrl || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL) || strlen($adminPassword) < 8) {
                throw new RuntimeException('Complete all fields. The administrator password must contain at least 8 characters.');
            }
            $pdo = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `{$name}`");
            $schema = file_get_contents($basePath . '/database/schema.sql');
            foreach (splitSqlStatements($schema) as $statement)
                $pdo->exec($statement);
            $role = $pdo->query("SELECT id FROM roles WHERE slug='super-administrator' LIMIT 1")->fetchColumn();
            $stmt = $pdo->prepare('INSERT INTO users (role_id,full_name,username,email,password,status) VALUES (?,?,?,?,?,"Active")');
            $stmt->execute([$role, $adminName, $adminUser, $adminEmail, password_hash($adminPassword, PASSWORD_DEFAULT)]);
            $appKey = bin2hex(random_bytes(32));
            $env = "APP_NAME=\"Universal QR Attendance\"\nAPP_URL=\"{$appUrl}\"\nAPP_ENV=\"production\"\nAPP_DEBUG=false\nAPP_KEY=\"{$appKey}\"\nDB_HOST=\"{$host}\"\nDB_PORT=\"{$port}\"\nDB_NAME=\"{$name}\"\nDB_USER=\"{$user}\"\nDB_PASS=\"" . addcslashes($pass, "\\\"") . "\"\n";
            if (file_put_contents($basePath . '/.env', $env) === false) {
                throw new RuntimeException('Database installed, but the .env file could not be written. Create it manually from .env.example.');
            }
            $installed = true;
            $message = 'Installation completed. Delete or rename install.php after signing in.';
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Universal QR Attendance Installer</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background: #eef2f7
        }

        .card {
            max-width: 820px;
            margin: 40px auto;
            border: 0;
            box-shadow: 0 10px 35px rgba(0, 0, 0, .08)
        }

        .brand {
            font-weight: 700;
            color: #343a40
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-body p-4 p-md-5">
                <h2 class="brand mb-1">Universal QR Attendance</h2>
                <p class="text-muted mb-4">Web installation</p>
                <div class="card bg-light mb-4" style="box-shadow:none">
                    <div class="card-body py-3"><strong>Requirements</strong>
                        <div class="row mt-2"><?php foreach ($requirements as $label => $ok): ?>
                                <div class="col-md-4 mb-1"><span
                                        class="badge badge-<?= $ok ? 'success' : 'danger' ?>"><?= $ok ? 'Ready' : 'Missing' ?></span>
                                    <?= htmlspecialchars($label) ?></div><?php endforeach; ?>
                        </div><?php if ($missingRequirements): ?><small class="text-danger d-block mt-2">Run
                                <code>composer install</code> and enable the missing PHP extensions before
                                installation.</small><?php endif; ?>
                    </div>
                </div>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
                <?php if ($message): ?>
                    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
                <?php if ($installed): ?>
                    <p>The application is installed.</p><a class="btn btn-primary" href="index.php?route=login">Open
                        Login</a>
                <?php else: ?>
                    <form method="post">
                        <h5>Database</h5>
                        <div class="form-row">
                            <div class="form-group col-md-8"><label>Host</label><input class="form-control" name="db_host"
                                    value="127.0.0.1" required></div>
                            <div class="form-group col-md-4"><label>Port</label><input class="form-control" name="db_port"
                                    value="3306" required></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-5"><label>Database Name</label><input class="form-control"
                                    name="db_name" value="universal_qr_attendance" required></div>
                            <div class="form-group col-md-4"><label>User</label><input class="form-control" name="db_user"
                                    value="root" required></div>
                            <div class="form-group col-md-3"><label>Password</label><input class="form-control"
                                    type="password" name="db_pass"></div>
                        </div>
                        <div class="form-group"><label>Application URL</label><input class="form-control" name="app_url"
                                value="http://localhost/universal_qr_attendance/public" required></div>
                        <hr>
                        <h5>First Super Administrator</h5>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Full Name</label><input class="form-control"
                                    name="admin_name" value="System Administrator" required></div>
                            <div class="form-group col-md-6"><label>Username</label><input class="form-control"
                                    name="admin_username" value="admin" required></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-7"><label>Email</label><input class="form-control" type="email"
                                    name="admin_email" value="admin@example.com" required></div>
                            <div class="form-group col-md-5"><label>Password</label><input class="form-control"
                                    type="password" name="admin_password" minlength="8" required></div>
                        </div>
                        <button class="btn btn-primary btn-block">Install System</button>
                    </form><?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>