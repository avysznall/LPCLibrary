<?php
declare(strict_types=1);

$_GET['route'] = 'kiosk';
require __DIR__ . '/index.php';
