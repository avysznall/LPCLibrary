<?php
declare(strict_types=1);

$checks = [
    'PHP 8.2 or newer' => version_compare(PHP_VERSION, '8.2.0', '>='),
    'PDO extension' => extension_loaded('pdo'),
    'PDO MySQL extension' => extension_loaded('pdo_mysql'),
    'GD extension' => extension_loaded('gd'),
    'Mbstring extension' => extension_loaded('mbstring'),
    'ZIP extension' => extension_loaded('zip'),
    'DOM extension' => extension_loaded('dom'),
    'Fileinfo extension' => extension_loaded('fileinfo'),
    'Composer dependencies' => is_file(dirname(__DIR__) . '/vendor/autoload.php'),
    'public/uploads writable' => is_writable(dirname(__DIR__) . '/public/uploads'),
    'public/backups writable' => is_writable(dirname(__DIR__) . '/public/backups'),
    'storage/logs writable' => is_writable(dirname(__DIR__) . '/storage/logs'),
];

$failed = false;
echo "Universal QR Attendance - Requirements Check\n" . str_repeat('=', 50) . "\n";
foreach ($checks as $name => $ok) {
    printf("[%s] %s\n", $ok ? 'OK' : 'FAIL', $name);
    $failed = $failed || !$ok;
}
echo str_repeat('-', 50) . "\n";
echo $failed ? "One or more requirements are missing.\n" : "All requirements are available.\n";
exit($failed ? 1 : 0);
